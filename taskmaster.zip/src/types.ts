export type NovelGenre = 
  | 'xianxia' 
  | 'wuxia' 
  | 'fantasy' 
  | 'rebirth' 
  | 'scifi' 
  | 'romance' 
  | 'adventure' 
  | 'mystery';

export interface Chapter {
  id: string;
  novelId: string;
  chapterNumber: number;
  title: string;
  content: string; // raw or line breaks
  paragraphs?: string[];
  wordCount: number;
  publishedAt: string;
}

export interface Novel {
  id: string;
  title: string;
  titleThai: string;
  originalTitle?: string;
  author: string;
  translator?: string;
  coverImage: string;
  description: string;
  genre: NovelGenre;
  tags: string[];
  status: 'ongoing' | 'completed';
  rating: number;
  ratingCount: number;
  views: number;
  chapters: Chapter[];
  createdAt: string;
  updatedAt: string;
}

export type ReaderFont = 'sarabun' | 'kanit' | 'baijamjuree' | 'serif' | 'sans' | 'mono';
export type ReaderTheme = 'dark' | 'light' | 'sepia' | 'emerald' | 'midnight' | 'paper';
export type ReaderWidth = 'prose' | 'narrow' | 'wide' | 'full';

export interface ReaderSettings {
  font: ReaderFont;
  fontSize: number; // 14 to 30
  lineHeight: number; // 1.5 to 2.4
  letterSpacing: number; // -0.5 to 2
  maxWidth: ReaderWidth;
  textAlign: 'left' | 'justify';
  theme: ReaderTheme;
  autoScroll: boolean;
  autoScrollSpeed: number; // 1 to 10
  paragraphHighlight: boolean;
  showChineseAnnotation: boolean;
}

export type AmbientSoundType = 
  | 'none' 
  | 'rain' 
  | 'waves' 
  | 'fireplace' 
  | 'zen_bamboo' 
  | 'night_forest' 
  | 'cafe';

export interface AudioSettings {
  rate: number; // 0.6 to 2.2
  pitch: number; // 0.7 to 1.3
  volume: number; // 0 to 1
  voiceURI: string;
  ambientSound: AmbientSoundType;
  ambientVolume: number; // 0 to 1
  sleepTimerMinutes: number | null;
  autoNextChapter: boolean;
}

export interface Bookmark {
  id: string;
  novelId: string;
  chapterId: string;
  chapterNumber: number;
  paragraphIndex: number;
  snippet: string;
  note?: string;
  createdAt: string;
}

export interface ReadingHistoryItem {
  novelId: string;
  chapterId: string;
  chapterNumber: number;
  paragraphIndex: number;
  progressPercent: number;
  lastReadAt: string;
}

export interface UserStats {
  minutesRead: number;
  chaptersCompleted: number;
  currentStreakDays: number;
  lastActiveDate: string;
}

export interface UserProfile {
  id: string;
  name: string;
  avatar: string;
  bio: string;
  isGuest: boolean;
  favorites: string[]; // novel ids
  history: ReadingHistoryItem[];
  bookmarks: Bookmark[];
  stats: UserStats;
}

export interface CultivationTerm {
  chinese: string;
  pinyin: string;
  thai: string;
  meaning: string;
  category: 'realm' | 'technique' | 'sect' | 'item' | 'title' | 'general';
}
