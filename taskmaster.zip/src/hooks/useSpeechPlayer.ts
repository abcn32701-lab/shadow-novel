import { useState, useEffect, useRef, useCallback } from 'react';
import { AudioSettings } from '../types';
import { ambientAudio } from '../utils/ambientAudio';
import { cleanTextForSpeech } from '../utils/textParser';

export interface SpeechPlayerOptions {
  chapterIndex?: number;
  totalChapters?: number;
  onNextChapter?: () => void;
  onPrevChapter?: () => void;
}

export interface SpeechPlayerHook {
  isPlaying: boolean;
  isPaused: boolean;
  currentParagraphIndex: number;
  availableVoices: SpeechSynthesisVoice[];
  settings: AudioSettings;
  sleepRemainingSeconds: number | null;
  playParagraph: (index: number) => void;
  togglePlayPause: () => void;
  stop: () => void;
  nextParagraph: () => void;
  prevParagraph: () => void;
  updateSettings: (newSettings: Partial<AudioSettings>) => void;
  setSleepTimer: (minutes: number | null) => void;
}

export function useSpeechPlayer(
  paragraphs: string[],
  optionsOrOnComplete?: SpeechPlayerOptions | (() => void)
): SpeechPlayerHook {
  const [isPlaying, setIsPlaying] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [currentParagraphIndex, setCurrentParagraphIndex] = useState(0);
  const [availableVoices, setAvailableVoices] = useState<SpeechSynthesisVoice[]>([]);
  const [sleepRemainingSeconds, setSleepRemainingSeconds] = useState<number | null>(null);

  const [settings, setSettings] = useState<AudioSettings>(() => {
    try {
      const saved = localStorage.getItem('novelia_audio_settings');
      if (saved) {
        return JSON.parse(saved);
      }
    } catch {}
    return {
      rate: 1.0,
      pitch: 1.0,
      volume: 1.0,
      voiceURI: '',
      ambientSound: 'none',
      ambientVolume: 0.35,
      sleepTimerMinutes: null,
      autoNextChapter: true
    };
  });

  const currentParagraphIndexRef = useRef(currentParagraphIndex);
  currentParagraphIndexRef.current = currentParagraphIndex;

  const isPlayingRef = useRef(isPlaying);
  isPlayingRef.current = isPlaying;

  const isPausedRef = useRef(isPaused);
  isPausedRef.current = isPaused;

  const paragraphsRef = useRef(paragraphs);
  paragraphsRef.current = paragraphs;

  const settingsRef = useRef(settings);
  settingsRef.current = settings;

  // Options ref to prevent stale closures in callbacks
  const optionsRef = useRef<SpeechPlayerOptions>({});
  optionsRef.current = typeof optionsOrOnComplete === 'function'
    ? { onNextChapter: optionsOrOnComplete }
    : (optionsOrOnComplete || {});

  const currentChapterIndex = typeof optionsOrOnComplete === 'object' ? optionsOrOnComplete?.chapterIndex : undefined;
  const prevChapterIndexRef = useRef<number | undefined>(currentChapterIndex);
  const isAdvancingChapterRef = useRef<boolean>(false);

  // Timers to manage lifecycles cleanly
  const watchdogTimerRef = useRef<any>(null);
  const transitionTimerRef = useRef<any>(null);
  const nextChapterTimerRef = useRef<any>(null);
  const isUserInterruptionRef = useRef<boolean>(false);

  // Ensure window storage for utterance Garbage Collection prevention in V8/Chrome
  if (typeof window !== 'undefined') {
    (window as any).__novelia_utterances = (window as any).__novelia_utterances || [];
  }

  const clearTimers = () => {
    if (watchdogTimerRef.current) {
      clearTimeout(watchdogTimerRef.current);
      watchdogTimerRef.current = null;
    }
    if (transitionTimerRef.current) {
      clearTimeout(transitionTimerRef.current);
      transitionTimerRef.current = null;
    }
    if (nextChapterTimerRef.current) {
      clearTimeout(nextChapterTimerRef.current);
      nextChapterTimerRef.current = null;
    }
  };

  // Load and deduplicate voices
  useEffect(() => {
    const updateVoices = () => {
      if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
        const rawVoices = window.speechSynthesis.getVoices();
        
        const seen = new Set<string>();
        const uniqueVoices: SpeechSynthesisVoice[] = [];
        
        for (const voice of rawVoices) {
          const id = `${voice.voiceURI || voice.name}__${voice.lang}`;
          if (!seen.has(id)) {
            seen.add(id);
            uniqueVoices.push(voice);
          }
        }
        
        // Prioritize Thai voices first, then English, then others
        uniqueVoices.sort((a, b) => {
          const aIsTh = a.lang.toLowerCase().startsWith('th');
          const bIsTh = b.lang.toLowerCase().startsWith('th');
          if (aIsTh && !bIsTh) return -1;
          if (!aIsTh && bIsTh) return 1;
          
          const aIsEn = a.lang.toLowerCase().startsWith('en');
          const bIsEn = b.lang.toLowerCase().startsWith('en');
          if (aIsEn && !bIsEn) return -1;
          if (!aIsEn && bIsEn) return 1;
          
          return a.name.localeCompare(b.name);
        });

        setAvailableVoices(uniqueVoices);
        
        // Auto select Thai voice if none selected
        if (!settingsRef.current.voiceURI && uniqueVoices.length > 0) {
          const thaiVoice = uniqueVoices.find(v => v.lang.toLowerCase().includes('th'));
          if (thaiVoice) {
            setSettings(prev => ({ ...prev, voiceURI: thaiVoice.voiceURI }));
          } else {
            setSettings(prev => ({ ...prev, voiceURI: uniqueVoices[0].voiceURI }));
          }
        }
      }
    };

    updateVoices();
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      window.speechSynthesis.onvoiceschanged = updateVoices;
    }
  }, []);

  // Ambient sound lifecycle
  useEffect(() => {
    if (isPlaying && !isPaused && settings.ambientSound !== 'none') {
      ambientAudio.play(settings.ambientSound, settings.ambientVolume);
    } else {
      ambientAudio.stop();
    }
  }, [isPlaying, isPaused, settings.ambientSound, settings.ambientVolume]);

  // Sleep Timer countdown
  useEffect(() => {
    if (!sleepRemainingSeconds || sleepRemainingSeconds <= 0) return;

    const interval = setInterval(() => {
      setSleepRemainingSeconds(prev => {
        if (!prev || prev <= 1) {
          stop();
          return null;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [sleepRemainingSeconds]);

  // Keep synthesis un-paused if browser accidentally pauses it
  useEffect(() => {
    if (!isPlaying || isPaused) return;
    const unpauseCheck = setInterval(() => {
      if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
        if (window.speechSynthesis.paused) {
          window.speechSynthesis.resume();
        }
      }
    }, 2500);
    return () => clearInterval(unpauseCheck);
  }, [isPlaying, isPaused]);

  // Stop playback completely
  const stop = useCallback(() => {
    clearTimers();
    isAdvancingChapterRef.current = false;
    isUserInterruptionRef.current = true;

    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }

    ambientAudio.stop();
    setIsPlaying(false);
    isPlayingRef.current = false;
    setIsPaused(false);
    isPausedRef.current = false;

    setTimeout(() => {
      isUserInterruptionRef.current = false;
    }, 80);
  }, []);

  // Chapter finished handler
  const handleChapterFinished = useCallback(() => {
    clearTimers();
    if (!settingsRef.current.autoNextChapter) {
      stop();
      return;
    }

    const opts = optionsRef.current;
    if (opts.onNextChapter) {
      if (
        opts.chapterIndex !== undefined &&
        opts.totalChapters !== undefined &&
        opts.chapterIndex >= opts.totalChapters - 1
      ) {
        // Reached the end of the entire novel
        stop();
        return;
      }

      // Mark that we are transitioning so next chapter auto-starts
      isAdvancingChapterRef.current = true;
      opts.onNextChapter();
    } else {
      stop();
    }
  }, [stop]);

  // Core internal speak function
  const speakParagraphInternal = useCallback((index: number, isUserTriggered: boolean = false) => {
    clearTimers();
    const currentParas = paragraphsRef.current;
    if (!currentParas || currentParas.length === 0) return;

    if (index < 0 || index >= currentParas.length) {
      if (index >= currentParas.length) {
        handleChapterFinished();
      } else {
        stop();
      }
      return;
    }

    if (typeof window === 'undefined' || !('speechSynthesis' in window)) {
      alert('เบราว์เซอร์ของคุณไม่รองรับการสังเคราะห์เสียง (Web Speech API)');
      return;
    }

    // Set state
    setCurrentParagraphIndex(index);
    currentParagraphIndexRef.current = index;
    setIsPlaying(true);
    isPlayingRef.current = true;
    setIsPaused(false);
    isPausedRef.current = false;

    const rawText = currentParas[index]?.trim() || '';
    const textToSpeak = cleanTextForSpeech(rawText);

    // If paragraph has no speakable text, skip immediately to next
    if (!textToSpeak) {
      transitionTimerRef.current = setTimeout(() => {
        if (isPlayingRef.current && !isPausedRef.current) {
          speakParagraphInternal(index + 1, false);
        }
      }, 50);
      return;
    }

    // CRITICAL: ONLY cancel if this was a manual user jump/start!
    // For automatic sequential progression, DO NOT cancel, as cancel() disrupts Chrome audio queue!
    if (isUserTriggered) {
      isUserInterruptionRef.current = true;
      window.speechSynthesis.cancel();
      setTimeout(() => {
        isUserInterruptionRef.current = false;
      }, 50);
    }

    const utterance = new SpeechSynthesisUtterance(textToSpeak);

    // Pin utterance in global window array to prevent Chrome GC bug
    if (typeof window !== 'undefined') {
      (window as any).__novelia_utterances.push(utterance);
      if ((window as any).__novelia_utterances.length > 50) {
        (window as any).__novelia_utterances.shift();
      }
    }

    // Voice assignment
    const currentVoice = availableVoices.find(v => v.voiceURI === settingsRef.current.voiceURI);
    if (currentVoice) {
      utterance.voice = currentVoice;
      utterance.lang = currentVoice.lang;
    } else {
      const thaiVoice = availableVoices.find(v => v.lang.toLowerCase().includes('th'));
      if (thaiVoice) {
        utterance.voice = thaiVoice;
        utterance.lang = thaiVoice.lang;
      } else {
        utterance.lang = 'th-TH';
      }
    }

    utterance.rate = Math.max(0.5, Math.min(2.0, settingsRef.current.rate));
    utterance.pitch = Math.max(0.5, Math.min(1.5, settingsRef.current.pitch));
    utterance.volume = Math.max(0.1, Math.min(1.0, settingsRef.current.volume));

    // Watchdog Timer: if browser stalls or onend fails to fire, advance safely
    const expectedSec = Math.max(3, textToSpeak.length / (10 * utterance.rate));
    const watchdogMs = Math.round(expectedSec * 1000 + 7000);

    watchdogTimerRef.current = setTimeout(() => {
      if (isPlayingRef.current && !isPausedRef.current && currentParagraphIndexRef.current === index) {
        if (!window.speechSynthesis.speaking) {
          // Audio finished speaking but browser failed to dispatch onend
          const nextIdx = index + 1;
          const latestParas = paragraphsRef.current;
          if (nextIdx < latestParas.length) {
            speakParagraphInternal(nextIdx, false);
          } else {
            handleChapterFinished();
          }
        } else if (window.speechSynthesis.paused) {
          window.speechSynthesis.resume();
        }
      }
    }, watchdogMs);

    // On End Handler: advance to next paragraph
    utterance.onend = () => {
      if (watchdogTimerRef.current) {
        clearTimeout(watchdogTimerRef.current);
        watchdogTimerRef.current = null;
      }

      if (!isPlayingRef.current || isPausedRef.current) {
        return;
      }

      const nextIdx = index + 1;
      const latestParas = paragraphsRef.current;

      if (nextIdx < latestParas.length) {
        // Natural breath pause between paragraphs (80ms)
        transitionTimerRef.current = setTimeout(() => {
          if (isPlayingRef.current && !isPausedRef.current) {
            speakParagraphInternal(nextIdx, false);
          }
        }, 80);
      } else {
        handleChapterFinished();
      }
    };

    // On Error Handler
    utterance.onerror = (e) => {
      if (watchdogTimerRef.current) {
        clearTimeout(watchdogTimerRef.current);
        watchdogTimerRef.current = null;
      }

      if (isUserInterruptionRef.current) {
        return;
      }

      console.warn('Speech synthesis error on paragraph', index, e.error);

      // Auto-recover from transient errors after brief delay
      if (isPlayingRef.current && !isPausedRef.current) {
        transitionTimerRef.current = setTimeout(() => {
          if (isPlayingRef.current && !isPausedRef.current) {
            const nextIdx = index + 1;
            const latestParas = paragraphsRef.current;
            if (nextIdx < latestParas.length) {
              speakParagraphInternal(nextIdx, false);
            } else {
              handleChapterFinished();
            }
          }
        }, 150);
      }
    };

    // Execute speak
    if (isUserTriggered) {
      setTimeout(() => {
        if (isPlayingRef.current && !isPausedRef.current) {
          window.speechSynthesis.speak(utterance);
          if (window.speechSynthesis.paused) {
            window.speechSynthesis.resume();
          }
        }
      }, 40);
    } else {
      window.speechSynthesis.speak(utterance);
      if (window.speechSynthesis.paused) {
        window.speechSynthesis.resume();
      }
    }
  }, [availableVoices, stop, handleChapterFinished]);

  // Public Play Paragraph
  const playParagraph = useCallback((index: number) => {
    speakParagraphInternal(index, true);
  }, [speakParagraphInternal]);

  // Chapter change effect: auto-start next chapter smoothly
  useEffect(() => {
    if (
      currentChapterIndex !== undefined &&
      prevChapterIndexRef.current !== undefined &&
      currentChapterIndex !== prevChapterIndexRef.current
    ) {
      prevChapterIndexRef.current = currentChapterIndex;

      // Always reset paragraph index to 0 for new chapter
      setCurrentParagraphIndex(0);
      currentParagraphIndexRef.current = 0;

      const shouldPlayNewChapter =
        isAdvancingChapterRef.current || (isPlayingRef.current && !isPausedRef.current);
      isAdvancingChapterRef.current = false;

      if (shouldPlayNewChapter) {
        clearTimers();
        if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
          isUserInterruptionRef.current = true;
          window.speechSynthesis.cancel();
          setTimeout(() => {
            isUserInterruptionRef.current = false;
          }, 60);
        }

        // Wait 300ms for paragraphs to load into ref
        nextChapterTimerRef.current = setTimeout(() => {
          if (isPlayingRef.current && !isPausedRef.current) {
            speakParagraphInternal(0, true);
          }
        }, 300);
      }
    } else if (currentChapterIndex !== undefined && prevChapterIndexRef.current === undefined) {
      prevChapterIndexRef.current = currentChapterIndex;
    }
  }, [currentChapterIndex, speakParagraphInternal]);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      clearTimers();
    };
  }, []);

  // Public Toggle Play / Pause
  const togglePlayPause = useCallback(() => {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) return;

    if (!isPlaying) {
      speakParagraphInternal(currentParagraphIndexRef.current, true);
    } else if (isPaused) {
      window.speechSynthesis.resume();
      setIsPaused(false);
      isPausedRef.current = false;
      if (settings.ambientSound !== 'none') {
        ambientAudio.play(settings.ambientSound, settings.ambientVolume);
      }
    } else {
      window.speechSynthesis.pause();
      setIsPaused(true);
      isPausedRef.current = true;
      ambientAudio.stop();
    }
  }, [isPlaying, isPaused, speakParagraphInternal, settings.ambientSound, settings.ambientVolume]);

  // Public Next / Prev
  const nextParagraph = useCallback(() => {
    const nextIdx = currentParagraphIndexRef.current + 1;
    const currentParas = paragraphsRef.current;
    if (nextIdx < currentParas.length) {
      speakParagraphInternal(nextIdx, true);
    } else {
      handleChapterFinished();
    }
  }, [speakParagraphInternal, handleChapterFinished]);

  const prevParagraph = useCallback(() => {
    const prevIdx = currentParagraphIndexRef.current - 1;
    if (prevIdx >= 0) {
      speakParagraphInternal(prevIdx, true);
    } else {
      const opts = optionsRef.current;
      if (opts.chapterIndex !== undefined && opts.chapterIndex > 0 && opts.onPrevChapter) {
        opts.onPrevChapter();
      }
    }
  }, [speakParagraphInternal]);

  // Public update settings with localStorage persistence
  const updateSettings = useCallback((newSettings: Partial<AudioSettings>) => {
    setSettings(prev => {
      const updated = { ...prev, ...newSettings };
      try {
        localStorage.setItem('novelia_audio_settings', JSON.stringify(updated));
      } catch {}
      if (newSettings.ambientVolume !== undefined && updated.ambientSound !== 'none') {
        ambientAudio.setVolume(newSettings.ambientVolume);
      }
      return updated;
    });
  }, []);

  const setSleepTimer = useCallback((minutes: number | null) => {
    if (!minutes || minutes <= 0) {
      setSleepRemainingSeconds(null);
      updateSettings({ sleepTimerMinutes: null });
    } else {
      setSleepRemainingSeconds(minutes * 60);
      updateSettings({ sleepTimerMinutes: minutes });
    }
  }, [updateSettings]);

  return {
    isPlaying,
    isPaused,
    currentParagraphIndex,
    availableVoices,
    settings,
    sleepRemainingSeconds,
    playParagraph,
    togglePlayPause,
    stop,
    nextParagraph,
    prevParagraph,
    updateSettings,
    setSleepTimer
  };
}
