import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { Novel, Chapter, ReaderSettings, UserProfile } from './types';
import { DEFAULT_NOVELS } from './data/defaultNovels';
import { useSpeechPlayer } from './hooks/useSpeechPlayer';
import { splitIntoParagraphs, estimateReadingTime } from './utils/textParser';
import { authService } from './utils/authService';

// Components
import { Navbar } from './components/Navbar';
import { HomeNovelList } from './components/HomeNovelList';
import { ReaderView } from './components/ReaderView';
import { AudioPlayerBar } from './components/AudioPlayerBar';
import { ChapterSidebar } from './components/ChapterSidebar';
import { AIToolsModal } from './components/AIToolsModal';
import { LibraryModal } from './components/LibraryModal';
import { CreateNovelModal } from './components/CreateNovelModal';
import { AddChapterModal } from './components/AddChapterModal';
import { SettingsModal } from './components/SettingsModal';
import { SleepTimerModal } from './components/SleepTimerModal';
import { UserProfileModal } from './components/UserProfileModal';
import { SharePortalModal } from './components/SharePortalModal';
import { BatchImportModal } from './components/BatchImportModal';
import { EditCoverModal } from './components/EditCoverModal';

const NOVELS_STORAGE_KEY = 'novelia_novels_v1';
const SETTINGS_STORAGE_KEY = 'novelia_reader_settings_v1';

export default function App() {
  // Novels State
  const [novels, setNovels] = useState<Novel[]>(() => {
    try {
      const saved = localStorage.getItem(NOVELS_STORAGE_KEY);
      if (saved) {
        return JSON.parse(saved);
      }
    } catch {
      // fallback
    }
    return DEFAULT_NOVELS;
  });

  // Navigation State
  const [currentView, setCurrentView] = useState<'home' | 'reader'>('home');
  const [selectedNovelId, setSelectedNovelId] = useState<string>(novels[0]?.id || 'novel_1');
  const [currentChapterIndex, setCurrentChapterIndex] = useState<number>(0);
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Reader Settings State
  const [readerSettings, setReaderSettings] = useState<ReaderSettings>(() => {
    try {
      const saved = localStorage.getItem(SETTINGS_STORAGE_KEY);
      if (saved) {
        return JSON.parse(saved);
      }
    } catch {
      // fallback
    }
    return {
      font: 'sarabun',
      fontSize: 18,
      lineHeight: 1.9,
      letterSpacing: 0,
      maxWidth: 'prose',
      textAlign: 'left',
      theme: 'dark',
      autoScroll: false,
      autoScrollSpeed: 3,
      paragraphHighlight: true,
      showChineseAnnotation: true
    };
  });

  // User Profile
  const [userProfile, setUserProfile] = useState<UserProfile>(() => authService.getProfile());

  // Modals state
  const [isLibraryOpen, setIsLibraryOpen] = useState(false);
  const [isAIToolsOpen, setIsAIToolsOpen] = useState(false);
  const [aiToolsText, setAiToolsText] = useState('');
  const [aiToolsMode, setAiToolsMode] = useState<'summarize' | 'translate'>('summarize');
  const [isCreateNovelOpen, setIsCreateNovelOpen] = useState(false);
  const [isAddChapterOpen, setIsAddChapterOpen] = useState(false);
  const [isBatchImportOpen, setIsBatchImportOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isSleepTimerOpen, setIsSleepTimerOpen] = useState(false);
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const [isChapterSidebarOpen, setIsChapterSidebarOpen] = useState(false);
  const [coverEditNovel, setCoverEditNovel] = useState<Novel | null>(null);
  const [shareData, setShareData] = useState<{ quote: string; novelTitle: string; chapterTitle: string } | null>(null);

  // Selected Novel and Chapter
  const selectedNovel = useMemo(() => {
    return novels.find(n => n.id === selectedNovelId) || novels[0];
  }, [novels, selectedNovelId]);

  const currentChapter = useMemo(() => {
    return selectedNovel?.chapters[currentChapterIndex] || selectedNovel?.chapters[0];
  }, [selectedNovel, currentChapterIndex]);

  const currentParagraphs = useMemo(() => {
    return currentChapter ? splitIntoParagraphs(currentChapter.content) : [];
  }, [currentChapter]);

  // Persist novels when updated
  useEffect(() => {
    try {
      localStorage.setItem(NOVELS_STORAGE_KEY, JSON.stringify(novels));
    } catch (e) {
      console.warn('Failed to persist novels:', e);
    }
  }, [novels]);

  // Persist reader settings
  const handleUpdateReaderSettings = (newSettings: Partial<ReaderSettings>) => {
    setReaderSettings(prev => {
      const updated = { ...prev, ...newSettings };
      try {
        localStorage.setItem(SETTINGS_STORAGE_KEY, JSON.stringify(updated));
      } catch {}
      return updated;
    });
  };

  // Next & Prev Chapter callbacks for speech player and reader navigation
  const handleNextChapter = useCallback(() => {
    setCurrentChapterIndex(prev => {
      const curNovel = novels.find(n => n.id === selectedNovelId);
      const total = curNovel?.chapters?.length || 0;
      if (prev < total - 1) {
        authService.incrementCompletedChapters();
        window.scrollTo({ top: 0, behavior: 'smooth' });
        return prev + 1;
      }
      return prev;
    });
  }, [novels, selectedNovelId]);

  const handlePrevChapter = useCallback(() => {
    setCurrentChapterIndex(prev => {
      if (prev > 0) {
        window.scrollTo({ top: 0, behavior: 'smooth' });
        return prev - 1;
      }
      return prev;
    });
  }, []);

  // Speech Player Hook with automatic continuous playback across chapters
  const speechPlayer = useSpeechPlayer(currentParagraphs, {
    chapterIndex: currentChapterIndex,
    totalChapters: selectedNovel?.chapters?.length || 0,
    onNextChapter: handleNextChapter,
    onPrevChapter: handlePrevChapter,
  });

  // Handlers
  const handleSelectNovel = (novel: Novel, chapterIndex: number = 0) => {
    speechPlayer.stop();
    setSelectedNovelId(novel.id);
    setCurrentChapterIndex(chapterIndex);
    setCurrentView('reader');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSelectChapter = (idx: number) => {
    setCurrentChapterIndex(idx);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handlePlayAudioNovel = (novel: Novel, chapterIndex: number = 0) => {
    speechPlayer.stop();
    setSelectedNovelId(novel.id);
    setCurrentChapterIndex(chapterIndex);
    setCurrentView('reader');
    window.scrollTo({ top: 0, behavior: 'smooth' });
    setTimeout(() => {
      speechPlayer.playParagraph(0);
    }, 250);
  };

  const handleAddNovel = (newNovel: Novel) => {
    setNovels(prev => [newNovel, ...prev]);
    handleSelectNovel(newNovel, 0);
  };

  const handleAddChapter = (newChapter: Chapter) => {
    setNovels(prev => prev.map(n => {
      if (n.id === selectedNovel.id) {
        return {
          ...n,
          chapters: [...n.chapters, newChapter],
          updatedAt: new Date().toISOString().split('T')[0]
        };
      }
      return n;
    }));
  };

  const handleImportAsNewNovel = (newNovel: Novel) => {
    setNovels(prev => [newNovel, ...prev]);
    handleSelectNovel(newNovel, 0);
  };

  const handleAppendToExistingNovel = (novelId: string, newChapters: Chapter[]) => {
    setNovels(prev => prev.map(n => {
      if (n.id === novelId) {
        return {
          ...n,
          chapters: [...n.chapters, ...newChapters],
          updatedAt: new Date().toISOString().split('T')[0]
        };
      }
      return n;
    }));
  };

  const handleApplyTranslationToCurrentChapter = (translatedText: string) => {
    if (!selectedNovel || !currentChapter) return;
    const { wordCount } = estimateReadingTime(translatedText);
    setNovels(prev => prev.map(n => {
      if (n.id === selectedNovel.id) {
        return {
          ...n,
          chapters: n.chapters.map(c => {
            if (c.id === currentChapter.id) {
              return {
                ...c,
                content: translatedText,
                wordCount
              };
            }
            return c;
          }),
          updatedAt: new Date().toISOString().split('T')[0]
        };
      }
      return n;
    }));
  };

  const handleOpenAIToolsWithText = (text: string, mode: 'summarize' | 'translate' = 'summarize') => {
    setAiToolsText(text);
    setAiToolsMode(mode);
    setIsAIToolsOpen(true);
  };

  const handleOpenShare = (quote: string, novelTitle: string, chapterTitle: string) => {
    setShareData({ quote, novelTitle, chapterTitle });
  };

  const handleUpdateNovelCover = (novelId: string, newCoverUrl: string) => {
    setNovels(prev => prev.map(n => {
      if (n.id === novelId) {
        return {
          ...n,
          coverImage: newCoverUrl,
          updatedAt: new Date().toISOString().split('T')[0]
        };
      }
      return n;
    }));
  };

  return (
    <div className="min-h-screen bg-neutral-950 text-neutral-100 flex flex-col selection:bg-amber-500/30 selection:text-amber-200">
      
      {/* Top Navbar */}
      <Navbar
        currentView={currentView}
        onNavigateHome={() => setCurrentView('home')}
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
        onOpenLibrary={() => setIsLibraryOpen(true)}
        onOpenAITools={() => {
          setAiToolsText(currentChapter?.content || '');
          setAiToolsMode('summarize');
          setIsAIToolsOpen(true);
        }}
        onOpenCreateNovel={() => setIsCreateNovelOpen(true)}
        onOpenBatchImport={() => setIsBatchImportOpen(true)}
        onOpenSettings={() => setIsSettingsOpen(true)}
        onOpenProfile={() => setIsProfileOpen(true)}
        userProfile={userProfile}
        ambientSound={speechPlayer.settings.ambientSound}
        isAudioPlaying={speechPlayer.isPlaying && !speechPlayer.isPaused}
        onToggleAudioPlayer={speechPlayer.togglePlayPause}
      />

      {/* Main Content Area */}
      <div className="flex-1">
        {currentView === 'home' ? (
          <main className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
            <HomeNovelList
              novels={novels}
              onSelectNovel={handleSelectNovel}
              onPlayAudioNovel={handlePlayAudioNovel}
              searchQuery={searchQuery}
              onOpenBatchImport={() => setIsBatchImportOpen(true)}
              onOpenEditCover={setCoverEditNovel}
            />
          </main>
        ) : (
          <ReaderView
            novel={selectedNovel}
            chapterIndex={currentChapterIndex}
            onBack={() => setCurrentView('home')}
            onSelectChapter={handleSelectChapter}
            onOpenTableOfContents={() => setIsChapterSidebarOpen(true)}
            onOpenAIToolsWithText={handleOpenAIToolsWithText}
            onOpenShareModal={handleOpenShare}
            readerSettings={readerSettings}
            onUpdateReaderSettings={handleUpdateReaderSettings}
            currentAudioParagraphIndex={speechPlayer.currentParagraphIndex}
            isAudioPlaying={speechPlayer.isPlaying && !speechPlayer.isPaused}
            onPlayParagraphFromReader={(idx) => speechPlayer.playParagraph(idx)}
          />
        )}
      </div>

      {/* Sticky Audio Player Bar (Show if on reader view or if audio is currently active) */}
      {(currentView === 'reader' || speechPlayer.isPlaying) && currentChapter && (
        <AudioPlayerBar
          novel={selectedNovel}
          chapter={currentChapter}
          paragraphs={currentParagraphs}
          currentParagraphIndex={speechPlayer.currentParagraphIndex}
          isPlaying={speechPlayer.isPlaying}
          isPaused={speechPlayer.isPaused}
          onTogglePlayPause={speechPlayer.togglePlayPause}
          onNextParagraph={speechPlayer.nextParagraph}
          onPrevParagraph={speechPlayer.prevParagraph}
          onNextChapter={handleNextChapter}
          onPrevChapter={handlePrevChapter}
          settings={speechPlayer.settings}
          onUpdateSettings={speechPlayer.updateSettings}
          sleepRemainingSeconds={speechPlayer.sleepRemainingSeconds}
          onOpenSleepTimer={() => setIsSleepTimerOpen(true)}
          availableVoices={speechPlayer.availableVoices}
        />
      )}

      {/* Modals & Drawers */}
      <ChapterSidebar
        isOpen={isChapterSidebarOpen}
        onClose={() => setIsChapterSidebarOpen(false)}
        novel={selectedNovel}
        currentChapterIndex={currentChapterIndex}
        onSelectChapter={handleSelectChapter}
        onOpenAddChapter={() => setIsAddChapterOpen(true)}
        onOpenBatchImport={() => setIsBatchImportOpen(true)}
        onOpenEditCover={setCoverEditNovel}
      />

      <AIToolsModal
        isOpen={isAIToolsOpen}
        onClose={() => setIsAIToolsOpen(false)}
        initialText={aiToolsText}
        initialMode={aiToolsMode}
        onApplyTranslation={handleApplyTranslationToCurrentChapter}
      />

      <BatchImportModal
        isOpen={isBatchImportOpen}
        onClose={() => setIsBatchImportOpen(false)}
        existingNovels={novels}
        currentNovelId={selectedNovel?.id}
        onImportAsNewNovel={handleImportAsNewNovel}
        onAppendToExistingNovel={handleAppendToExistingNovel}
      />

      <LibraryModal
        isOpen={isLibraryOpen}
        onClose={() => setIsLibraryOpen(false)}
        novels={novels}
        onSelectNovel={(n, idx) => {
          handleSelectNovel(n, idx || 0);
          setIsLibraryOpen(false);
        }}
        onOpenEditCover={setCoverEditNovel}
      />

      <CreateNovelModal
        isOpen={isCreateNovelOpen}
        onClose={() => setIsCreateNovelOpen(false)}
        onAddNovel={handleAddNovel}
        onOpenBatchImport={() => setIsBatchImportOpen(true)}
      />

      <AddChapterModal
        isOpen={isAddChapterOpen}
        onClose={() => setIsAddChapterOpen(false)}
        novel={selectedNovel}
        onAddChapter={handleAddChapter}
        onOpenBatchImport={() => setIsBatchImportOpen(true)}
      />

      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        readerSettings={readerSettings}
        onUpdateReaderSettings={handleUpdateReaderSettings}
        audioSettings={speechPlayer.settings}
        onUpdateAudioSettings={speechPlayer.updateSettings}
        availableVoices={speechPlayer.availableVoices}
      />

      <SleepTimerModal
        isOpen={isSleepTimerOpen}
        onClose={() => setIsSleepTimerOpen(false)}
        currentRemainingSeconds={speechPlayer.sleepRemainingSeconds}
        onSetTimer={speechPlayer.setSleepTimer}
      />

      <UserProfileModal
        isOpen={isProfileOpen}
        onClose={() => setIsProfileOpen(false)}
        userProfile={userProfile}
        onProfileUpdated={setUserProfile}
      />

      {shareData && (
        <SharePortalModal
          isOpen={!!shareData}
          onClose={() => setShareData(null)}
          quote={shareData.quote}
          novelTitle={shareData.novelTitle}
          chapterTitle={shareData.chapterTitle}
        />
      )}

      {/* Edit Cover Modal */}
      <EditCoverModal
        isOpen={!!coverEditNovel}
        onClose={() => setCoverEditNovel(null)}
        novel={coverEditNovel}
        onSaveCover={handleUpdateNovelCover}
      />

    </div>
  );
}
