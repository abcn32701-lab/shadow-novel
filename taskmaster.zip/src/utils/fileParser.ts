import * as pdfjsLib from 'pdfjs-dist';

// Configure pdfjs worker
if (typeof window !== 'undefined') {
  try {
    // Use worker from unpkg or cdnjs corresponding to pdfjs version
    pdfjsLib.GlobalWorkerOptions.workerSrc = `https://cdnjs.cloudflare.com/ajax/libs/pdf.js/${pdfjsLib.version}/pdf.worker.min.mjs`;
  } catch (e) {
    console.warn('Failed to set pdfjs workerSrc:', e);
  }
}

export interface ParsedChapterItem {
  chapterNumber: number;
  title: string;
  content: string;
  wordCount: number;
  originalLanguage?: 'zh' | 'th' | 'en' | 'mixed';
}

export interface NovelParseResult {
  detectedTitle: string;
  detectedAuthor: string;
  chapters: ParsedChapterItem[];
  totalWords: number;
  rawTextLength: number;
}

/**
 * Read text from .txt file with encoding support (UTF-8, GBK for Chinese novels, TIS-620 for Thai)
 */
export async function readTextFromFile(file: File, encoding: string = 'utf-8'): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      resolve((e.target?.result as string) || '');
    };
    reader.onerror = (err) => reject(err);
    reader.readAsText(file, encoding);
  });
}

/**
 * Extract text from .pdf file using pdfjs-dist with pure text stream fallback
 */
export async function extractTextFromPdf(file: File): Promise<string> {
  try {
    const arrayBuffer = await file.arrayBuffer();
    const loadingTask = pdfjsLib.getDocument({
      data: new Uint8Array(arrayBuffer),
      useSystemFonts: true,
    });

    const pdf = await loadingTask.promise;
    const numPages = pdf.numPages;
    const pagesText: string[] = [];

    for (let i = 1; i <= numPages; i++) {
      const page = await pdf.getPage(i);
      const textContent = await page.getTextContent();
      const pageStrings = textContent.items
        .map((item: any) => item.str || '')
        .join(' ');
      pagesText.push(pageStrings);
    }

    const fullText = pagesText.join('\n\n');
    if (fullText.trim().length > 0) {
      return fullText;
    }
  } catch (err) {
    console.warn('pdfjs-dist extraction encountered error, attempting fallback parser:', err);
  }

  // Fallback: extract text streams from PDF arrayBuffer if worker fails
  try {
    const buffer = await file.arrayBuffer();
    const textDecoder = new TextDecoder('utf-8');
    const rawPdf = textDecoder.decode(buffer);

    // Simple regex extraction of BT ... ET blocks in PDF
    const textMatches = rawPdf.match(/\(([^()]*)\)\s*Tj/g) || [];
    if (textMatches.length > 0) {
      return textMatches
        .map(m => m.replace(/^\(/, '').replace(/\)\s*Tj$/, ''))
        .join(' ');
    }
  } catch (fallbackErr) {
    console.error('Fallback PDF parser failed:', fallbackErr);
  }

  throw new Error('ไม่สามารถแยกข้อความจากไฟล์ PDF ได้ กรุณาลองใช้ไฟล์ .TXT หรือคัดลอกข้อความโดยตรง');
}

/**
 * Detect language of text
 */
export function detectLanguage(text: string): 'zh' | 'th' | 'en' | 'mixed' {
  const sample = text.slice(0, 2000);
  const zhMatches = sample.match(/[\u4e00-\u9fa5]/g)?.length || 0;
  const thMatches = sample.match(/[\u0e00-\u0e7f]/g)?.length || 0;
  const enMatches = sample.match(/[a-zA-Z]/g)?.length || 0;

  if (zhMatches > thMatches && zhMatches > enMatches) return 'zh';
  if (thMatches > zhMatches && thMatches > enMatches) return 'th';
  if (enMatches > zhMatches && enMatches > thMatches) return 'en';
  return 'mixed';
}

/**
 * Smart chapter splitter for Chinese, Thai, and English novel formats
 */
export function parseNovelFile(rawText: string, fallbackNovelTitle = 'นิยายนำเข้า'): NovelParseResult {
  const cleanText = rawText.replace(/\r\n/g, '\n').replace(/\r/g, '\n');

  // Try to detect Novel Title & Author from beginning of text
  const lines = cleanText.split('\n').map(l => l.trim()).filter(l => l.length > 0);
  let detectedTitle = fallbackNovelTitle;
  let detectedAuthor = 'ไม่ระบุนามปากกา';

  if (lines.length > 0) {
    const firstLine = lines[0];
    // Check if line 1 has 《书名》 or 《...》
    const bookNameMatch = firstLine.match(/《([^》]+)》/);
    if (bookNameMatch) {
      detectedTitle = bookNameMatch[1];
    } else if (firstLine.length < 40 && !firstLine.match(/^(?:第|ตอนที่|บทที่|Chapter)/i)) {
      detectedTitle = firstLine.replace(/^(?:书名|ชื่อเรื่อง|Title)[：:]\s*/i, '');
    }

    // Check author in first 5 lines
    for (let i = 0; i < Math.min(5, lines.length); i++) {
      const authorMatch = lines[i].match(/(?:作者|ผู้แต่ง|Author)[：:]\s*([^\s]+)/i);
      if (authorMatch) {
        detectedAuthor = authorMatch[1];
        break;
      }
    }
  }

  // Regex patterns for matching Chapter Headers:
  // 1. Chinese: 第X章, 第X节, 第X回, 第一章, 第一百二十章
  // 2. Thai: ตอนที่ X, บทที่ X
  // 3. English: Chapter X, Book X
  // 4. Numeric: 001. Title or 1. Title
  const chapterHeaderRegex = /(?:^|\n)\s*(?:(第\s*[0-90-9一二三四五六七八九十百千万]+\s*[章|节|回|卷|集|篇|折][^\n\r]*)|(ตอนที่\s*[0-9๑-๙]+[^\n\r]*)|(บทที่\s*[0-9๑-๙]+[^\n\r]*)|(Chapter\s*[0-9]+[^\n\r]*)|(Prologue[^\n\r]*)|(Epilogue[^\n\r]*)|((?:[0-9]{1,4}|[๑-๙]{1,4})[、. :：\s]+[^\n\r]{2,35}))/gi;

  const matches: Array<{ index: number; title: string }> = [];
  let match: RegExpExecArray | null;

  while ((match = chapterHeaderRegex.exec(cleanText)) !== null) {
    const headerTitle = match[0].trim();
    // Verify it's not too long to be a paragraph
    if (headerTitle.length < 80) {
      matches.push({
        index: match.index,
        title: headerTitle
      });
    }
  }

  const parsedChapters: ParsedChapterItem[] = [];

  if (matches.length >= 2) {
    // Multiple chapters found
    // If there is preamble before Chapter 1, include it if significant
    const firstMatchIdx = matches[0].index;
    if (firstMatchIdx > 200) {
      const prologueContent = cleanText.substring(0, firstMatchIdx).trim();
      if (prologueContent.length > 50) {
        parsedChapters.push({
          chapterNumber: 0,
          title: 'บทนำ (Prologue)',
          content: prologueContent,
          wordCount: countWords(prologueContent),
          originalLanguage: detectLanguage(prologueContent)
        });
      }
    }

    for (let i = 0; i < matches.length; i++) {
      const startIdx = matches[i].index;
      const endIdx = i < matches.length - 1 ? matches[i + 1].index : cleanText.length;
      const chunk = cleanText.substring(startIdx, endIdx).trim();

      // The first line of chunk is title, the rest is content
      const chunkLines = chunk.split('\n');
      const title = chunkLines[0].trim() || `ตอนที่ ${i + 1}`;
      const content = chunkLines.slice(1).join('\n').trim();

      parsedChapters.push({
        chapterNumber: parsedChapters.length + 1,
        title: cleanChapterTitle(title, parsedChapters.length + 1),
        content: content.length > 0 ? content : title,
        wordCount: countWords(content.length > 0 ? content : title),
        originalLanguage: detectLanguage(content)
      });
    }
  } else {
    // If no chapter headers detected, split by word count (approx 2,000 words or 8,000 chars per chapter)
    // or keep as 1-3 chapters
    const paragraphs = cleanText.split('\n\n').filter(p => p.trim().length > 0);
    if (paragraphs.length > 25) {
      // Split into batches of ~15-20 paragraphs
      const paragraphsPerChapter = 18;
      let chapNum = 1;

      for (let i = 0; i < paragraphs.length; i += paragraphsPerChapter) {
        const slice = paragraphs.slice(i, i + paragraphsPerChapter);
        const chapContent = slice.join('\n\n').trim();
        parsedChapters.push({
          chapterNumber: chapNum,
          title: `ตอนที่ ${chapNum}`,
          content: chapContent,
          wordCount: countWords(chapContent),
          originalLanguage: detectLanguage(chapContent)
        });
        chapNum++;
      }
    } else {
      // Single chapter
      parsedChapters.push({
        chapterNumber: 1,
        title: detectedTitle || 'ตอนที่ 1',
        content: cleanText,
        wordCount: countWords(cleanText),
        originalLanguage: detectLanguage(cleanText)
      });
    }
  }

  const totalWords = parsedChapters.reduce((acc, c) => acc + c.wordCount, 0);

  return {
    detectedTitle,
    detectedAuthor,
    chapters: parsedChapters,
    totalWords,
    rawTextLength: cleanText.length
  };
}

function cleanChapterTitle(rawTitle: string, fallbackNum: number): string {
  let t = rawTitle.replace(/^[#*\s-]+/, '').trim();
  if (!t) return `ตอนที่ ${fallbackNum}`;
  return t;
}

function countWords(text: string): number {
  const zhCount = text.match(/[\u4e00-\u9fa5]/g)?.length || 0;
  const thCount = text.match(/[\u0e00-\u0e7f]+/g)?.reduce((acc, word) => acc + Math.max(1, Math.ceil(word.length / 5)), 0) || 0;
  const enCount = text.match(/[a-zA-Z0-9_-]+/g)?.length || 0;
  return zhCount + thCount + enCount;
}
