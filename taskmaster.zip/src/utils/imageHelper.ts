// Generates consistent elegant SVG data URIs for novel covers
export function generateCoverSvg(title: string, genre: string, author: string, seed: string = '1'): string {
  const hash = (str: string) => {
    let h = 0;
    for (let i = 0; i < str.length; i++) {
      h = (Math.imul(31, h) + str.charCodeAt(i)) | 0;
    }
    return Math.abs(h);
  };

  const val = hash(title + seed);
  
  // Sophisticated palates based on genre
  const colorThemes = {
    xianxia: ['#0f172a', '#1e1b4b', '#0369a1', '#e0f2fe', '仙'],
    wuxia: ['#1c1917', '#451a03', '#9a3412', '#fef3c7', '武'],
    fantasy: ['#18181b', '#3b0764', '#7e22ce', '#fae8ff', '幻'],
    rebirth: ['#09090b', '#701a75', '#c026d3', '#fdf4ff', '生'],
    scifi: ['#022c22', '#064e3b', '#0d9488', '#ccfbf1', '科'],
    romance: ['#2e1065', '#831843', '#db2777', '#fce7f3', '情'],
    adventure: ['#14532d', '#15803d', '#166534', '#dcfce7', '行'],
    mystery: ['#09090b', '#1e293b', '#475569', '#f1f5f9', '秘'],
  };

  const themeKey = (genre in colorThemes ? genre : 'xianxia') as keyof typeof colorThemes;
  const [bgDark, bgMid, accent, textLight, kanji] = colorThemes[themeKey];

  // Truncate title for display
  const shortTitle = title.length > 18 ? title.slice(0, 16) + '...' : title;

  const svg = `
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 600" width="100%" height="100%">
  <defs>
    <linearGradient id="bgGrad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="${bgDark}" />
      <stop offset="50%" stop-color="${bgMid}" />
      <stop offset="100%" stop-color="#050505" />
    </linearGradient>
    <linearGradient id="goldGrad" x1="0%" y1="0%" x2="100%" y2="0%">
      <stop offset="0%" stop-color="#fbbf24" />
      <stop offset="50%" stop-color="#f59e0b" />
      <stop offset="100%" stop-color="#d97706" />
    </linearGradient>
    <radialGradient id="glow" cx="50%" cy="35%" r="45%">
      <stop offset="0%" stop-color="${accent}" stop-opacity="0.35" />
      <stop offset="100%" stop-color="${accent}" stop-opacity="0" />
    </radialGradient>
    <filter id="shadow" x="-10%" y="-10%" width="120%" height="120%">
      <feDropShadow dx="0" dy="4" stdDeviation="6" flood-color="#000" flood-opacity="0.6" />
    </filter>
  </defs>

  <!-- Background -->
  <rect width="400" height="600" fill="url(#bgGrad)" />
  <circle cx="200" cy="220" r="180" fill="url(#glow)" />

  <!-- Traditional Ornamental Borders -->
  <rect x="18" y="18" width="364" height="564" fill="none" stroke="${accent}" stroke-width="1.2" stroke-opacity="0.35" rx="4" />
  <rect x="24" y="24" width="352" height="552" fill="none" stroke="#fbbf24" stroke-width="0.8" stroke-opacity="0.25" rx="2" />
  
  <!-- Corner Ornaments -->
  <path d="M 28 40 L 40 40 L 40 28" fill="none" stroke="#fbbf24" stroke-width="1.5" stroke-opacity="0.6"/>
  <path d="M 372 40 L 360 40 L 360 28" fill="none" stroke="#fbbf24" stroke-width="1.5" stroke-opacity="0.6"/>
  <path d="M 28 560 L 40 560 L 40 572" fill="none" stroke="#fbbf24" stroke-width="1.5" stroke-opacity="0.6"/>
  <path d="M 372 560 L 360 560 L 360 572" fill="none" stroke="#fbbf24" stroke-width="1.5" stroke-opacity="0.6"/>

  <!-- Mystic Circle / Halo -->
  <circle cx="200" cy="220" r="110" fill="none" stroke="${accent}" stroke-width="1" stroke-opacity="0.25" stroke-dasharray="4 6"/>
  <circle cx="200" cy="220" r="85" fill="none" stroke="#fbbf24" stroke-width="1.2" stroke-opacity="0.3"/>

  <!-- Giant Atmospheric Chinese Character Behind -->
  <text x="200" y="270" font-family="'Cinzel', serif, cursive" font-size="140" fill="${textLight}" opacity="0.07" text-anchor="middle" font-weight="bold">${kanji}</text>

  <!-- Traditional Red Seal Stamp -->
  <g transform="translate(305, 55)">
    <rect width="36" height="42" fill="#991b1b" rx="4" stroke="#f87171" stroke-width="1" opacity="0.85" />
    <text x="18" y="28" font-family="serif" font-size="18" fill="#fef2f2" text-anchor="middle" font-weight="bold">真傳</text>
  </g>

  <!-- Genre Badge -->
  <g transform="translate(48, 55)">
    <rect width="70" height="24" fill="#000" rx="12" stroke="${accent}" stroke-width="1" opacity="0.7" />
    <text x="83" y="71" font-family="sans-serif" font-size="11" fill="#e2e8f0" text-anchor="middle" font-weight="600" letter-spacing="1">${genre.toUpperCase()}</text>
  </g>

  <!-- Title Section -->
  <g filter="url(#shadow)">
    <text x="200" y="375" font-family="'Noto Serif Thai', 'Cinzel', serif" font-size="24" font-weight="bold" fill="url(#goldGrad)" text-anchor="middle" letter-spacing="1.5">
      ${escapeXml(shortTitle)}
    </text>
  </g>

  <!-- Divider Line -->
  <path d="M 120 405 L 185 405 M 215 405 L 280 405" stroke="#fbbf24" stroke-width="1" stroke-opacity="0.5" />
  <polygon points="200,401 205,405 200,409 195,405" fill="#fbbf24" fill-opacity="0.8" />

  <!-- Author Details -->
  <text x="200" y="445" font-family="'Sarabun', sans-serif" font-size="14" fill="#94a3b8" text-anchor="middle" font-weight="500">
    ผู้แต่ง: ${escapeXml(author || 'นิรนาม')}
  </text>

  <text x="200" y="525" font-family="'Cinzel', serif" font-size="11" fill="#64748b" text-anchor="middle" letter-spacing="3" opacity="0.8">
    NOVELIA DIGITAL STUDIO
  </text>
</svg>
  `.trim();

  return `data:image/svg+xml;utf8,${encodeURIComponent(svg)}`;
}

function escapeXml(unsafe: string): string {
  return unsafe
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;');
}

/**
 * Process and compress an uploaded image file into a standardized 2:3 ratio novel cover
 * Returns a clean, lightweight data URL that safely persists in localStorage.
 */
export function processCoverImageFile(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    if (!file.type.startsWith('image/')) {
      reject(new Error('ไฟล์ที่เลือกไม่ใช่รูปภาพ กรุณาเลือกไฟล์รูปภาพ เช่น PNG, JPG หรือ WebP'));
      return;
    }

    const reader = new FileReader();
    reader.onload = (e) => {
      const img = new Image();
      img.onload = () => {
        // Standard novel cover ratio 2:3 (600x900)
        const targetWidth = 600;
        const targetHeight = 900;
        const canvas = document.createElement('canvas');
        canvas.width = targetWidth;
        canvas.height = targetHeight;
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          resolve(e.target?.result as string);
          return;
        }

        // Draw with cover crop (centered)
        const hRatio = targetWidth / img.width;
        const vRatio = targetHeight / img.height;
        const ratio = Math.max(hRatio, vRatio);
        const centerShift_x = (targetWidth - img.width * ratio) / 2;
        const centerShift_y = (targetHeight - img.height * ratio) / 2;

        ctx.fillStyle = '#0a0a0a';
        ctx.fillRect(0, 0, targetWidth, targetHeight);
        ctx.drawImage(
          img,
          0,
          0,
          img.width,
          img.height,
          centerShift_x,
          centerShift_y,
          img.width * ratio,
          img.height * ratio
        );

        // Convert to optimized JPEG data URL
        const dataUrl = canvas.toDataURL('image/jpeg', 0.85);
        resolve(dataUrl);
      };
      img.onerror = () => {
        reject(new Error('ไม่สามารถโหลดรูปภาพที่เลือกได้'));
      };
      img.src = e.target?.result as string;
    };
    reader.onerror = () => reject(new Error('เกิดข้อผิดพลาดในการอ่านไฟล์จากอุปกรณ์'));
    reader.readAsDataURL(file);
  });
}

/**
 * Curated artistic book cover presets for various genres
 */
export const PRESET_COVERS: Array<{ id: string; name: string; genre: string; url: string }> = [
  {
    id: 'preset_xianxia_mountains',
    name: 'หุบเขาเซียนเมฆา',
    genre: 'เทพเซียน / กำลังภายใน',
    url: 'https://images.unsplash.com/photo-1506744038136-46273834b3fb?w=600&auto=format&fit=crop&q=80'
  },
  {
    id: 'preset_wuxia_temple',
    name: 'อารามยุทธภพโบราณ',
    genre: 'ยุทธภพ / กำลังภายใน',
    url: 'https://images.unsplash.com/photo-1545569341-9eb8b30979d9?w=600&auto=format&fit=crop&q=80'
  },
  {
    id: 'preset_magic_forest',
    name: 'ป่าเวทมนตร์เรืองแสง',
    genre: 'แฟนตาซีเวทมนตร์',
    url: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=600&auto=format&fit=crop&q=80'
  },
  {
    id: 'preset_starry_rebirth',
    name: 'แสงดวงดาราย้อนกาล',
    genre: 'เกิดใหม่ / ย้อนเวลา',
    url: 'https://images.unsplash.com/photo-1506703719100-a0f3a48c0f86?w=600&auto=format&fit=crop&q=80'
  },
  {
    id: 'preset_cyber_scifi',
    name: 'มหานครไซเบอร์ล้ำยุค',
    genre: 'ไซไฟ / ล้ำยุค',
    url: 'https://images.unsplash.com/photo-1508739773434-c26b3d09e071?w=600&auto=format&fit=crop&q=80'
  },
  {
    id: 'preset_sakura_romance',
    name: 'สายลมกลีบซากุระ',
    genre: 'โรแมนติก / ยุทธภพ',
    url: 'https://images.unsplash.com/photo-1522383225653-ed111181a951?w=600&auto=format&fit=crop&q=80'
  }
];
