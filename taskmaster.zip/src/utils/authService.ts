import { Bookmark, ReadingHistoryItem, UserProfile } from '../types';

const STORAGE_KEY = 'novelia_user_profile_v1';

const DEFAULT_PROFILE: UserProfile = {
  id: 'guest_user',
  name: 'นักอ่านแดนเซียน',
  avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
  bio: 'ผู้แสวงหาวิถีแห่งการบำเพ็ญผ่านตัวอักษรและเสียงบรรยาย',
  isGuest: true,
  favorites: ['novel_1', 'novel_2'],
  history: [],
  bookmarks: [],
  stats: {
    minutesRead: 45,
    chaptersCompleted: 3,
    currentStreakDays: 2,
    lastActiveDate: new Date().toISOString().split('T')[0]
  }
};

export const authService = {
  getProfile(): UserProfile {
    try {
      const data = localStorage.getItem(STORAGE_KEY);
      if (data) {
        return JSON.parse(data);
      }
    } catch {
      // fallback
    }
    return DEFAULT_PROFILE;
  },

  saveProfile(profile: UserProfile): void {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(profile));
    } catch (e) {
      console.warn('Failed to save profile to localStorage:', e);
    }
  },

  updateName(name: string, bio?: string): UserProfile {
    const profile = this.getProfile();
    profile.name = name;
    if (bio !== undefined) profile.bio = bio;
    this.saveProfile(profile);
    return profile;
  },

  toggleFavorite(novelId: string): boolean {
    const profile = this.getProfile();
    const index = profile.favorites.indexOf(novelId);
    let isFav = false;
    if (index >= 0) {
      profile.favorites.splice(index, 1);
      isFav = false;
    } else {
      profile.favorites.push(novelId);
      isFav = true;
    }
    this.saveProfile(profile);
    return isFav;
  },

  isFavorite(novelId: string): boolean {
    const profile = this.getProfile();
    return profile.favorites.includes(novelId);
  },

  updateReadingHistory(novelId: string, chapterId: string, chapterNumber: number, paragraphIndex: number, progressPercent: number): void {
    const profile = this.getProfile();
    const existingIndex = profile.history.findIndex(h => h.novelId === novelId);
    
    const historyItem: ReadingHistoryItem = {
      novelId,
      chapterId,
      chapterNumber,
      paragraphIndex,
      progressPercent,
      lastReadAt: new Date().toISOString()
    };

    if (existingIndex >= 0) {
      profile.history[existingIndex] = historyItem;
    } else {
      profile.history.unshift(historyItem);
    }

    // Keep top 30 history items
    if (profile.history.length > 30) {
      profile.history = profile.history.slice(0, 30);
    }

    // Update streak if new day
    const today = new Date().toISOString().split('T')[0];
    if (profile.stats.lastActiveDate !== today) {
      profile.stats.currentStreakDays += 1;
      profile.stats.lastActiveDate = today;
    }

    this.saveProfile(profile);
  },

  addReadingTime(minutes: number): void {
    const profile = this.getProfile();
    profile.stats.minutesRead += minutes;
    this.saveProfile(profile);
  },

  incrementCompletedChapters(): void {
    const profile = this.getProfile();
    profile.stats.chaptersCompleted += 1;
    this.saveProfile(profile);
  },

  addBookmark(bookmark: Omit<Bookmark, 'id' | 'createdAt'>): Bookmark {
    const profile = this.getProfile();
    const newBookmark: Bookmark = {
      ...bookmark,
      id: 'bm_' + Date.now() + '_' + Math.random().toString(36).substring(2, 7),
      createdAt: new Date().toISOString()
    };
    profile.bookmarks.unshift(newBookmark);
    this.saveProfile(profile);
    return newBookmark;
  },

  removeBookmark(bookmarkId: string): void {
    const profile = this.getProfile();
    profile.bookmarks = profile.bookmarks.filter(b => b.id !== bookmarkId);
    this.saveProfile(profile);
  }
};
