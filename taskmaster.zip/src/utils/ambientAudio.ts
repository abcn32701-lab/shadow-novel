import { AmbientSoundType } from '../types';

class AmbientSoundEngine {
  private ctx: AudioContext | null = null;
  private currentType: AmbientSoundType = 'none';
  private masterGain: GainNode | null = null;
  private isRunning: boolean = false;
  private activeNodes: Array<AudioNode | number> = [];

  private initContext() {
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.ctx = new AudioCtx();
      this.masterGain = this.ctx.createGain();
      this.masterGain.connect(this.ctx.destination);
    }
    if (this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  public setVolume(volume: number) {
    if (this.masterGain && this.ctx) {
      this.masterGain.gain.setTargetAtTime(Math.max(0, Math.min(1, volume)), this.ctx.currentTime, 0.05);
    }
  }

  public play(type: AmbientSoundType, volume: number = 0.4) {
    this.stop();
    if (type === 'none') {
      this.currentType = 'none';
      return;
    }

    try {
      this.initContext();
      if (!this.ctx || !this.masterGain) return;
      this.setVolume(volume);
      this.currentType = type;
      this.isRunning = true;

      switch (type) {
        case 'rain':
          this.startRain();
          break;
        case 'waves':
          this.startWaves();
          break;
        case 'fireplace':
          this.startFireplace();
          break;
        case 'zen_bamboo':
          this.startZenBamboo();
          break;
        case 'night_forest':
          this.startNightForest();
          break;
        case 'cafe':
          this.startCafe();
          break;
      }
    } catch (e) {
      console.warn('AudioContext not allowed or failed:', e);
    }
  }

  public stop() {
    this.isRunning = false;
    this.activeNodes.forEach(node => {
      if (typeof node === 'number') {
        window.clearInterval(node);
      } else {
        try {
          if ('stop' in node && typeof (node as AudioScheduledSourceNode).stop === 'function') {
            (node as AudioScheduledSourceNode).stop();
          }
          node.disconnect();
        } catch {
          // ignore cleanup errors
        }
      }
    });
    this.activeNodes = [];
    this.currentType = 'none';
  }

  public getCurrentType(): AmbientSoundType {
    return this.currentType;
  }

  // --- Ambient Generators ---

  private createNoiseBuffer(duration = 3): AudioBuffer {
    if (!this.ctx) throw new Error('No audio context');
    const bufferSize = this.ctx.sampleRate * duration;
    const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
    const data = buffer.getChannelData(0);
    let lastOut = 0.0;
    // Pink noise approximation
    for (let i = 0; i < bufferSize; i++) {
      const white = Math.random() * 2 - 1;
      data[i] = (lastOut + 0.02 * white) / 1.02;
      lastOut = data[i];
    }
    return buffer;
  }

  private startRain() {
    if (!this.ctx || !this.masterGain) return;

    // Background steady rain hiss
    const noiseBuffer = this.createNoiseBuffer(4);
    const noiseSource = this.ctx.createBufferSource();
    noiseSource.buffer = noiseBuffer;
    noiseSource.loop = true;

    const filter = this.ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.value = 850;

    const rainGain = this.ctx.createGain();
    rainGain.gain.value = 0.35;

    noiseSource.connect(filter);
    filter.connect(rainGain);
    rainGain.connect(this.masterGain);
    noiseSource.start();

    this.activeNodes.push(noiseSource, filter, rainGain);

    // Occasional gentle water drops
    const dropTimer = window.setInterval(() => {
      if (!this.ctx || !this.isRunning || !this.masterGain) return;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      const now = this.ctx.currentTime;
      const freq = 1200 + Math.random() * 800;

      osc.frequency.setValueAtTime(freq, now);
      osc.frequency.exponentialRampToValueAtTime(300, now + 0.08);

      gain.gain.setValueAtTime(0.04 + Math.random() * 0.04, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.08);

      osc.connect(gain);
      gain.connect(this.masterGain);
      osc.start(now);
      osc.stop(now + 0.09);
    }, 280);

    this.activeNodes.push(dropTimer);
  }

  private startWaves() {
    if (!this.ctx || !this.masterGain) return;

    const noiseBuffer = this.createNoiseBuffer(5);
    const noiseSource = this.ctx.createBufferSource();
    noiseSource.buffer = noiseBuffer;
    noiseSource.loop = true;

    const filter = this.ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.value = 400;

    const gain = this.ctx.createGain();
    gain.gain.value = 0.2;

    noiseSource.connect(filter);
    filter.connect(gain);
    gain.connect(this.masterGain);
    noiseSource.start();

    this.activeNodes.push(noiseSource, filter, gain);

    // Modulation of ocean surge
    const lfo = this.ctx.createOscillator();
    lfo.frequency.value = 0.12; // wave every ~8 seconds
    const lfoGain = this.ctx.createGain();
    lfoGain.gain.value = 250;
    lfo.connect(lfoGain);
    lfoGain.connect(filter.frequency);
    lfo.start();

    this.activeNodes.push(lfo, lfoGain);
  }

  private startFireplace() {
    if (!this.ctx || !this.masterGain) return;

    // Low rumble
    const noiseBuffer = this.createNoiseBuffer(3);
    const noise = this.ctx.createBufferSource();
    noise.buffer = noiseBuffer;
    noise.loop = true;

    const filter = this.ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.value = 280;

    const lowGain = this.ctx.createGain();
    lowGain.gain.value = 0.25;

    noise.connect(filter);
    filter.connect(lowGain);
    lowGain.connect(this.masterGain);
    noise.start();

    this.activeNodes.push(noise, filter, lowGain);

    // Random crackles
    const crackleTimer = window.setInterval(() => {
      if (!this.ctx || !this.isRunning || !this.masterGain) return;
      if (Math.random() > 0.4) {
        const now = this.ctx.currentTime;
        const popOsc = this.ctx.createOscillator();
        const popGain = this.ctx.createGain();
        popOsc.frequency.setValueAtTime(200 + Math.random() * 800, now);
        popGain.gain.setValueAtTime(0.06 + Math.random() * 0.08, now);
        popGain.gain.exponentialRampToValueAtTime(0.001, now + 0.03);

        popOsc.connect(popGain);
        popGain.connect(this.masterGain);
        popOsc.start(now);
        popOsc.stop(now + 0.035);
      }
    }, 180);

    this.activeNodes.push(crackleTimer);
  }

  private startZenBamboo() {
    if (!this.ctx || !this.masterGain) return;

    // Wind and soft harmonic hum
    const osc1 = this.ctx.createOscillator();
    const osc2 = this.ctx.createOscillator();
    const droneGain = this.ctx.createGain();

    osc1.frequency.value = 174; // solfeggio healing tone
    osc2.frequency.value = 285;
    droneGain.gain.value = 0.06;

    osc1.connect(droneGain);
    osc2.connect(droneGain);
    droneGain.connect(this.masterGain);
    osc1.start();
    osc2.start();

    this.activeNodes.push(osc1, osc2, droneGain);

    // Bamboo water clack (Shishi-odoshi) every few seconds
    const clackTimer = window.setInterval(() => {
      if (!this.ctx || !this.isRunning || !this.masterGain) return;
      const now = this.ctx.currentTime;
      const clackOsc = this.ctx.createOscillator();
      const clackGain = this.ctx.createGain();

      clackOsc.type = 'triangle';
      clackOsc.frequency.setValueAtTime(540, now);
      clackOsc.frequency.exponentialRampToValueAtTime(120, now + 0.12);

      clackGain.gain.setValueAtTime(0.18, now);
      clackGain.gain.exponentialRampToValueAtTime(0.001, now + 0.2);

      clackOsc.connect(clackGain);
      clackGain.connect(this.masterGain);
      clackOsc.start(now);
      clackOsc.stop(now + 0.25);
    }, 6000 + Math.random() * 3000);

    this.activeNodes.push(clackTimer);
  }

  private startNightForest() {
    if (!this.ctx || !this.masterGain) return;

    // Soft high pitch crickets
    const cricketTimer = window.setInterval(() => {
      if (!this.ctx || !this.isRunning || !this.masterGain) return;
      const now = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.frequency.setValueAtTime(4600 + Math.sin(now * 10) * 200, now);
      gain.gain.setValueAtTime(0.02, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.1);

      osc.connect(gain);
      gain.connect(this.masterGain);
      osc.start(now);
      osc.stop(now + 0.11);
    }, 240);

    this.activeNodes.push(cricketTimer);
  }

  private startCafe() {
    if (!this.ctx || !this.masterGain) return;

    const noiseBuffer = this.createNoiseBuffer(4);
    const noise = this.ctx.createBufferSource();
    noise.buffer = noiseBuffer;
    noise.loop = true;

    const filter = this.ctx.createBiquadFilter();
    filter.type = 'bandpass';
    filter.frequency.value = 500;
    filter.Q.value = 0.8;

    const gain = this.ctx.createGain();
    gain.gain.value = 0.18;

    noise.connect(filter);
    filter.connect(gain);
    gain.connect(this.masterGain);
    noise.start();

    this.activeNodes.push(noise, filter, gain);
  }
}

export const ambientAudio = new AmbientSoundEngine();
