export function splitIntoParagraphs(content: string): string[] {
  if (!content) return [];
  
  // Normalize line endings
  const normalized = content.replace(/\r\n/g, '\n').replace(/\r/g, '\n');
  
  // Split by double line breaks or single line breaks with indentation
  const rawParagraphs = normalized.split(/\n\s*\n/);
  
  const paragraphs: string[] = [];
  
  for (const raw of rawParagraphs) {
    const trimmed = raw.trim();
    if (trimmed.length > 0) {
      // Check if this block contains multiple lines that look like individual dialogue lines
      const subLines = trimmed.split('\n').map(l => l.trim()).filter(l => l.length > 0);
      if (subLines.length > 1 && subLines.some(l => l.startsWith('"') || l.startsWith('“') || l.startsWith('「') || l.startsWith('-'))) {
        paragraphs.push(...subLines);
      } else {
        paragraphs.push(trimmed);
      }
    }
  }

  return paragraphs.length > 0 ? paragraphs : [content];
}

export function estimateReadingTime(text: string): { minutes: number; wordCount: number } {
  if (!text) return { minutes: 1, wordCount: 0 };
  
  // For Thai and Asian languages, character count / 4 is a standard proxy for words
  const thaiOrAsianChars = (text.match(/[\u0E00-\u0E7F\u4E00-\u9FFF]/g) || []).length;
  const englishWords = (text.match(/[a-zA-Z0-9_-]+/g) || []).length;
  
  const totalEstimatedWords = Math.round(englishWords + (thaiOrAsianChars / 4));
  // Average reading speed ~ 220 words/minute
  const minutes = Math.max(1, Math.ceil(totalEstimatedWords / 220));
  
  return { minutes, wordCount: totalEstimatedWords };
}

export function detectChapterTitle(text: string): { chapterNumber?: number; title: string; body: string } {
  const lines = text.trim().split('\n').map(l => l.trim()).filter(l => l.length > 0);
  if (lines.length === 0) return { title: 'บทใหม่', body: '' };

  const firstLine = lines[0];
  // Match patterns like "ตอนที่ 1: กำเนิด", "บทที่ 12 ...", "Chapter 1: ...", "第1章 ..."
  const match = firstLine.match(/^(ตอนที่|บทที่|Chapter|第)\s*(\d+)\s*[:：\-]?\s*(.*)$/i);
  
  if (match) {
    const num = parseInt(match[2], 10);
    const titleText = match[3]?.trim() || `ตอนที่ ${num}`;
    const body = lines.slice(1).join('\n\n');
    return { chapterNumber: num, title: titleText, body };
  }

  // If first line is short (< 50 chars) assume it's the title
  if (firstLine.length < 50 && lines.length > 1) {
    return { title: firstLine, body: lines.slice(1).join('\n\n') };
  }

  return { title: 'บทใหม่', body: text };
}

/**
 * Cleans and sanitizes paragraph text for the Web Speech API TTS engine.
 * Strips out markdown syntax, excessive punctuation, and symbols that can cause
 * TTS engines to hang, stall, or read awkward characters (like multiple dots).
 */
export function cleanTextForSpeech(text: string): string {
  if (!text) return '';
  let cleaned = text;

  // Remove markdown headers, bold, italics, dividers
  cleaned = cleaned.replace(/^[#*>\s\-=_]{3,}/gm, ' ');
  cleaned = cleaned.replace(/[*_~`]{1,3}/g, '');

  // Replace multiple periods, dots, ellipses with a single natural pause comma
  cleaned = cleaned.replace(/[.]{2,}/g, ', ');
  cleaned = cleaned.replace(/[…]{1,}/g, ', ');
  cleaned = cleaned.replace(/[-]{2,}/g, ', ');
  cleaned = cleaned.replace(/[—]{1,}/g, ', ');

  // Normalize repeated exclamation and question marks
  cleaned = cleaned.replace(/[!]{2,}/g, '!');
  cleaned = cleaned.replace(/[?]{2,}/g, '?');

  // Remove unwanted brackets or symbols that cause speech glitches
  cleaned = cleaned.replace(/[「」『』《》]/g, ' ');

  // Collapse multiple whitespaces into a single space
  cleaned = cleaned.replace(/\s+/g, ' ').trim();

  return cleaned;
}

