import { CultivationTerm } from '../types';

export const CULTIVATION_TERMS: CultivationTerm[] = [
  // ลำดับขั้นพลัง (Cultivation Realms)
  {
    chinese: '炼气',
    pinyin: 'Liàn Qì',
    thai: 'กำเนิดลมปราณ (เลี่ยนชี่)',
    meaning: 'ขั้นเริ่มต้นของการบำเพ็ญเพียร ผู้ฝึกจะเริ่มสัมผัสและชักนำพลังฟ้าดินเข้าสู่ร่าง ชำระเส้นชีพจร มีทั้งหมด 9-10 ระดับย่อย',
    category: 'realm'
  },
  {
    chinese: '筑基',
    pinyin: 'Zhù Jī',
    thai: 'สร้างรากฐาน (จู้จี)',
    meaning: 'การหลอมรวมลมปราณในจุดตันเถียนให้ควบแน่นเปลี่ยนเป็นของเหลว ร่างกายกลายเป็นกายกึ่งเซียน มีอายุขัยยืนยาวถึงสองร้อยปี',
    category: 'realm'
  },
  {
    chinese: '金丹',
    pinyin: 'Jīn Dān',
    thai: 'แก่นทองคำ (จินตาน)',
    meaning: 'ของเหลวลมปราณควบแน่นกลายเป็นเม็ดแก่นทองคำสุกสกาวในจุดตันเถียน ก้าวสู่ความเป็นผู้มีพลังอำนาจที่แท้จริง เหาะเหินเดินอากาศได้อย่างอิสระ อายุขัยราวห้าร้อยปี',
    category: 'realm'
  },
  {
    chinese: '元婴',
    pinyin: 'Yuán Yīng',
    thai: 'ก่อกำเนิดวิญญาณ (หยวนอิง)',
    meaning: 'แก่นทองคำแตกออกก่อกำเนิดเป็นทารกวิญญาณ หากร่างกายเนื้อถูกทำลาย วิญญาณหยวนอิงยังสามารถหนีและเข้าสิงร่างใหม่ได้ อายุขัยนับพันปี',
    category: 'realm'
  },
  {
    chinese: '化神',
    pinyin: 'Huà Shén',
    thai: 'แปลงวิญญาณ / เทพแปลง (ฮว่าเสิน)',
    meaning: 'หยวนอิงหลอมรวมกับพลังวิญญาณสวรรค์ สามารถหยิบยืมพลังแห่งกฎเกณฑ์ธรรมชาติได้ อายุขัยหลายพันปี เป็นยอดฝีมือระดับบรรพชนของทวีป',
    category: 'realm'
  },
  {
    chinese: '渡劫',
    pinyin: 'Dù Jié',
    thai: 'ข้ามภัยพิบัติ (ตู้เจี๋ย)',
    meaning: 'ขั้นสูงสุดในโลกมนุษย์ ต้องรับทัณฑ์อัสนีบาตสวรรค์เก้าสาย หากผ่านไปได้จะก้าวข้ามสู่ดินแดนเซียนที่แท้จริง',
    category: 'realm'
  },
  
  // ศัพท์กายวิภาคและพลัง (Anatomy & Energy)
  {
    chinese: '丹田',
    pinyin: 'Dān Tián',
    thai: 'ตันเถียน (จุดรวมลมปราณ)',
    meaning: 'ศูนย์กลางสะสมพลังปราณในร่างกายมนุษย์ แบ่งเป็น ตันเถียนล่าง (ใต้สะดือ), ตันเถียนกลาง (หน้าอก), และตันเถียนบน (หว่างคิ้ว)',
    category: 'general'
  },
  {
    chinese: '走火入魔',
    pinyin: 'Zǒu Huǒ Rù Mó',
    thai: 'ลมปราณแตกซ่าน / ธาตุไฟแตกซ่าน',
    meaning: 'ภาวะที่พลังปราณในร่างกายควบคุมไม่ได้ ไหลย้อนกลับหรือทะลักออกนอกเส้นชีพจร มักเกิดจากจิตใจมีปมในอดีตหรือฝืนบำเพ็ญ อาจทำให้พิการหรือกลายเป็นปีศาจ',
    category: 'general'
  },
  {
    chinese: '经脉',
    pinyin: 'Jīng Mài',
    thai: 'เส้นชีพจร',
    meaning: 'เส้นทางไหลเวียนของพลังปราณทั่วร่างกาย ผู้มีเส้นชีพจรวิญญาณบริสุทธิ์จะซึมซับพลังฟ้าดินได้รวดเร็วกว่าผู้อื่นหลายเท่า',
    category: 'general'
  },
  {
    chinese: '神识',
    pinyin: 'Shén Shí',
    thai: 'ญาณหยั่งรู้ / จิตสัมผัส (เสินสือ)',
    meaning: 'พลังคลื่นความรู้สึกที่แผ่ออกไปภายนอก สามารถตรวจจับสิ่งรอบตัว มองทะลุกำแพง และสื่อสารทางจิตได้โดยไม่ต้องใช้สายตา',
    category: 'general'
  },

  // คำสรรพนามและความสัมพันธ์ (Titles & Relations)
  {
    chinese: '道友',
    pinyin: 'Dào Yǒu',
    thai: 'สหายเต๋า (เต้าโหย่ว)',
    meaning: 'คำเรียกผู้ร่วมเดินทางบนวิถีแห่งการบำเพ็ญเซียน ใช้เรียกผู้บำเพ็ญเพียรในระดับเดียวกันด้วยความสุภาพ',
    category: 'title'
  },
  {
    chinese: '师尊',
    pinyin: 'Shī Zūn',
    thai: 'ซือจุน / ซือฝุ (อาจารย์ผู้เคารพ)',
    meaning: 'คำยกย่องเรียกอาจารย์ผู้ถ่ายทอดวิชา เปรียบเสมือนบิดาผู้ให้กำเนิดในวิถีเซียน',
    category: 'title'
  },
  {
    chinese: '师兄 / 师姐',
    pinyin: 'Shī Xiōng / Shī Jiě',
    thai: 'ซือซยง (ศิษย์พี่ชาย) / ซือเจี่ย (ศิษย์พี่หญิง)',
    meaning: 'ผู้ร่วมสำนักที่เข้าศึกษาก่อน หรือได้รับการยอมรับในลำดับอาวุโสสูงกว่า',
    category: 'title'
  },
  {
    chinese: '老祖',
    pinyin: 'Lǎo Zǔ',
    thai: 'บรรพชน / เหล่าจู่',
    meaning: 'ผู้ก่อตั้งสำนักหรือผู้อาวุโสสูงสุดที่ยังมีชีวิต มักเก็บตัวฝึกตนในถ้ำลึก ไม่ยุ่งเกี่ยวกับเรื่องราวทางโลกเว้นแต่เกิดภัยพิบัติร้ายแรง',
    category: 'title'
  },

  // ยุทธภพและสิ่งของ (Items & Sects)
  {
    chinese: '储物袋',
    pinyin: 'Chǔ Wù Dài',
    thai: 'ถุงมิติมนต์ตรา (ถุงเฉียนคุน)',
    meaning: 'ถุงเก็บของที่มีมิติเวทมนตร์ภายใน สามารถบรรจุสิ่งของขนาดใหญ่ได้มากมาย แต่มีน้ำหนักเบาดั่งขนนก',
    category: 'item'
  },
  {
    chinese: '灵石',
    pinyin: 'Líng Shí',
    thai: 'หินวิญญาณ (หลิงสือ)',
    meaning: 'แร่ธาตุธรรมชาติที่อัดแน่นด้วยพลังฟ้าดิน ใช้เป็นทั้งเงินตราแลกเปลี่ยนในโลกเซียน และใช้ดูดซับเพื่อเพิ่มพูนระดับการฝึกตน',
    category: 'item'
  },
  {
    chinese: '灵丹妙药',
    pinyin: 'Líng Dān Miào Yào',
    thai: 'โอสถวิเศษ',
    meaning: 'เม็ดยาที่หลอมขึ้นจากสมุนไพรวิญญาณพันปีโดยนักหลอมโอสถ มีผลตั้งแต่รักษาแผลลึกทะลุอวัยวะภายใน ไปจนถึงช่วยทะลวงคอขวดระดับพลัง',
    category: 'item'
  },
  {
    chinese: '飞剑',
    pinyin: 'Fēi Jiàn',
    thai: 'กระบี่บิน',
    meaning: 'กระบี่วิญญาณที่ผู้บำเพ็ญหลอมรวมด้วยโลหิต สามารถควบคุมด้วยจิตเพื่อสังหารศัตรูจากระยะไกลนับร้อยลี้ หรือใช้ยืนเหาะเหินข้ามขุนเขา',
    category: 'item'
  },
  {
    chinese: '秘境',
    pinyin: 'Mì Jìng',
    thai: 'แดนลับ / แดนศักดิ์สิทธิ์โบราณ',
    meaning: 'มิติแยกตัวที่หลงเหลือจากยุคโบราณ เต็มไปด้วยสมุนไพรหายาก สัตว์อสูรดุร้าย และซากมรดกของมหาเซียนที่ล่วงลับ',
    category: 'general'
  }
];

// Helper to find terms within a paragraph
export function annotateNovelText(text: string): { text: string; matchedTerms: CultivationTerm[] } {
  const matchedTerms: CultivationTerm[] = [];
  
  for (const term of CULTIVATION_TERMS) {
    // Check Thai term, Pinyin, or Chinese
    const regex = new RegExp(`(${term.thai.split(' ')[0]}|${term.chinese})`, 'g');
    if (regex.test(text)) {
      if (!matchedTerms.some(t => t.chinese === term.chinese)) {
        matchedTerms.push(term);
      }
    }
  }

  return { text, matchedTerms };
}

export function searchCultivationTerms(query: string): CultivationTerm[] {
  if (!query.trim()) return CULTIVATION_TERMS;
  const q = query.toLowerCase().trim();
  return CULTIVATION_TERMS.filter(
    item =>
      item.thai.toLowerCase().includes(q) ||
      item.pinyin.toLowerCase().includes(q) ||
      item.chinese.includes(q) ||
      item.meaning.toLowerCase().includes(q)
  );
}
