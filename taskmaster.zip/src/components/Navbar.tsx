import React, { useState } from 'react';
import { 
  BookOpen, 
  Search, 
  Bookmark, 
  Sparkles, 
  PlusCircle, 
  Settings, 
  Volume2, 
  VolumeX, 
  Flame,
  User,
  Headphones,
  FileUp
} from 'lucide-react';
import { UserProfile, AmbientSoundType } from '../types';

interface NavbarProps {
  currentView: 'home' | 'reader';
  onNavigateHome: () => void;
  searchQuery: string;
  onSearchChange: (q: string) => void;
  onOpenLibrary: () => void;
  onOpenAITools: () => void;
  onOpenCreateNovel: () => void;
  onOpenBatchImport?: () => void;
  onOpenSettings: () => void;
  onOpenProfile: () => void;
  userProfile: UserProfile;
  ambientSound: AmbientSoundType;
  isAudioPlaying: boolean;
  onToggleAudioPlayer: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentView,
  onNavigateHome,
  searchQuery,
  onSearchChange,
  onOpenLibrary,
  onOpenAITools,
  onOpenCreateNovel,
  onOpenBatchImport,
  onOpenSettings,
  onOpenProfile,
  userProfile,
  ambientSound,
  isAudioPlaying,
  onToggleAudioPlayer
}) => {
  const [showMobileSearch, setShowMobileSearch] = useState(false);

  return (
    <header className="sticky top-0 z-40 w-full border-b border-neutral-800/80 bg-neutral-950/85 backdrop-blur-md transition-colors">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
        
        {/* Logo & Brand */}
        <div className="flex items-center gap-6">
          <button 
            onClick={onNavigateHome}
            className="group flex items-center gap-3 text-left focus:outline-none"
            aria-label="Novelia Home"
          >
            <div className="relative flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-tr from-amber-600 via-amber-500 to-yellow-400 text-neutral-950 shadow-md shadow-amber-500/20 transition-transform group-hover:scale-105">
              <BookOpen className="h-5 w-5 stroke-[2.2]" />
              <span className="absolute -bottom-1 -right-1 flex h-4 w-4 items-center justify-center rounded-full bg-neutral-900 text-[10px] font-bold text-amber-400 ring-1 ring-amber-500/50">
                仙
              </span>
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-serif text-xl font-bold tracking-tight text-neutral-100 group-hover:text-amber-400 transition-colors">
                  Novelia
                </span>
                <span className="rounded bg-amber-500/15 px-1.5 py-0.5 text-[10px] font-semibold text-amber-400">
                  Audio
                </span>
              </div>
              <p className="hidden text-[11px] font-medium text-neutral-400 sm:block">
                เว็บอ่าน & ฟังนิยายเสียงอัจฉริยะ
              </p>
            </div>
          </button>
        </div>

        {/* Search Bar - Desktop */}
        <div className="hidden flex-1 max-w-md mx-8 md:block">
          <div className="relative">
            <Search className="absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-neutral-500" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => onSearchChange(e.target.value)}
              placeholder="ค้นหาชื่อนิยาย, ตัวละคร, ปรมาจารย์กระบี่, ย้อนเวลา..."
              className="w-full rounded-full border border-neutral-800 bg-neutral-900/90 py-2 pl-10 pr-4 text-sm text-neutral-200 placeholder-neutral-500 transition-all focus:border-amber-500/60 focus:bg-neutral-900 focus:outline-none focus:ring-2 focus:ring-amber-500/20"
            />
            {searchQuery && (
              <button
                onClick={() => onSearchChange('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-neutral-500 hover:text-neutral-300"
              >
                ล้าง
              </button>
            )}
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Mobile Search Toggle */}
          <button
            onClick={() => setShowMobileSearch(!showMobileSearch)}
            className="flex h-9 w-9 items-center justify-center rounded-lg border border-neutral-800 text-neutral-400 hover:border-neutral-700 hover:text-neutral-200 md:hidden"
            aria-label="ค้นหา"
          >
            <Search className="h-4 w-4" />
          </button>

          {/* AI Tools Studio */}
          <button
            onClick={onOpenAITools}
            className="flex items-center gap-1.5 rounded-lg border border-purple-500/30 bg-purple-500/10 px-3 py-1.5 text-xs font-semibold text-purple-300 transition-all hover:bg-purple-500/20 hover:border-purple-500/50"
          >
            <Sparkles className="h-3.5 w-3.5 text-purple-400" />
            <span className="hidden sm:inline">AI Studio</span>
          </button>

          {/* Bookshelf / Library */}
          <button
            onClick={onOpenLibrary}
            className="relative flex items-center gap-1.5 rounded-lg border border-neutral-800 bg-neutral-900 px-3 py-1.5 text-xs font-medium text-neutral-300 transition-colors hover:border-neutral-700 hover:text-neutral-100"
          >
            <Bookmark className="h-3.5 w-3.5 text-amber-500" />
            <span className="hidden sm:inline">ชั้นหนังสือ</span>
            {userProfile.favorites.length > 0 && (
              <span className="ml-0.5 flex h-4 min-w-4 items-center justify-center rounded-full bg-amber-500 px-1 text-[10px] font-bold text-neutral-950">
                {userProfile.favorites.length}
              </span>
            )}
          </button>

          {/* Batch Import TXT/PDF */}
          {onOpenBatchImport && (
            <button
              onClick={onOpenBatchImport}
              className="flex items-center gap-1.5 rounded-lg border border-amber-500/30 bg-amber-500/10 px-3 py-1.5 text-xs font-semibold text-amber-300 transition-colors hover:bg-amber-500/20 hover:border-amber-500/50"
              title="นำเข้านิยายหลายตอนจากไฟล์ .TXT หรือ .PDF"
            >
              <FileUp className="h-3.5 w-3.5 text-amber-400" />
              <span className="hidden sm:inline">นำเข้าไฟล์</span>
            </button>
          )}

          {/* Create Novel */}
          <button
            onClick={onOpenCreateNovel}
            className="flex items-center gap-1.5 rounded-lg border border-neutral-800 bg-neutral-900 px-3 py-1.5 text-xs font-medium text-neutral-300 transition-colors hover:border-neutral-700 hover:text-neutral-100"
          >
            <PlusCircle className="h-3.5 w-3.5 text-emerald-400" />
            <span className="hidden sm:inline">เพิ่มนิยาย</span>
          </button>

          {/* Audio Indicator */}
          {isAudioPlaying && (
            <button
              onClick={onToggleAudioPlayer}
              className="flex items-center gap-1.5 rounded-lg border border-amber-500/40 bg-amber-500/15 px-2.5 py-1.5 text-xs font-medium text-amber-300 animate-pulse"
              title="กำลังเล่นเสียงอ่าน"
            >
              <Headphones className="h-3.5 w-3.5" />
              <span className="hidden lg:inline text-[11px]">กำลังอ่าน</span>
            </button>
          )}

          {/* Ambient Sound Indicator */}
          {ambientSound !== 'none' && (
            <div className="flex items-center gap-1 rounded-full bg-emerald-950/60 px-2 py-1 text-[11px] font-medium text-emerald-400 border border-emerald-500/30">
              <Volume2 className="h-3 w-3" />
              <span className="capitalize hidden lg:inline">{ambientSound}</span>
            </div>
          )}

          {/* Settings Modal Button */}
          <button
            onClick={onOpenSettings}
            className="flex h-9 w-9 items-center justify-center rounded-lg border border-neutral-800 text-neutral-400 transition-colors hover:border-neutral-700 hover:text-neutral-200"
            aria-label="ตั้งค่า"
          >
            <Settings className="h-4 w-4" />
          </button>

          {/* User Profile Pill */}
          <button
            onClick={onOpenProfile}
            className="flex items-center gap-2 rounded-full border border-neutral-800 bg-neutral-900 p-1 pr-2.5 text-xs font-medium text-neutral-300 transition-colors hover:border-amber-500/50 hover:bg-neutral-850"
          >
            <img
              src={userProfile.avatar}
              alt={userProfile.name}
              className="h-6 w-6 rounded-full object-cover ring-1 ring-amber-500/40"
            />
            <span className="hidden sm:inline max-w-[80px] truncate">{userProfile.name}</span>
            {userProfile.stats.currentStreakDays > 0 && (
              <span className="flex items-center text-[11px] text-orange-400 font-bold">
                <Flame className="h-3 w-3 mr-0.5 fill-orange-400 text-orange-400" />
                {userProfile.stats.currentStreakDays}
              </span>
            )}
          </button>
        </div>
      </div>

      {/* Mobile Search Input */}
      {showMobileSearch && (
        <div className="border-t border-neutral-800 bg-neutral-950 p-3 md:hidden">
          <div className="relative">
            <Search className="absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-neutral-500" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => onSearchChange(e.target.value)}
              placeholder="ค้นหาชื่อนิยาย, ตัวละคร, หมวดหมู่..."
              className="w-full rounded-lg border border-neutral-800 bg-neutral-900 py-2 pl-10 pr-4 text-sm text-neutral-200 focus:border-amber-500 focus:outline-none"
              autoFocus
            />
          </div>
        </div>
      )}
    </header>
  );
};
