import React, { useState } from 'react';
import { Novel, NovelGenre } from '../types';
import { 
  Play, 
  BookOpen, 
  Star, 
  Eye, 
  Clock, 
  Bookmark, 
  Flame, 
  Sparkles, 
  Compass, 
  ArrowRight,
  FileUp,
  Camera
} from 'lucide-react';
import { authService } from '../utils/authService';

interface HomeNovelListProps {
  novels: Novel[];
  onSelectNovel: (novel: Novel, chapterIndex?: number) => void;
  onPlayAudioNovel: (novel: Novel, chapterIndex?: number) => void;
  searchQuery: string;
  onOpenBatchImport?: () => void;
  onOpenEditCover?: (novel: Novel) => void;
}

const GENRE_LABELS: Record<string, string> = {
  all: 'ทั้งหมด',
  xianxia: 'กำลังภายใน / เทพเซียน',
  fantasy: 'แฟนตาซีเวทมนตร์',
  rebirth: 'เกิดใหม่ / หวนคืน',
  scifi: 'ไซไฟ / ล้ำยุค',
  adventure: 'ผจญภัย / ท่องโลก',
  romance: 'โรแมนติก / ยุทธภพ'
};

export const HomeNovelList: React.FC<HomeNovelListProps> = ({
  novels,
  onSelectNovel,
  onPlayAudioNovel,
  searchQuery,
  onOpenBatchImport,
  onOpenEditCover
}) => {
  const [selectedGenre, setSelectedGenre] = useState<string>('all');
  const [favoriteIds, setFavoriteIds] = useState<string[]>(() => authService.getProfile().favorites);

  const handleToggleFavorite = (e: React.MouseEvent, novelId: string) => {
    e.stopPropagation();
    const isFav = authService.toggleFavorite(novelId);
    setFavoriteIds(prev => isFav ? [...prev, novelId] : prev.filter(id => id !== novelId));
  };

  // Filter novels by search and genre
  const filteredNovels = novels.filter(novel => {
    const matchesGenre = selectedGenre === 'all' || novel.genre === selectedGenre;
    const query = searchQuery.toLowerCase().trim();
    const matchesSearch = !query || 
      novel.titleThai.toLowerCase().includes(query) ||
      novel.title.toLowerCase().includes(query) ||
      novel.author.toLowerCase().includes(query) ||
      novel.description.toLowerCase().includes(query) ||
      novel.tags.some(t => t.toLowerCase().includes(query));

    return matchesGenre && matchesSearch;
  });

  // Featured novel (first one or highest rated)
  const featuredNovel = novels[0];

  return (
    <div className="space-y-10 pb-20">
      
      {/* Hero Featured Section - Only when no search */}
      {!searchQuery && featuredNovel && (
        <section className="relative overflow-hidden rounded-3xl border border-neutral-800 bg-gradient-to-b from-neutral-900 via-neutral-950 to-neutral-950 p-6 sm:p-10 shadow-2xl">
          {/* Subtle Ambient Background glow */}
          <div className="absolute -left-20 -top-20 h-80 w-80 rounded-full bg-amber-500/10 blur-3xl pointer-events-none" />
          <div className="absolute right-0 top-0 h-96 w-96 rounded-full bg-indigo-500/10 blur-3xl pointer-events-none" />

          <div className="relative z-10 flex flex-col items-center gap-8 lg:flex-row lg:items-start lg:gap-12">
            
            {/* Book Cover */}
            <div className="relative group shrink-0">
              <div className="w-52 sm:w-60 overflow-hidden rounded-2xl border border-neutral-700/60 shadow-2xl shadow-black/80 transition-transform duration-300 group-hover:scale-105 relative">
                <img
                  src={featuredNovel.coverImage}
                  alt={featuredNovel.titleThai}
                  className="h-auto w-full object-cover"
                />
                {onOpenEditCover && (
                  <button
                    onClick={() => onOpenEditCover(featuredNovel)}
                    className="absolute inset-0 bg-black/50 backdrop-blur-xs flex flex-col items-center justify-center gap-1.5 text-amber-300 opacity-0 group-hover:opacity-100 transition-opacity font-medium text-xs"
                    title="เปลี่ยนรูปปกนิยายเรื่องนี้"
                  >
                    <div className="p-2 rounded-full bg-neutral-900/80 border border-amber-500/40 text-amber-400">
                      <Camera className="h-5 w-5" />
                    </div>
                    <span>คลิกเปลี่ยนรูปปก</span>
                  </button>
                )}
              </div>
              <span className="absolute -top-2 -left-2 flex items-center gap-1 rounded-full bg-amber-500 px-2.5 py-0.5 text-xs font-bold text-neutral-950 shadow-md">
                <Flame className="h-3.5 w-3.5 fill-current" />
                แนะนำยอดนิยม
              </span>
            </div>

            {/* Novel Info & Description */}
            <div className="flex-1 text-center lg:text-left">
              <div className="flex flex-wrap items-center justify-center gap-2 lg:justify-start">
                <span className="rounded-full bg-neutral-800/80 px-3 py-1 text-xs font-semibold text-amber-400 border border-neutral-700">
                  {GENRE_LABELS[featuredNovel.genre] || featuredNovel.genre}
                </span>
                <span className="flex items-center gap-1 text-xs font-medium text-amber-400">
                  <Star className="h-3.5 w-3.5 fill-amber-400" />
                  {featuredNovel.rating.toFixed(1)} ({featuredNovel.ratingCount.toLocaleString()} คะแนน)
                </span>
                <span className="flex items-center gap-1 text-xs text-neutral-400">
                  <Eye className="h-3.5 w-3.5" />
                  {featuredNovel.views.toLocaleString()} อ่าน
                </span>
              </div>

              <h1 className="mt-4 font-serif text-2xl sm:text-3xl lg:text-4xl font-extrabold text-neutral-100 tracking-tight">
                {featuredNovel.titleThai}
              </h1>
              <p className="mt-1 font-serif text-sm italic text-neutral-400">
                {featuredNovel.title} {featuredNovel.originalTitle && `(${featuredNovel.originalTitle})`}
              </p>

              <p className="mt-4 text-sm sm:text-base leading-relaxed text-neutral-300 line-clamp-3 lg:line-clamp-4 max-w-3xl">
                {featuredNovel.description}
              </p>

              {/* Tags */}
              <div className="mt-4 flex flex-wrap justify-center gap-1.5 lg:justify-start">
                {featuredNovel.tags.map(tag => (
                  <span
                    key={tag}
                    className="rounded-md bg-neutral-900 px-2.5 py-1 text-xs font-medium text-neutral-400 border border-neutral-800"
                  >
                    #{tag}
                  </span>
                ))}
              </div>

              {/* Action Buttons */}
              <div className="mt-6 flex flex-wrap items-center justify-center gap-4 lg:justify-start">
                <button
                  onClick={() => onSelectNovel(featuredNovel, 0)}
                  className="flex items-center gap-2 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 px-6 py-3 text-sm font-bold text-neutral-950 shadow-lg shadow-amber-500/20 transition-all hover:brightness-110 hover:shadow-amber-500/30 active:scale-95"
                >
                  <BookOpen className="h-4 w-4 stroke-[2.5]" />
                  เริ่มอ่านตอนที่ 1
                </button>

                <button
                  onClick={() => onPlayAudioNovel(featuredNovel, 0)}
                  className="flex items-center gap-2 rounded-xl border border-neutral-700 bg-neutral-900/90 px-5 py-3 text-sm font-semibold text-neutral-200 transition-colors hover:border-amber-500/60 hover:bg-neutral-800 active:scale-95"
                >
                  <Play className="h-4 w-4 fill-current text-amber-400" />
                  ฟังเสียงนิยาย
                </button>

                <button
                  onClick={(e) => handleToggleFavorite(e, featuredNovel.id)}
                  className={`flex h-11 w-11 items-center justify-center rounded-xl border transition-colors ${
                    favoriteIds.includes(featuredNovel.id)
                      ? 'border-amber-500/50 bg-amber-500/10 text-amber-400'
                      : 'border-neutral-800 bg-neutral-900 text-neutral-400 hover:text-neutral-200'
                  }`}
                  aria-label="เพิ่มเข้าชั้นหนังสือ"
                >
                  <Bookmark className={`h-4 w-4 ${favoriteIds.includes(featuredNovel.id) ? 'fill-current' : ''}`} />
                </button>

                {onOpenEditCover && (
                  <button
                    onClick={() => onOpenEditCover(featuredNovel)}
                    className="flex items-center gap-2 rounded-xl border border-neutral-700 bg-neutral-900/90 px-4 py-3 text-sm font-semibold text-neutral-300 transition-colors hover:border-amber-500/60 hover:text-amber-400 hover:bg-neutral-800 active:scale-95"
                    title="เปลี่ยนรูปปกนิยายเรื่องนี้"
                  >
                    <Camera className="h-4 w-4 text-amber-400" />
                    เปลี่ยนรูปปก
                  </button>
                )}
              </div>

            </div>
          </div>
        </section>
      )}

      {/* Genre Filter Bar */}
      <section className="space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <Compass className="h-5 w-5 text-amber-400" />
            <h2 className="text-lg sm:text-xl font-bold text-neutral-100 font-serif">
              สำรวจคลังนิยายทั้งหมด
            </h2>
          </div>
          
          <div className="flex items-center gap-3">
            {onOpenBatchImport && (
              <button
                onClick={onOpenBatchImport}
                className="flex items-center gap-1.5 rounded-xl border border-amber-500/30 bg-amber-500/10 px-3 py-1.5 text-xs font-semibold text-amber-300 hover:bg-amber-500/20 hover:border-amber-500/50 transition-all"
              >
                <FileUp className="h-3.5 w-3.5 text-amber-400" />
                <span>นำเข้าไฟล์หลายตอน (.TXT / .PDF)</span>
              </button>
            )}
            <span className="text-xs text-neutral-400 hidden sm:inline">
              พบ {filteredNovels.length} เรื่อง
            </span>
          </div>
        </div>

        {/* Categories Chips */}
        <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-none">
          {Object.entries(GENRE_LABELS).map(([key, label]) => (
            <button
              key={key}
              onClick={() => setSelectedGenre(key)}
              className={`shrink-0 rounded-full px-4 py-2 text-xs font-semibold transition-all ${
                selectedGenre === key
                  ? 'bg-amber-500 text-neutral-950 shadow-md shadow-amber-500/20'
                  : 'bg-neutral-900 text-neutral-400 border border-neutral-800 hover:border-neutral-700 hover:text-neutral-200'
              }`}
            >
              {label}
            </button>
          ))}
        </div>
      </section>

      {/* Novel Cards Grid */}
      <section>
        {filteredNovels.length === 0 ? (
          <div className="rounded-2xl border border-neutral-800 bg-neutral-900/50 p-12 text-center">
            <BookOpen className="mx-auto h-12 w-12 text-neutral-600 stroke-[1.5]" />
            <h3 className="mt-4 text-base font-semibold text-neutral-200">ไม่พบนิยายที่ตรงกับการค้นหา</h3>
            <p className="mt-1 text-sm text-neutral-500">ลองเปลี่ยนคำค้นหาหรือเลือกหมวดหมู่อื่นดูสิ</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {filteredNovels.map(novel => {
              const isFav = favoriteIds.includes(novel.id);
              return (
                <div
                  key={novel.id}
                  onClick={() => onSelectNovel(novel, 0)}
                  className="group relative flex flex-col overflow-hidden rounded-2xl border border-neutral-800/80 bg-neutral-900/70 p-4 transition-all duration-300 hover:-translate-y-1 hover:border-amber-500/40 hover:bg-neutral-900 hover:shadow-xl hover:shadow-amber-500/5 cursor-pointer"
                >
                  {/* Cover with hover play button */}
                  <div className="relative aspect-[2/3] w-full overflow-hidden rounded-xl bg-neutral-950">
                    <img
                      src={novel.coverImage}
                      alt={novel.titleThai}
                      className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
                    />

                    {/* Bookmark Toggle Overlay */}
                    <button
                      onClick={(e) => handleToggleFavorite(e, novel.id)}
                      className={`absolute top-2 right-2 flex h-8 w-8 items-center justify-center rounded-full backdrop-blur-md transition-colors ${
                        isFav ? 'bg-amber-500 text-neutral-950' : 'bg-neutral-900/70 text-neutral-300 hover:text-white'
                      }`}
                      aria-label="บันทึกเรื่องนี้"
                    >
                      <Bookmark className={`h-4 w-4 ${isFav ? 'fill-current' : ''}`} />
                    </button>

                    {/* Change Cover Quick Overlay Button */}
                    {onOpenEditCover && (
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onOpenEditCover(novel);
                        }}
                        className="absolute top-2 left-2 flex h-8 w-8 items-center justify-center rounded-full bg-neutral-950/80 backdrop-blur-md text-neutral-300 hover:text-amber-400 hover:bg-neutral-900 transition-all opacity-80 sm:opacity-0 sm:group-hover:opacity-100 shadow-md border border-neutral-700/50"
                        title="เปลี่ยนรูปปกนิยายเรื่องนี้"
                        aria-label="เปลี่ยนรูปปกนิยาย"
                      >
                        <Camera className="h-3.5 w-3.5" />
                      </button>
                    )}

                    {/* Quick Play overlay button */}
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onPlayAudioNovel(novel, 0);
                      }}
                      className="absolute bottom-3 right-3 flex h-10 w-10 items-center justify-center rounded-full bg-amber-500 text-neutral-950 shadow-lg shadow-black/60 transition-transform duration-200 hover:scale-110 active:scale-95"
                      title="เริ่มฟังเสียงบรรยาย"
                    >
                      <Play className="h-5 w-5 fill-current ml-0.5" />
                    </button>

                    {/* Status badge */}
                    <div className="absolute bottom-3 left-3 rounded bg-neutral-950/80 px-2 py-0.5 text-[10px] font-semibold text-neutral-300 backdrop-blur-sm">
                      {novel.status === 'completed' ? 'จบแล้ว' : 'ยังไม่จบ'}
                    </div>
                  </div>

                  {/* Details */}
                  <div className="mt-3 flex flex-1 flex-col justify-between">
                    <div>
                      <div className="flex items-center gap-1.5 text-xs text-neutral-400">
                        <span className="text-amber-400 font-semibold flex items-center gap-0.5">
                          <Star className="h-3 w-3 fill-amber-400" />
                          {novel.rating.toFixed(1)}
                        </span>
                        <span>•</span>
                        <span>{novel.chapters.length} ตอน</span>
                      </div>

                      <h3 className="mt-1.5 font-serif text-base font-bold text-neutral-100 group-hover:text-amber-400 transition-colors line-clamp-1">
                        {novel.titleThai}
                      </h3>

                      <p className="mt-1 text-xs text-neutral-400 line-clamp-2 leading-relaxed">
                        {novel.description}
                      </p>
                    </div>

                    <div className="mt-3 pt-3 border-t border-neutral-800/80 flex items-center justify-between text-xs text-neutral-500">
                      <span>แต่งโดย: {novel.author}</span>
                      <span className="flex items-center text-amber-500 font-medium group-hover:translate-x-0.5 transition-transform">
                        อ่าน <ArrowRight className="h-3 w-3 ml-1" />
                      </span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </section>
    </div>
  );
};
