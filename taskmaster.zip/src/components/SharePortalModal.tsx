import React, { useState } from 'react';
import { Share2, X, Copy, Check, Sparkles } from 'lucide-react';

interface SharePortalModalProps {
  isOpen: boolean;
  onClose: () => void;
  novelTitle: string;
  chapterTitle: string;
  quote: string;
}

export const SharePortalModal: React.FC<SharePortalModalProps> = ({
  isOpen,
  onClose,
  novelTitle,
  chapterTitle,
  quote
}) => {
  const [copied, setCopied] = useState(false);
  const [selectedTheme, setSelectedTheme] = useState<'gold' | 'ink' | 'emerald'>('gold');

  if (!isOpen) return null;

  const cardThemes = {
    gold: 'from-neutral-900 via-neutral-950 to-neutral-900 border-amber-500/40 text-neutral-100',
    ink: 'from-zinc-900 via-black to-zinc-950 border-neutral-700 text-neutral-200',
    emerald: 'from-emerald-950 via-neutral-950 to-emerald-950 border-emerald-500/40 text-emerald-100'
  };

  const handleCopyText = () => {
    const textToShare = `“${quote}”\n\n— จากเรื่อง: ${novelTitle} (${chapterTitle})\nอ่านต่อได้ที่ Novelia WebNovel Studio`;
    navigator.clipboard.writeText(textToShare);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4">
      <div 
        className="w-full max-w-lg rounded-3xl border border-neutral-800 bg-neutral-950 p-6 text-neutral-100 shadow-2xl flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between pb-3 border-b border-neutral-800">
          <div className="flex items-center gap-2">
            <Share2 className="h-5 w-5 text-amber-400" />
            <h2 className="text-base font-bold font-serif">แชร์การ์ดคำคมนิยาย (Share Quote)</h2>
          </div>
          <button onClick={onClose} className="p-1.5 rounded-lg text-neutral-400 hover:text-white">
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Theme select */}
        <div className="flex gap-2 my-4">
          {[
            { id: 'gold', label: 'สุวรรณทิพย์ (Gold)' },
            { id: 'ink', label: 'หมึกดำคราม (Ink)' },
            { id: 'emerald', label: 'หยกมรกต (Jade)' },
          ].map(t => (
            <button
              key={t.id}
              onClick={() => setSelectedTheme(t.id as any)}
              className={`flex-1 py-1.5 rounded-lg text-xs font-semibold border transition-all ${
                selectedTheme === t.id
                  ? 'border-amber-500 bg-amber-500/20 text-amber-300'
                  : 'border-neutral-800 bg-neutral-900 text-neutral-400'
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>

        {/* Quote Card Preview */}
        <div className={`rounded-2xl border p-6 bg-gradient-to-br shadow-xl relative overflow-hidden ${cardThemes[selectedTheme]}`}>
          <div className="absolute top-3 right-4 font-serif text-3xl opacity-15 text-amber-500 font-bold">
            “
          </div>
          
          <p className="font-serif text-sm sm:text-base leading-relaxed italic text-neutral-100">
            "{quote || 'เมื่อข้าก้าวข้ามแดนสวรรค์ เลือดของพวกเจ้าจะเป็นสิ่งแรกที่เซ่นไหว้คมกระบี่ของข้า!'}"
          </p>

          <div className="mt-6 pt-4 border-t border-neutral-700/50 flex items-center justify-between text-xs">
            <div>
              <p className="font-bold text-amber-400 font-serif">{novelTitle}</p>
              <p className="text-[11px] text-neutral-400">{chapterTitle}</p>
            </div>
            <span className="text-[10px] tracking-widest uppercase font-mono text-neutral-500">
              NOVELIA
            </span>
          </div>
        </div>

        <div className="mt-6 flex justify-end gap-3">
          <button
            onClick={handleCopyText}
            className="flex items-center gap-2 rounded-xl bg-amber-500 px-5 py-2 text-xs font-bold text-neutral-950 hover:bg-amber-400 shadow-lg shadow-amber-500/20"
          >
            {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
            {copied ? 'คัดลอกข้อความแล้ว' : 'คัดลอกข้อความพร้อมที่มา'}
          </button>
        </div>
      </div>
    </div>
  );
};
