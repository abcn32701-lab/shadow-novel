import React, { useState, useRef } from 'react';
import { Novel, Chapter, NovelGenre } from '../types';
import { 
  FileUp, 
  FileText, 
  X, 
  Check, 
  AlertCircle, 
  BookOpen, 
  Loader2, 
  Layers, 
  Sparkles, 
  Trash2, 
  Edit3, 
  FolderPlus,
  ArrowRight
} from 'lucide-react';
import { readTextFromFile, extractTextFromPdf, parseNovelFile, ParsedChapterItem, NovelParseResult } from '../utils/fileParser';
import { generateCoverSvg } from '../utils/imageHelper';

interface BatchImportModalProps {
  isOpen: boolean;
  onClose: () => void;
  existingNovels: Novel[];
  currentNovelId?: string;
  onImportAsNewNovel: (novel: Novel) => void;
  onAppendToExistingNovel: (novelId: string, chapters: Chapter[]) => void;
}

export const BatchImportModal: React.FC<BatchImportModalProps> = ({
  isOpen,
  onClose,
  existingNovels,
  currentNovelId,
  onImportAsNewNovel,
  onAppendToExistingNovel
}) => {
  const [activeTab, setActiveTab] = useState<'upload' | 'paste'>('upload');
  const [importMode, setImportMode] = useState<'new_novel' | 'append'>('new_novel');
  const [selectedTargetNovelId, setSelectedTargetNovelId] = useState<string>(currentNovelId || existingNovels[0]?.id || '');
  
  // File upload state
  const [isParsing, setIsParsing] = useState(false);
  const [parseError, setParseError] = useState('');
  const [rawPastedText, setRawPastedText] = useState('');
  const [encoding, setEncoding] = useState('utf-8');
  const [parseResult, setParseResult] = useState<NovelParseResult | null>(null);
  
  // Editable fields for novel creation
  const [novelTitle, setNovelTitle] = useState('');
  const [authorName, setAuthorName] = useState('');
  const [genre, setGenre] = useState<NovelGenre>('xianxia');
  const [description, setDescription] = useState('');
  const [chaptersList, setChaptersList] = useState<ParsedChapterItem[]>([]);

  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const handleProcessRawText = (text: string, defaultName = 'นิยายนำเข้า') => {
    try {
      setIsParsing(true);
      setParseError('');
      
      const result = parseNovelFile(text, defaultName);
      if (!result.chapters || result.chapters.length === 0) {
        throw new Error('ไม่พบเนื้อหาหรือตอนในไฟล์ที่ระบุ');
      }

      setParseResult(result);
      setNovelTitle(result.detectedTitle);
      setAuthorName(result.detectedAuthor);
      setChaptersList(result.chapters);
      setDescription(`นิยายนำเข้าจำนวน ${result.chapters.length} ตอน (${result.totalWords.toLocaleString()} คำ)`);
    } catch (err: any) {
      setParseError(err.message || 'เกิดข้อผิดพลาดในการแยกบทนิยาย');
    } finally {
      setIsParsing(false);
    }
  };

  const handleFileUpload = async (file: File) => {
    setIsParsing(true);
    setParseError('');
    try {
      const fileNameWithoutExt = file.name.replace(/\.[^/.]+$/, '');
      let text = '';

      if (file.name.toLowerCase().endsWith('.pdf')) {
        text = await extractTextFromPdf(file);
      } else {
        // .txt or plain text
        text = await readTextFromFile(file, encoding);
      }

      if (!text.trim()) {
        throw new Error('ไฟล์ว่างเปล่า หรือไม่สามารถอ่านข้อความได้');
      }

      handleProcessRawText(text, fileNameWithoutExt);
    } catch (err: any) {
      console.error('File import error:', err);
      setParseError(err.message || 'ไม่สามารถเปิดไฟล์นี้ได้');
    } finally {
      setIsParsing(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      handleFileUpload(e.dataTransfer.files[0]);
    }
  };

  const handleDeleteChapter = (idx: number) => {
    setChaptersList(prev => prev.filter((_, i) => i !== idx));
  };

  const handleUpdateChapterTitle = (idx: number, newTitle: string) => {
    setChaptersList(prev => prev.map((c, i) => i === idx ? { ...c, title: newTitle } : c));
  };

  const handleConfirmImport = () => {
    if (chaptersList.length === 0) {
      setParseError('ไม่มีตอนที่จะนำเข้า');
      return;
    }

    if (importMode === 'new_novel') {
      const novelId = 'novel_' + Date.now();
      const finalTitle = novelTitle.trim() || 'นิยายนำเข้า';
      const cover = generateCoverSvg(finalTitle, genre, authorName || 'นักเขียนนิรนาม', String(Date.now()));

      const formattedChapters: Chapter[] = chaptersList.map((ch, idx) => ({
        id: `chap_${novelId}_${idx + 1}_${Date.now()}`,
        novelId,
        chapterNumber: idx + 1,
        title: ch.title,
        content: ch.content,
        wordCount: ch.wordCount,
        publishedAt: new Date().toISOString().split('T')[0]
      }));

      const newNovel: Novel = {
        id: novelId,
        title: finalTitle,
        titleThai: finalTitle,
        author: authorName.trim() || 'ไม่ระบุนามปากกา',
        coverImage: cover,
        description: description.trim() || `นิยายนำเข้า ${formattedChapters.length} ตอน`,
        genre,
        tags: [genre, 'นำเข้าไฟล์', chaptersList[0]?.originalLanguage === 'zh' ? 'นิยายจีน' : 'นิยายแปล'],
        status: 'ongoing',
        rating: 5.0,
        ratingCount: 1,
        views: 0,
        createdAt: new Date().toISOString().split('T')[0],
        updatedAt: new Date().toISOString().split('T')[0],
        chapters: formattedChapters
      };

      onImportAsNewNovel(newNovel);
    } else {
      // Append to existing novel
      const targetNovel = existingNovels.find(n => n.id === selectedTargetNovelId);
      if (!targetNovel) {
        setParseError('กรุณาเลือกนิยายเป้าหมายที่ต้องการเพิ่มตอน');
        return;
      }

      const currentChapCount = targetNovel.chapters.length;
      const formattedChapters: Chapter[] = chaptersList.map((ch, idx) => ({
        id: `chap_${targetNovel.id}_${currentChapCount + idx + 1}_${Date.now()}`,
        novelId: targetNovel.id,
        chapterNumber: currentChapCount + idx + 1,
        title: ch.title,
        content: ch.content,
        wordCount: ch.wordCount,
        publishedAt: new Date().toISOString().split('T')[0]
      }));

      onAppendToExistingNovel(targetNovel.id, formattedChapters);
    }

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4">
      <div 
        className="w-full max-w-3xl rounded-3xl border border-neutral-800 bg-neutral-950 p-6 text-neutral-100 shadow-2xl flex flex-col max-h-[90vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Header */}
        <div className="flex items-center justify-between pb-4 border-b border-neutral-800">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-amber-500/15 text-amber-400 border border-amber-500/30">
              <Layers className="h-5 w-5" />
            </div>
            <div>
              <h2 className="text-base font-bold font-serif">นำเข้านิยายหลายตอน (.TXT / .PDF)</h2>
              <p className="text-xs text-neutral-400">
                ระบบแยกตอนอัตโนมัติ รองรับนิยายจีน (第X章), นิยายไทย (ตอนที่ X), และภาษาอังกฤษ
              </p>
            </div>
          </div>
          <button onClick={onClose} className="p-1.5 rounded-lg text-neutral-400 hover:text-white">
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Step 1: Input area (if no parsed result yet) */}
        {!parseResult ? (
          <div className="flex-1 overflow-y-auto mt-4 space-y-4">
            
            {/* Tabs for Upload vs Paste */}
            <div className="flex border-b border-neutral-800">
              <button
                onClick={() => setActiveTab('upload')}
                className={`flex-1 py-2.5 text-xs font-bold border-b-2 flex items-center justify-center gap-2 ${
                  activeTab === 'upload' ? 'border-amber-500 text-amber-400' : 'border-transparent text-neutral-400'
                }`}
              >
                <FileUp className="h-4 w-4" />
                อัปโหลดไฟล์ (.TXT / .PDF)
              </button>
              <button
                onClick={() => setActiveTab('paste')}
                className={`flex-1 py-2.5 text-xs font-bold border-b-2 flex items-center justify-center gap-2 ${
                  activeTab === 'paste' ? 'border-amber-500 text-amber-400' : 'border-transparent text-neutral-400'
                }`}
              >
                <FileText className="h-4 w-4" />
                วางข้อความยาวโดยตรง
              </button>
            </div>

            {activeTab === 'upload' ? (
              <div className="space-y-3">
                {/* Drag and drop zone */}
                <div
                  onDragOver={(e) => e.preventDefault()}
                  onDrop={handleDrop}
                  onClick={() => fileInputRef.current?.click()}
                  className="flex flex-col items-center justify-center p-8 rounded-2xl border-2 border-dashed border-neutral-800 hover:border-amber-500/50 bg-neutral-900/40 hover:bg-neutral-900/80 cursor-pointer transition-all text-center"
                >
                  <FileUp className="h-10 w-10 text-amber-500/70 mb-3" />
                  <p className="text-sm font-semibold text-neutral-200">
                    คลิกเพื่อเลือกไฟล์ หรือลากไฟล์มาวางที่นี่
                  </p>
                  <p className="text-xs text-neutral-400 mt-1">
                    รองรับไฟล์ <span className="text-amber-400 font-mono">.txt</span> และ <span className="text-amber-400 font-mono">.pdf</span> (ไม่จำกัดความยาว)
                  </p>
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept=".txt,.pdf,.text,.md"
                    className="hidden"
                    onChange={(e) => {
                      if (e.target.files && e.target.files[0]) {
                        handleFileUpload(e.target.files[0]);
                      }
                    }}
                  />
                </div>

                {/* Encoding Option */}
                <div className="flex items-center justify-between bg-neutral-900/60 p-3 rounded-xl border border-neutral-800 text-xs">
                  <span className="text-neutral-400">การเข้ารหัสอักขระ (Encoding):</span>
                  <select
                    value={encoding}
                    onChange={(e) => setEncoding(e.target.value)}
                    className="rounded-lg bg-neutral-950 border border-neutral-800 px-3 py-1 text-neutral-200 text-xs"
                  >
                    <option value="utf-8">UTF-8 (สากล / นิยายไทย & จีนสมัยใหม่)</option>
                    <option value="gb18030">GBK / GB18030 (นิยายจีนดาวน์โหลดจากเว็บจีน)</option>
                    <option value="big5">Big5 (จีนตัวเต็ม / ไต้หวัน / ฮ่องกง)</option>
                    <option value="windows-874">TIS-620 / Windows-874 (ภาษาไทยดั้งเดิม)</option>
                  </select>
                </div>
              </div>
            ) : (
              <div className="space-y-3">
                <textarea
                  rows={10}
                  value={rawPastedText}
                  onChange={(e) => setRawPastedText(e.target.value)}
                  placeholder="วางเนื้อหานิยายจีนหรือไทยที่มีหลายตอนลงที่นี่...
ตัวอย่าง:
第一章 重生
(เนื้อหาตอนที่ 1...)

第二章 决斗
(เนื้อหาตอนที่ 2...)"
                  className="w-full rounded-2xl border border-neutral-800 bg-neutral-900/80 p-4 text-xs leading-relaxed text-neutral-100 focus:border-amber-500 focus:outline-none"
                />

                <div className="flex justify-end">
                  <button
                    disabled={!rawPastedText.trim() || isParsing}
                    onClick={() => handleProcessRawText(rawPastedText, 'นิยายนำเข้า')}
                    className="flex items-center gap-2 rounded-xl bg-amber-500 px-5 py-2 text-xs font-bold text-neutral-950 hover:bg-amber-400 disabled:opacity-40"
                  >
                    {isParsing ? <Loader2 className="h-4 w-4 animate-spin" /> : <Sparkles className="h-4 w-4" />}
                    แยกบทอัตโนมัติ
                  </button>
                </div>
              </div>
            )}

            {isParsing && (
              <div className="flex items-center justify-center gap-2 py-6 text-amber-400 text-xs font-medium animate-pulse">
                <Loader2 className="h-4 w-4 animate-spin" />
                กำลังสแกนและแยกบทนิยาย กรุณารอสักครู่...
              </div>
            )}

            {parseError && (
              <div className="flex items-center gap-2 p-3 rounded-xl bg-red-500/10 border border-red-500/30 text-red-300 text-xs">
                <AlertCircle className="h-4 w-4 shrink-0" />
                <span>{parseError}</span>
              </div>
            )}

          </div>
        ) : (
          /* Step 2: Preview & Configuration */
          <div className="flex-1 overflow-y-auto mt-4 space-y-4 pr-1">
            
            {/* Import destination selector */}
            <div className="grid grid-cols-2 gap-3">
              <button
                onClick={() => setImportMode('new_novel')}
                className={`p-3 rounded-xl border text-left transition-all ${
                  importMode === 'new_novel'
                    ? 'border-amber-500 bg-amber-500/15 text-amber-300'
                    : 'border-neutral-800 bg-neutral-900 text-neutral-400'
                }`}
              >
                <div className="font-bold text-xs">สร้างเป็นนิยายเรื่องใหม่</div>
                <div className="text-[11px] text-neutral-400 mt-0.5">บรรจุ {chaptersList.length} ตอนลงในเรื่องใหม่</div>
              </button>

              <button
                onClick={() => setImportMode('append')}
                className={`p-3 rounded-xl border text-left transition-all ${
                  importMode === 'append'
                    ? 'border-amber-500 bg-amber-500/15 text-amber-300'
                    : 'border-neutral-800 bg-neutral-900 text-neutral-400'
                }`}
              >
                <div className="font-bold text-xs">เพิ่มต่อท้ายนิยายเดิม</div>
                <div className="text-[11px] text-neutral-400 mt-0.5">เพิ่มตอนเข้าไปในนิยายที่มีอยู่แล้ว</div>
              </button>
            </div>

            {/* Target Details Form */}
            {importMode === 'new_novel' ? (
              <div className="space-y-3 bg-neutral-900/60 p-4 rounded-2xl border border-neutral-800">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="text-xs text-neutral-400 block mb-1">ชื่อเรื่องภาษาไทย / ชื่อเรื่อง</label>
                    <input
                      type="text"
                      value={novelTitle}
                      onChange={(e) => setNovelTitle(e.target.value)}
                      className="w-full rounded-xl border border-neutral-800 bg-neutral-950 p-2 text-xs text-neutral-100 focus:border-amber-500 focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="text-xs text-neutral-400 block mb-1">ชื่อผู้แต่ง / นามปากกา</label>
                    <input
                      type="text"
                      value={authorName}
                      onChange={(e) => setAuthorName(e.target.value)}
                      className="w-full rounded-xl border border-neutral-800 bg-neutral-950 p-2 text-xs text-neutral-100 focus:border-amber-500 focus:outline-none"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="text-xs text-neutral-400 block mb-1">หมวดหมู่</label>
                    <select
                      value={genre}
                      onChange={(e) => setGenre(e.target.value as NovelGenre)}
                      className="w-full rounded-xl border border-neutral-800 bg-neutral-950 p-2 text-xs text-neutral-100 focus:border-amber-500 focus:outline-none"
                    >
                      <option value="xianxia">กำลังภายใน / เทพเซียน (Xianxia)</option>
                      <option value="wuxia">ยุทธภพ / จอมยุทธ์ (Wuxia)</option>
                      <option value="rebirth">เกิดใหม่ / ข้ามมิติ (Rebirth)</option>
                      <option value="fantasy">แฟนตาซี (Fantasy)</option>
                      <option value="adventure">ผจญภัย (Adventure)</option>
                    </select>
                  </div>

                  <div>
                    <label className="text-xs text-neutral-400 block mb-1">เรื่องย่อสั้นๆ</label>
                    <input
                      type="text"
                      value={description}
                      onChange={(e) => setDescription(e.target.value)}
                      className="w-full rounded-xl border border-neutral-800 bg-neutral-950 p-2 text-xs text-neutral-100 focus:border-amber-500 focus:outline-none"
                    />
                  </div>
                </div>
              </div>
            ) : (
              <div className="bg-neutral-900/60 p-4 rounded-2xl border border-neutral-800">
                <label className="text-xs text-neutral-400 block mb-1">เลือกนิยายที่ต้องการเพิ่มตอน</label>
                <select
                  value={selectedTargetNovelId}
                  onChange={(e) => setSelectedTargetNovelId(e.target.value)}
                  className="w-full rounded-xl border border-neutral-800 bg-neutral-950 p-2.5 text-xs text-neutral-100"
                >
                  {existingNovels.map(n => (
                    <option key={n.id} value={n.id}>
                      {n.titleThai} (ปัจจุบันมี {n.chapters.length} ตอน)
                    </option>
                  ))}
                </select>
              </div>
            )}

            {/* Chapters Preview List */}
            <div className="space-y-2">
              <div className="flex items-center justify-between text-xs text-neutral-400 px-1">
                <span>
                  ตรวจพบ <strong className="text-amber-400">{chaptersList.length} ตอน</strong> (รวม {chaptersList.reduce((a, b) => a + b.wordCount, 0).toLocaleString()} คำ)
                </span>
                <button
                  onClick={() => setParseResult(null)}
                  className="text-neutral-400 hover:text-white underline text-[11px]"
                >
                  เลือกไฟล์อื่น
                </button>
              </div>

              <div className="max-h-60 overflow-y-auto space-y-1.5 border border-neutral-800 rounded-2xl p-2 bg-neutral-950">
                {chaptersList.map((ch, idx) => (
                  <div
                    key={idx}
                    className="flex items-center justify-between gap-3 p-2 rounded-xl bg-neutral-900/70 border border-neutral-850 hover:border-neutral-750 text-xs"
                  >
                    <span className="font-mono text-neutral-500 w-8 shrink-0 text-center">
                      #{idx + 1}
                    </span>

                    <input
                      type="text"
                      value={ch.title}
                      onChange={(e) => handleUpdateChapterTitle(idx, e.target.value)}
                      className="flex-1 bg-transparent border-b border-transparent hover:border-neutral-700 focus:border-amber-500 text-neutral-200 focus:outline-none px-1"
                    />

                    <span className="text-[11px] text-neutral-500 shrink-0">
                      {ch.wordCount.toLocaleString()} คำ
                    </span>

                    <button
                      onClick={() => handleDeleteChapter(idx)}
                      className="text-neutral-500 hover:text-red-400 p-1"
                      title="ลบตอนนี้ออก"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex items-center justify-end gap-3 pt-3 border-t border-neutral-800">
              <button
                onClick={() => setParseResult(null)}
                className="rounded-xl border border-neutral-800 px-4 py-2 text-xs font-semibold text-neutral-400 hover:text-white"
              >
                ย้อนกลับ
              </button>
              <button
                onClick={handleConfirmImport}
                className="flex items-center gap-2 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 px-6 py-2 text-xs font-bold text-neutral-950 hover:brightness-110 shadow-lg shadow-amber-500/20"
              >
                <Check className="h-4 w-4" />
                ยืนยันนำเข้า {chaptersList.length} ตอน
              </button>
            </div>

          </div>
        )}

      </div>
    </div>
  );
};
