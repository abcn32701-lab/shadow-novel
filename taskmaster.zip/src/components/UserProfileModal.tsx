import React, { useState } from 'react';
import { UserProfile } from '../types';
import { 
  User, 
  X, 
  Flame, 
  Clock, 
  BookOpen, 
  Award, 
  Download, 
  Upload, 
  Check,
  Edit2
} from 'lucide-react';
import { authService } from '../utils/authService';

interface UserProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
  userProfile: UserProfile;
  onProfileUpdated: (updated: UserProfile) => void;
}

export const UserProfileModal: React.FC<UserProfileModalProps> = ({
  isOpen,
  onClose,
  userProfile,
  onProfileUpdated
}) => {
  const [name, setName] = useState(userProfile.name);
  const [bio, setBio] = useState(userProfile.bio);
  const [isEditing, setIsEditing] = useState(false);
  const [exportSuccess, setExportSuccess] = useState(false);

  if (!isOpen) return null;

  const handleSave = () => {
    const updated = authService.updateName(name, bio);
    onProfileUpdated(updated);
    setIsEditing(false);
  };

  const handleExportData = () => {
    const dataStr = JSON.stringify(userProfile, null, 2);
    const blob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `novelia_backup_${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
    setExportSuccess(true);
    setTimeout(() => setExportSuccess(false), 2500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4">
      <div 
        className="w-full max-w-lg rounded-3xl border border-neutral-800 bg-neutral-950 p-6 text-neutral-100 shadow-2xl flex flex-col max-h-[90vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-neutral-800">
          <h2 className="text-base font-bold font-serif">ข้อมูลนักอ่าน (Reader Profile)</h2>
          <button onClick={onClose} className="p-1.5 rounded-lg text-neutral-400 hover:text-white">
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto mt-4 space-y-6 pr-1">
          {/* User Card */}
          <div className="flex items-center gap-4 rounded-2xl bg-neutral-900/60 p-4 border border-neutral-800">
            <img
              src={userProfile.avatar}
              alt={userProfile.name}
              className="h-16 w-16 rounded-full object-cover ring-2 ring-amber-500/50"
            />
            <div className="flex-1 min-w-0">
              {isEditing ? (
                <div className="space-y-2">
                  <input
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full rounded-lg border border-neutral-700 bg-neutral-950 p-1.5 text-xs text-white"
                  />
                  <input
                    type="text"
                    value={bio}
                    onChange={(e) => setBio(e.target.value)}
                    className="w-full rounded-lg border border-neutral-700 bg-neutral-950 p-1.5 text-xs text-neutral-300"
                  />
                  <button
                    onClick={handleSave}
                    className="rounded-lg bg-amber-500 px-3 py-1 text-xs font-bold text-neutral-950"
                  >
                    บันทึก
                  </button>
                </div>
              ) : (
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-base font-bold text-neutral-100 truncate">{userProfile.name}</h3>
                    <button
                      onClick={() => setIsEditing(true)}
                      className="text-neutral-500 hover:text-amber-400 p-1"
                    >
                      <Edit2 className="h-3.5 w-3.5" />
                    </button>
                  </div>
                  <p className="text-xs text-neutral-400 line-clamp-2 mt-0.5">{userProfile.bio}</p>
                </div>
              )}
            </div>
          </div>

          {/* Reading Statistics */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-amber-500 mb-3 flex items-center gap-1.5">
              <Award className="h-4 w-4" />
              สถิติการอ่านของคุณ
            </h4>

            <div className="grid grid-cols-3 gap-3">
              <div className="rounded-2xl bg-neutral-900/60 p-3.5 border border-neutral-800 text-center">
                <Clock className="mx-auto h-5 w-5 text-amber-400 mb-1" />
                <span className="text-xl font-bold font-mono text-neutral-100">
                  {userProfile.stats.minutesRead}
                </span>
                <p className="text-[11px] text-neutral-400 mt-0.5">นาทีที่อ่าน</p>
              </div>

              <div className="rounded-2xl bg-neutral-900/60 p-3.5 border border-neutral-800 text-center">
                <BookOpen className="mx-auto h-5 w-5 text-emerald-400 mb-1" />
                <span className="text-xl font-bold font-mono text-neutral-100">
                  {userProfile.stats.chaptersCompleted}
                </span>
                <p className="text-[11px] text-neutral-400 mt-0.5">ตอนที่อ่านจบ</p>
              </div>

              <div className="rounded-2xl bg-neutral-900/60 p-3.5 border border-neutral-800 text-center">
                <Flame className="mx-auto h-5 w-5 text-orange-500 fill-orange-500 mb-1" />
                <span className="text-xl font-bold font-mono text-neutral-100">
                  {userProfile.stats.currentStreakDays}
                </span>
                <p className="text-[11px] text-neutral-400 mt-0.5">วันติดต่อกัน</p>
              </div>
            </div>
          </div>

          {/* Backup & Export Data */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-neutral-400 mb-3">
              สำรองข้อมูลและการนำออก
            </h4>
            <div className="flex gap-2">
              <button
                onClick={handleExportData}
                className="flex-1 flex items-center justify-center gap-2 p-3 rounded-xl border border-neutral-800 bg-neutral-900/60 hover:bg-neutral-850 text-xs font-semibold text-neutral-300 transition-colors"
              >
                {exportSuccess ? <Check className="h-4 w-4 text-emerald-400" /> : <Download className="h-4 w-4" />}
                {exportSuccess ? 'ดาวน์โหลดแล้ว' : 'ส่งออกข้อมูล (JSON)'}
              </button>
            </div>
          </div>
        </div>

        <div className="mt-6 pt-4 border-t border-neutral-800 flex justify-end">
          <button
            onClick={onClose}
            className="rounded-xl bg-neutral-800 px-5 py-2 text-xs font-semibold text-neutral-200 hover:bg-neutral-700"
          >
            ปิด
          </button>
        </div>
      </div>
    </div>
  );
};
