import React from 'react';
import { Clock, X, Moon, Check } from 'lucide-react';

interface SleepTimerModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentRemainingSeconds: number | null;
  onSetTimer: (minutes: number | null) => void;
}

export const SleepTimerModal: React.FC<SleepTimerModalProps> = ({
  isOpen,
  onClose,
  currentRemainingSeconds,
  onSetTimer
}) => {
  if (!isOpen) return null;

  const timerOptions = [
    { label: '15 นาที', minutes: 15 },
    { label: '30 นาที', minutes: 30 },
    { label: '45 นาที', minutes: 45 },
    { label: '60 นาที (1 ชั่วโมง)', minutes: 60 },
    { label: '90 นาที', minutes: 90 },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4">
      <div 
        className="w-full max-w-sm rounded-3xl border border-neutral-800 bg-neutral-950 p-6 text-neutral-100 shadow-2xl flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between pb-3 border-b border-neutral-800">
          <div className="flex items-center gap-2">
            <Moon className="h-5 w-5 text-amber-400" />
            <h2 className="text-base font-bold font-serif">ตั้งเวลาหยุดเล่น (Sleep Timer)</h2>
          </div>
          <button onClick={onClose} className="p-1.5 rounded-lg text-neutral-400 hover:text-white">
            <X className="h-5 w-5" />
          </button>
        </div>

        <p className="text-xs text-neutral-400 mt-3 mb-4">
          เมื่อหมดเวลา เสียงอ่านและเสียงบรรยากาศจะค่อยๆ หยุดลง เพื่อให้คุณนอนหลับสบาย
        </p>

        {currentRemainingSeconds && currentRemainingSeconds > 0 && (
          <div className="mb-4 rounded-xl bg-amber-500/15 border border-amber-500/30 p-3 text-center">
            <span className="text-xs text-amber-300">กำลังนับถอยหลัง:</span>
            <p className="text-xl font-bold font-mono text-amber-400 mt-0.5">
              {Math.floor(currentRemainingSeconds / 60)} นาที {currentRemainingSeconds % 60} วินาที
            </p>
          </div>
        )}

        <div className="space-y-2">
          {timerOptions.map(opt => (
            <button
              key={opt.minutes}
              onClick={() => {
                onSetTimer(opt.minutes);
                onClose();
              }}
              className="w-full flex items-center justify-between p-3 rounded-xl border border-neutral-800 bg-neutral-900/60 hover:bg-neutral-850 hover:border-amber-500/50 text-xs font-semibold transition-all"
            >
              <span>{opt.label}</span>
              <Clock className="h-4 w-4 text-neutral-500" />
            </button>
          ))}

          {currentRemainingSeconds && (
            <button
              onClick={() => {
                onSetTimer(null);
                onClose();
              }}
              className="w-full p-3 rounded-xl border border-red-500/30 bg-red-500/10 text-red-300 hover:bg-red-500/20 text-xs font-bold transition-all mt-2"
            >
              ยกเลิกการตั้งเวลา
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
