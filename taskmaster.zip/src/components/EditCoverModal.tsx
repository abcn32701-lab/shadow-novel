import React, { useState, useEffect, useRef } from 'react';
import { Novel, NovelGenre } from '../types';
import { 
  X, 
  Upload, 
  Link as LinkIcon, 
  Sparkles, 
  Image as ImageIcon, 
  Check, 
  RefreshCw,
  Eye,
  Layers,
  Palette
} from 'lucide-react';
import { processCoverImageFile, PRESET_COVERS, generateCoverSvg } from '../utils/imageHelper';

interface EditCoverModalProps {
  isOpen: boolean;
  onClose: () => void;
  novel: Novel | null;
  onSaveCover: (novelId: string, newCoverUrl: string) => void;
}

export const EditCoverModal: React.FC<EditCoverModalProps> = ({
  isOpen,
  onClose,
  novel,
  onSaveCover
}) => {
  const [activeTab, setActiveTab] = useState<'upload' | 'url' | 'presets' | 'generate'>('upload');
  const [previewCover, setPreviewCover] = useState<string>('');
  const [urlInput, setUrlInput] = useState<string>('');
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string>('');
  const [selectedGenreForGen, setSelectedGenreForGen] = useState<NovelGenre>('xianxia');
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (novel && isOpen) {
      setPreviewCover(novel.coverImage);
      setUrlInput(novel.coverImage.startsWith('http') ? novel.coverImage : '');
      setSelectedGenreForGen(novel.genre);
      setErrorMessage('');
    }
  }, [novel, isOpen]);

  if (!isOpen || !novel) return null;

  // Handle file selection and compression
  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsProcessing(true);
    setErrorMessage('');
    try {
      const dataUrl = await processCoverImageFile(file);
      setPreviewCover(dataUrl);
    } catch (err: any) {
      setErrorMessage(err.message || 'เกิดข้อผิดพลาดในการโหลดรูปภาพ');
    } finally {
      setIsProcessing(false);
    }
  };

  // Drag and drop handlers
  const handleDrop = async (e: React.DragEvent) => {
    e.preventDefault();
    const file = e.dataTransfer.files?.[0];
    if (!file) return;

    setIsProcessing(true);
    setErrorMessage('');
    try {
      const dataUrl = await processCoverImageFile(file);
      setPreviewCover(dataUrl);
    } catch (err: any) {
      setErrorMessage(err.message || 'เกิดข้อผิดพลาดในการโหลดรูปภาพ');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
  };

  // Apply custom image URL
  const handleApplyUrl = () => {
    const trimmed = urlInput.trim();
    if (!trimmed) {
      setErrorMessage('กรุณาระบุ URL ของรูปภาพ');
      return;
    }
    setPreviewCover(trimmed);
    setErrorMessage('');
  };

  // Generate procedural SVG cover
  const handleGenerateSvg = (seed: string = String(Date.now())) => {
    const generated = generateCoverSvg(
      novel.titleThai || novel.title,
      selectedGenreForGen,
      novel.author || 'นิรนาม',
      seed
    );
    setPreviewCover(generated);
  };

  // Save changes
  const handleSave = () => {
    if (!previewCover) {
      setErrorMessage('กรุณาเลือกรูปปกก่อนบันทึก');
      return;
    }
    onSaveCover(novel.id, previewCover);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4">
      <div 
        className="w-full max-w-2xl rounded-3xl border border-neutral-800 bg-neutral-950 p-6 text-neutral-100 shadow-2xl flex flex-col max-h-[90vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-neutral-800">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-amber-500/15 text-amber-400 border border-amber-500/30">
              <ImageIcon className="h-5 w-5" />
            </div>
            <div>
              <h2 className="text-base font-bold font-serif">เปลี่ยนรูปปกนิยาย</h2>
              <p className="text-xs text-neutral-400 truncate max-w-sm sm:max-w-md">
                เรื่อง: <span className="text-amber-300 font-semibold">{novel.titleThai}</span>
              </p>
            </div>
          </div>
          <button 
            onClick={onClose} 
            className="p-1.5 rounded-lg text-neutral-400 hover:text-white hover:bg-neutral-900"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Content Body: Left is preview, Right is inputs */}
        <div className="flex-1 overflow-y-auto mt-4 grid grid-cols-1 md:grid-cols-12 gap-6 pr-1">
          
          {/* Left: Live 2:3 Cover Preview */}
          <div className="md:col-span-5 flex flex-col items-center">
            <div className="relative aspect-[2/3] w-48 sm:w-52 rounded-2xl overflow-hidden border-2 border-amber-500/40 bg-neutral-900 shadow-2xl shadow-black/80 group">
              <img 
                src={previewCover || novel.coverImage} 
                alt="Novel Cover Preview" 
                className="h-full w-full object-cover"
                onError={() => {
                  setErrorMessage('รูปภาพไม่สามารถแสดงได้ ตรวจสอบว่าลิงก์ถูกต้องหรือไม่');
                }}
              />
              
              {isProcessing && (
                <div className="absolute inset-0 bg-black/70 backdrop-blur-sm flex flex-col items-center justify-center gap-2">
                  <RefreshCw className="h-6 w-6 text-amber-400 animate-spin" />
                  <span className="text-xs text-neutral-200">กำลังย่อและปรับขนาด...</span>
                </div>
              )}

              <span className="absolute top-2 left-2 flex items-center gap-1 rounded-md bg-neutral-950/80 px-2 py-0.5 text-[10px] font-medium text-amber-300 border border-amber-500/20 backdrop-blur-md">
                <Eye className="h-3 w-3" />
                ตัวอย่างปก
              </span>
            </div>

            <p className="text-[11px] text-neutral-400 text-center mt-3">
              อัตราส่วนมาตรฐานหนังสือ 2:3 คมชัดทุกขนาดหน้าจอ
            </p>
          </div>

          {/* Right: Method Tabs and Configuration */}
          <div className="md:col-span-7 flex flex-col space-y-4">
            
            {/* Tabs */}
            <div className="grid grid-cols-4 gap-1 rounded-xl bg-neutral-900 p-1 border border-neutral-800 text-xs">
              <button
                type="button"
                onClick={() => setActiveTab('upload')}
                className={`py-1.5 px-2 rounded-lg font-medium transition-all text-center flex flex-col sm:flex-row items-center justify-center gap-1 ${
                  activeTab === 'upload'
                    ? 'bg-amber-500 text-neutral-950 font-bold shadow-sm'
                    : 'text-neutral-400 hover:text-neutral-200'
                }`}
              >
                <Upload className="h-3.5 w-3.5" />
                <span>อัปโหลด</span>
              </button>

              <button
                type="button"
                onClick={() => setActiveTab('url')}
                className={`py-1.5 px-2 rounded-lg font-medium transition-all text-center flex flex-col sm:flex-row items-center justify-center gap-1 ${
                  activeTab === 'url'
                    ? 'bg-amber-500 text-neutral-950 font-bold shadow-sm'
                    : 'text-neutral-400 hover:text-neutral-200'
                }`}
              >
                <LinkIcon className="h-3.5 w-3.5" />
                <span>ใส่ลิงก์</span>
              </button>

              <button
                type="button"
                onClick={() => setActiveTab('presets')}
                className={`py-1.5 px-2 rounded-lg font-medium transition-all text-center flex flex-col sm:flex-row items-center justify-center gap-1 ${
                  activeTab === 'presets'
                    ? 'bg-amber-500 text-neutral-950 font-bold shadow-sm'
                    : 'text-neutral-400 hover:text-neutral-200'
                }`}
              >
                <Layers className="h-3.5 w-3.5" />
                <span>สำเร็จรูป</span>
              </button>

              <button
                type="button"
                onClick={() => setActiveTab('generate')}
                className={`py-1.5 px-2 rounded-lg font-medium transition-all text-center flex flex-col sm:flex-row items-center justify-center gap-1 ${
                  activeTab === 'generate'
                    ? 'bg-amber-500 text-neutral-950 font-bold shadow-sm'
                    : 'text-neutral-400 hover:text-neutral-200'
                }`}
              >
                <Sparkles className="h-3.5 w-3.5" />
                <span>สร้างอาร์ต</span>
              </button>
            </div>

            {/* Error notice if any */}
            {errorMessage && (
              <div className="rounded-xl border border-red-500/30 bg-red-500/10 p-2.5 text-xs text-red-300">
                {errorMessage}
              </div>
            )}

            {/* Tab 1: Upload from device */}
            {activeTab === 'upload' && (
              <div className="space-y-3">
                <div
                  onDrop={handleDrop}
                  onDragOver={handleDragOver}
                  onClick={() => fileInputRef.current?.click()}
                  className="flex flex-col items-center justify-center rounded-2xl border-2 border-dashed border-neutral-700 bg-neutral-900/50 p-6 text-center hover:border-amber-500/60 hover:bg-neutral-900 transition-all cursor-pointer group"
                >
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/png,image/jpeg,image/webp,image/jpg"
                    onChange={handleFileChange}
                    className="hidden"
                  />
                  <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-neutral-800 text-neutral-400 group-hover:bg-amber-500/20 group-hover:text-amber-400 transition-colors mb-3">
                    <Upload className="h-6 w-6" />
                  </div>
                  <p className="text-xs font-semibold text-neutral-200">
                    คลิกเพื่อเลือกรูปภาพ หรือลากไฟล์มาวางที่นี่
                  </p>
                  <p className="text-[11px] text-neutral-500 mt-1">
                    รองรับ JPG, PNG, WEBP (ระบบจะบีบอัดให้พอดีอัตโนมัติ)
                  </p>
                </div>
              </div>
            )}

            {/* Tab 2: Image URL */}
            {activeTab === 'url' && (
              <div className="space-y-3">
                <div>
                  <label className="text-xs text-neutral-300 block mb-1.5 font-medium">
                    ใส่ที่อยู่ลิงก์รูปภาพ (Image URL)
                  </label>
                  <div className="flex gap-2">
                    <input
                      type="url"
                      value={urlInput}
                      onChange={(e) => setUrlInput(e.target.value)}
                      placeholder="https://example.com/cover.jpg"
                      className="flex-1 rounded-xl border border-neutral-800 bg-neutral-900 p-2.5 text-xs text-neutral-100 focus:border-amber-500 focus:outline-none"
                    />
                    <button
                      type="button"
                      onClick={handleApplyUrl}
                      className="shrink-0 rounded-xl bg-neutral-800 px-4 py-2 text-xs font-semibold text-amber-400 hover:bg-neutral-700 transition-colors"
                    >
                      ดูตัวอย่าง
                    </button>
                  </div>
                </div>
                <p className="text-[11px] text-neutral-500">
                  คุณสามารถคัดลอกลิงก์รูปภาพจาก Pinterest, Unsplash หรือเว็บไซต์ภายนอกมาวางได้
                </p>
              </div>
            )}

            {/* Tab 3: Curated Presets */}
            {activeTab === 'presets' && (
              <div className="space-y-2">
                <label className="text-xs text-neutral-300 block font-medium">
                  เลือกภาพปกสำเร็จรูปตามแนวเรื่อง:
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 max-h-56 overflow-y-auto pr-1">
                  {PRESET_COVERS.map((preset) => {
                    const isSelected = previewCover === preset.url;
                    return (
                      <button
                        key={preset.id}
                        type="button"
                        onClick={() => setPreviewCover(preset.url)}
                        className={`relative aspect-[2/3] rounded-xl overflow-hidden border-2 text-left transition-all ${
                          isSelected 
                            ? 'border-amber-500 ring-2 ring-amber-500/30 shadow-md' 
                            : 'border-neutral-800 opacity-75 hover:opacity-100 hover:border-neutral-600'
                        }`}
                      >
                        <img 
                          src={preset.url} 
                          alt={preset.name} 
                          className="h-full w-full object-cover"
                        />
                        <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black via-black/80 to-transparent p-1.5 pt-4">
                          <p className="text-[10px] font-bold text-white truncate">{preset.name}</p>
                          <p className="text-[9px] text-amber-300 truncate">{preset.genre}</p>
                        </div>
                        {isSelected && (
                          <div className="absolute top-1.5 right-1.5 flex h-4 w-4 items-center justify-center rounded-full bg-amber-500 text-neutral-950">
                            <Check className="h-3 w-3 stroke-[3]" />
                          </div>
                        )}
                      </button>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Tab 4: Procedural SVG Generator */}
            {activeTab === 'generate' && (
              <div className="space-y-3">
                <div>
                  <label className="text-xs text-neutral-300 block mb-1 font-medium">
                    เลือกโทนศิลป์และแนวเรื่อง
                  </label>
                  <select
                    value={selectedGenreForGen}
                    onChange={(e) => {
                      const newGenre = e.target.value as NovelGenre;
                      setSelectedGenreForGen(newGenre);
                      const generated = generateCoverSvg(
                        novel.titleThai || novel.title,
                        newGenre,
                        novel.author || 'นิรนาม'
                      );
                      setPreviewCover(generated);
                    }}
                    className="w-full rounded-xl border border-neutral-800 bg-neutral-900 p-2 text-xs text-neutral-100 focus:border-amber-500 focus:outline-none"
                  >
                    <option value="xianxia">เทพเซียน / บำเพ็ญตบะ (Xianxia)</option>
                    <option value="wuxia">ยุทธภพ / กำลังภายในแท้ (Wuxia)</option>
                    <option value="fantasy">แฟนตาซีเวทมนตร์ (Fantasy)</option>
                    <option value="rebirth">ย้อนเวลา / เกิดใหม่ (Rebirth)</option>
                    <option value="scifi">ไซไฟล้ำยุค (Sci-Fi)</option>
                    <option value="romance">โรแมนติกยุทธภพ (Romance)</option>
                    <option value="adventure">ผจญภัยท่องโลก (Adventure)</option>
                  </select>
                </div>

                <button
                  type="button"
                  onClick={() => handleGenerateSvg(String(Math.random()))}
                  className="w-full flex items-center justify-center gap-2 rounded-xl border border-amber-500/30 bg-amber-500/10 p-2.5 text-xs font-bold text-amber-300 hover:bg-amber-500/20 transition-colors"
                >
                  <Sparkles className="h-4 w-4 text-amber-400" />
                  <span>สุ่มลวดลายและดวงตราอักษรใหม่</span>
                </button>
              </div>
            )}

          </div>

        </div>

        {/* Footer Actions */}
        <div className="mt-6 pt-4 border-t border-neutral-800 flex items-center justify-between">
          <button
            type="button"
            onClick={() => setPreviewCover(novel.coverImage)}
            className="text-xs text-neutral-400 hover:text-neutral-200"
          >
            ย้อนกลับเป็นรูปเดิม
          </button>

          <div className="flex gap-2">
            <button
              type="button"
              onClick={onClose}
              className="rounded-xl border border-neutral-800 px-4 py-2 text-xs font-semibold text-neutral-400 hover:text-white"
            >
              ยกเลิก
            </button>
            <button
              type="button"
              onClick={handleSave}
              className="flex items-center gap-1.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 px-5 py-2 text-xs font-bold text-neutral-950 hover:brightness-110 shadow-lg shadow-amber-500/20"
            >
              <Check className="h-4 w-4 stroke-[2.5]" />
              <span>บันทึกรูปปกนี้</span>
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
