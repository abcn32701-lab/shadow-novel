import React, { useState } from 'react';
import { Novel } from '../types';
import { 
  Bookmark, 
  X, 
  BookOpen, 
  Clock, 
  Trash2, 
  Play, 
  ArrowRight,
  Flame,
  Heart,
  Camera
} from 'lucide-react';
import { authService } from '../utils/authService';

interface LibraryModalProps {
  isOpen: boolean;
  onClose: () => void;
  novels: Novel[];
  onSelectNovel: (novel: Novel, chapterIndex?: number) => void;
  onOpenEditCover?: (novel: Novel) => void;
}

export const LibraryModal: React.FC<LibraryModalProps> = ({
  isOpen,
  onClose,
  novels,
  onSelectNovel,
  onOpenEditCover
}) => {
  const [tab, setTab] = useState<'favorites' | 'history'>('favorites');
  const profile = authService.getProfile();

  if (!isOpen) return null;

  const favoriteNovels = novels.filter(n => profile.favorites.includes(n.id));

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4">
      <div 
        className="w-full max-w-3xl rounded-3xl border border-neutral-800 bg-neutral-950 p-6 text-neutral-100 shadow-2xl flex flex-col max-h-[85vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-neutral-800">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-amber-500/15 text-amber-400 border border-amber-500/30">
              <Bookmark className="h-5 w-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold font-serif">ชั้นหนังสือของฉัน (My Bookshelf)</h2>
              <p className="text-xs text-neutral-400">บันทึกเรื่องโปรดและประวัติการอ่านของคุณ</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-neutral-400 hover:text-white hover:bg-neutral-900"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Tabs */}
        <div className="flex border-b border-neutral-800 mt-3">
          <button
            onClick={() => setTab('favorites')}
            className={`flex-1 py-3 text-xs font-bold text-center border-b-2 transition-colors flex items-center justify-center gap-1.5 ${
              tab === 'favorites'
                ? 'border-amber-500 text-amber-400'
                : 'border-transparent text-neutral-400 hover:text-neutral-200'
            }`}
          >
            <Heart className="h-3.5 w-3.5 fill-current" />
            นิยายเรื่องโปรด ({favoriteNovels.length})
          </button>

          <button
            onClick={() => setTab('history')}
            className={`flex-1 py-3 text-xs font-bold text-center border-b-2 transition-colors flex items-center justify-center gap-1.5 ${
              tab === 'history'
                ? 'border-amber-500 text-amber-400'
                : 'border-transparent text-neutral-400 hover:text-neutral-200'
            }`}
          >
            <Clock className="h-3.5 w-3.5" />
            ประวัติการอ่าน ({profile.history.length})
          </button>
        </div>

        {/* Tab content */}
        <div className="flex-1 overflow-y-auto mt-4 space-y-3 pr-1">
          {tab === 'favorites' ? (
            favoriteNovels.length === 0 ? (
              <div className="py-16 text-center text-neutral-500">
                <Bookmark className="mx-auto h-10 w-10 stroke-[1.5] mb-2 opacity-40" />
                <p className="text-sm font-semibold text-neutral-300">ยังไม่มีนิยายในชั้นหนังสือ</p>
                <p className="text-xs text-neutral-500 mt-1">กดไอคอนที่คั่นหนังสือบนการ์ดนิยายเพื่อเพิ่มเข้ามาที่นี่</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {favoriteNovels.map(novel => (
                  <div
                    key={novel.id}
                    onClick={() => {
                      onSelectNovel(novel, 0);
                      onClose();
                    }}
                    className="flex gap-4 p-3 rounded-2xl border border-neutral-800 bg-neutral-900/60 hover:bg-neutral-900 hover:border-amber-500/40 transition-all cursor-pointer group"
                  >
                    <div className="relative shrink-0 group/cover">
                      <img
                        src={novel.coverImage}
                        alt={novel.titleThai}
                        className="w-20 h-28 object-cover rounded-xl shrink-0"
                      />
                      {onOpenEditCover && (
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            onOpenEditCover(novel);
                          }}
                          className="absolute inset-0 bg-black/60 rounded-xl flex items-center justify-center opacity-0 group-hover/cover:opacity-100 transition-opacity text-amber-300 text-[10px] font-bold"
                          title="เปลี่ยนรูปปก"
                        >
                          <Camera className="h-4 w-4" />
                        </button>
                      )}
                    </div>
                    <div className="flex flex-col justify-between min-w-0 flex-1">
                      <div>
                        <h4 className="font-serif text-sm font-bold text-neutral-100 group-hover:text-amber-400 truncate">
                          {novel.titleThai}
                        </h4>
                        <p className="text-xs text-neutral-400 mt-0.5">{novel.author}</p>
                        <p className="text-[11px] text-neutral-500 line-clamp-2 mt-1">
                          {novel.description}
                        </p>
                      </div>
                      <div className="flex items-center justify-between text-xs text-amber-400 pt-2">
                        <span>{novel.chapters.length} ตอน</span>
                        <div className="flex items-center gap-2">
                          {onOpenEditCover && (
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                onOpenEditCover(novel);
                              }}
                              className="text-[11px] text-neutral-400 hover:text-amber-300 flex items-center gap-1 px-1.5 py-0.5 rounded bg-neutral-800/60"
                              title="เปลี่ยนรูปปก"
                            >
                              <Camera className="h-3 w-3" />
                              <span>ปก</span>
                            </button>
                          )}
                          <span className="flex items-center text-[11px] font-semibold text-amber-400">
                            อ่านต่อ <ArrowRight className="h-3 w-3 ml-0.5" />
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )
          ) : (
            /* History Tab */
            profile.history.length === 0 ? (
              <div className="py-16 text-center text-neutral-500">
                <Clock className="mx-auto h-10 w-10 stroke-[1.5] mb-2 opacity-40" />
                <p className="text-sm font-semibold text-neutral-300">ยังไม่มีประวัติการอ่าน</p>
                <p className="text-xs text-neutral-500 mt-1">เมื่อคุณเริ่มอ่านนิยาย เรื่องจะถูกบันทึกที่นี่โดยอัตโนมัติ</p>
              </div>
            ) : (
              <div className="space-y-3">
                {profile.history.map(item => {
                  const novel = novels.find(n => n.id === item.novelId);
                  if (!novel) return null;
                  const chapIdx = novel.chapters.findIndex(c => c.id === item.chapterId);

                  return (
                    <div
                      key={item.novelId}
                      className="flex items-center justify-between p-3 rounded-2xl border border-neutral-800 bg-neutral-900/60"
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        <img
                          src={novel.coverImage}
                          alt={novel.titleThai}
                          className="w-12 h-16 object-cover rounded-lg shrink-0"
                        />
                        <div className="min-w-0">
                          <h4 className="font-serif text-sm font-bold text-neutral-100 truncate">
                            {novel.titleThai}
                          </h4>
                          <p className="text-xs text-amber-400">
                            อ่านถึง: ตอนที่ {item.chapterNumber} (ความคืบหน้า {item.progressPercent}%)
                          </p>
                          <p className="text-[10px] text-neutral-500">
                            {new Date(item.lastReadAt).toLocaleString('th-TH')}
                          </p>
                        </div>
                      </div>

                      <div className="flex items-center gap-2 shrink-0">
                        {onOpenEditCover && (
                          <button
                            type="button"
                            onClick={() => onOpenEditCover(novel)}
                            className="p-2 rounded-xl border border-neutral-800 bg-neutral-800/80 text-neutral-400 hover:text-amber-400 hover:border-amber-500/50"
                            title="เปลี่ยนรูปปกนิยาย"
                          >
                            <Camera className="h-3.5 w-3.5" />
                          </button>
                        )}
                        <button
                          onClick={() => {
                            onSelectNovel(novel, chapIdx >= 0 ? chapIdx : 0);
                            onClose();
                          }}
                          className="rounded-xl bg-amber-500 px-4 py-2 text-xs font-bold text-neutral-950 hover:bg-amber-400"
                        >
                          อ่านต่อ
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )
          )}
        </div>

      </div>
    </div>
  );
};
