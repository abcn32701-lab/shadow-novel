import React, { useState } from 'react';
import { Novel, Bookmark } from '../types';
import { 
  X, 
  Search, 
  BookOpen, 
  Bookmark as BookmarkIcon, 
  Clock, 
  Trash2, 
  CheckCircle2,
  Plus,
  FileUp,
  Camera
} from 'lucide-react';
import { authService } from '../utils/authService';

interface ChapterSidebarProps {
  isOpen: boolean;
  onClose: () => void;
  novel: Novel;
  currentChapterIndex: number;
  onSelectChapter: (index: number) => void;
  onOpenAddChapter: () => void;
  onOpenBatchImport?: () => void;
  onOpenEditCover?: (novel: Novel) => void;
}

export const ChapterSidebar: React.FC<ChapterSidebarProps> = ({
  isOpen,
  onClose,
  novel,
  currentChapterIndex,
  onSelectChapter,
  onOpenAddChapter,
  onOpenBatchImport,
  onOpenEditCover
}) => {
  const [activeTab, setActiveTab] = useState<'chapters' | 'bookmarks'>('chapters');
  const [filterQuery, setFilterQuery] = useState('');
  const [bookmarks, setBookmarks] = useState<Bookmark[]>(() => {
    return authService.getProfile().bookmarks.filter(b => b.novelId === novel.id);
  });

  if (!isOpen) return null;

  const filteredChapters = novel.chapters.filter(ch => {
    const q = filterQuery.toLowerCase();
    return ch.title.toLowerCase().includes(q) || String(ch.chapterNumber).includes(q);
  });

  const handleDeleteBookmark = (bmId: string) => {
    authService.removeBookmark(bmId);
    setBookmarks(prev => prev.filter(b => b.id !== bmId));
  };

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-black/75 backdrop-blur-sm transition-opacity">
      <div 
        className="w-full max-w-md h-full bg-neutral-950 border-l border-neutral-800 flex flex-col text-neutral-100 shadow-2xl animate-in slide-in-from-right duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-neutral-800 flex items-center justify-between gap-3">
          <div className="flex items-center gap-3 min-w-0">
            <div className="relative shrink-0 group/cover">
              <img
                src={novel.coverImage}
                alt={novel.titleThai}
                className="w-10 h-14 object-cover rounded-lg border border-neutral-800"
              />
              {onOpenEditCover && (
                <button
                  type="button"
                  onClick={() => onOpenEditCover(novel)}
                  className="absolute inset-0 bg-black/60 rounded-lg flex items-center justify-center opacity-0 group-hover/cover:opacity-100 transition-opacity text-amber-300"
                  title="เปลี่ยนรูปปก"
                >
                  <Camera className="h-3.5 w-3.5" />
                </button>
              )}
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-2">
                <span className="text-xs text-amber-500 font-semibold truncate max-w-[180px] block">{novel.titleThai}</span>
                {onOpenEditCover && (
                  <button
                    type="button"
                    onClick={() => onOpenEditCover(novel)}
                    className="text-[10px] text-neutral-400 hover:text-amber-400 flex items-center gap-1 px-1.5 py-0.5 rounded bg-neutral-900 border border-neutral-800 shrink-0"
                    title="เปลี่ยนรูปปก"
                  >
                    <Camera className="h-2.5 w-2.5" />
                    <span>เปลี่ยนปก</span>
                  </button>
                )}
              </div>
              <h2 className="text-base font-bold font-serif text-neutral-100">สารบัญ & ที่คั่นหน้า</h2>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-lg text-neutral-400 hover:text-white hover:bg-neutral-900 transition-colors shrink-0"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Tabs */}
        <div className="flex border-b border-neutral-800 px-4">
          <button
            onClick={() => setActiveTab('chapters')}
            className={`flex-1 py-3 text-xs font-bold text-center border-b-2 transition-colors flex items-center justify-center gap-1.5 ${
              activeTab === 'chapters'
                ? 'border-amber-500 text-amber-400'
                : 'border-transparent text-neutral-400 hover:text-neutral-200'
            }`}
          >
            <BookOpen className="h-3.5 w-3.5" />
            ตอนทั้งหมด ({novel.chapters.length})
          </button>
          <button
            onClick={() => setActiveTab('bookmarks')}
            className={`flex-1 py-3 text-xs font-bold text-center border-b-2 transition-colors flex items-center justify-center gap-1.5 ${
              activeTab === 'bookmarks'
                ? 'border-amber-500 text-amber-400'
                : 'border-transparent text-neutral-400 hover:text-neutral-200'
            }`}
          >
            <BookmarkIcon className="h-3.5 w-3.5" />
            ที่คั่นหน้า ({bookmarks.length})
          </button>
        </div>

        {/* Content Area */}
        {activeTab === 'chapters' ? (
          <div className="flex-1 flex flex-col min-h-0">
            {/* Search filter & Add chapter */}
            <div className="p-4 border-b border-neutral-850 flex items-center gap-2">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-neutral-500" />
                <input
                  type="text"
                  value={filterQuery}
                  onChange={(e) => setFilterQuery(e.target.value)}
                  placeholder="ค้นหาชื่อตอน หรือเลขตอน..."
                  className="w-full rounded-lg border border-neutral-800 bg-neutral-900 py-1.5 pl-8 pr-3 text-xs text-neutral-200 focus:border-amber-500 focus:outline-none"
                />
              </div>
              <div className="flex items-center gap-1.5 shrink-0">
                <button
                  onClick={onOpenAddChapter}
                  className="flex items-center gap-1 rounded-lg bg-amber-500/15 border border-amber-500/30 px-2 py-1.5 text-[11px] font-semibold text-amber-400 hover:bg-amber-500/25"
                  title="เพิ่มตอนใหม่ทีละตอน"
                >
                  <Plus className="h-3.5 w-3.5" />
                  <span>เพิ่มตอน</span>
                </button>
                {onOpenBatchImport && (
                  <button
                    onClick={() => {
                      onOpenBatchImport();
                      onClose();
                    }}
                    className="flex items-center gap-1 rounded-lg bg-neutral-900 border border-neutral-800 px-2 py-1.5 text-[11px] font-semibold text-neutral-300 hover:border-amber-500/40 hover:text-amber-300"
                    title="นำเข้าหลายตอนจากไฟล์ .TXT หรือ .PDF"
                  >
                    <FileUp className="h-3.5 w-3.5 text-amber-400" />
                    <span>นำเข้าไฟล์</span>
                  </button>
                )}
              </div>
            </div>

            {/* Chapters list */}
            <div className="flex-1 overflow-y-auto p-4 space-y-2">
              {filteredChapters.map((ch, idx) => {
                const originalIndex = novel.chapters.findIndex(c => c.id === ch.id);
                const isCurrent = originalIndex === currentChapterIndex;

                return (
                  <button
                    key={ch.id}
                    onClick={() => {
                      onSelectChapter(originalIndex);
                      onClose();
                    }}
                    className={`w-full flex items-center justify-between p-3 rounded-xl border text-left transition-all ${
                      isCurrent
                        ? 'border-amber-500 bg-amber-500/10 text-amber-300 font-semibold'
                        : 'border-neutral-850 bg-neutral-900/60 hover:bg-neutral-850 hover:border-neutral-750 text-neutral-200'
                    }`}
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <span className={`text-xs font-mono px-2 py-0.5 rounded ${
                        isCurrent ? 'bg-amber-500 text-neutral-950 font-bold' : 'bg-neutral-800 text-neutral-400'
                      }`}>
                        {ch.chapterNumber}
                      </span>
                      <div className="min-w-0">
                        <p className="text-sm font-medium truncate">{ch.title}</p>
                        <p className="text-[11px] text-neutral-500">{ch.wordCount.toLocaleString()} คำ</p>
                      </div>
                    </div>

                    {isCurrent && (
                      <CheckCircle2 className="h-4 w-4 text-amber-400 shrink-0" />
                    )}
                  </button>
                );
              })}
            </div>
          </div>
        ) : (
          /* Bookmarks Tab */
          <div className="flex-1 overflow-y-auto p-4 space-y-3">
            {bookmarks.length === 0 ? (
              <div className="py-12 text-center text-neutral-500">
                <BookmarkIcon className="mx-auto h-8 w-8 stroke-[1.5] mb-2 opacity-50" />
                <p className="text-xs">ยังไม่มีที่คั่นหน้าในเรื่องนี้</p>
                <p className="text-[11px] mt-1 text-neutral-600">กดไอคอนที่คั่นหน้าขณะอ่านเพื่อบันทึก</p>
              </div>
            ) : (
              bookmarks.map(bm => {
                const chapIdx = novel.chapters.findIndex(c => c.id === bm.chapterId);
                return (
                  <div
                    key={bm.id}
                    className="p-3 rounded-xl border border-neutral-800 bg-neutral-900/80 space-y-2"
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-amber-400">
                        ตอนที่ {bm.chapterNumber}
                      </span>
                      <button
                        onClick={() => handleDeleteBookmark(bm.id)}
                        className="text-neutral-500 hover:text-red-400 p-1"
                        title="ลบที่คั่นนี้"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </button>
                    </div>

                    <p className="text-xs text-neutral-300 italic line-clamp-2">
                      "{bm.snippet}"
                    </p>

                    <div className="flex items-center justify-between pt-1 text-[10px] text-neutral-500">
                      <span>{new Date(bm.createdAt).toLocaleDateString('th-TH')}</span>
                      <button
                        onClick={() => {
                          if (chapIdx >= 0) {
                            onSelectChapter(chapIdx);
                            onClose();
                          }
                        }}
                        className="text-amber-500 font-semibold hover:underline"
                      >
                        เปิดอ่านตรงนี้ →
                      </button>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        )}

      </div>
    </div>
  );
};
