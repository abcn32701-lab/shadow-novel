import React, { useState } from 'react';
import { Novel, Chapter, AudioSettings, AmbientSoundType } from '../types';
import { 
  Play, 
  Pause, 
  SkipBack, 
  SkipForward, 
  Volume2, 
  VolumeX, 
  Clock, 
  ChevronUp, 
  ChevronDown, 
  Sliders, 
  Headphones, 
  CloudRain, 
  Waves, 
  Flame, 
  Coffee, 
  Moon, 
  TreePine,
  Sparkles,
  ChevronsLeft,
  ChevronsRight
} from 'lucide-react';

interface AudioPlayerBarProps {
  novel: Novel;
  chapter: Chapter;
  paragraphs: string[];
  currentParagraphIndex: number;
  isPlaying: boolean;
  isPaused: boolean;
  onTogglePlayPause: () => void;
  onNextParagraph: () => void;
  onPrevParagraph: () => void;
  onNextChapter?: () => void;
  onPrevChapter?: () => void;
  settings: AudioSettings;
  onUpdateSettings: (newSettings: Partial<AudioSettings>) => void;
  sleepRemainingSeconds: number | null;
  onOpenSleepTimer: () => void;
  availableVoices: SpeechSynthesisVoice[];
}

const AMBIENT_OPTIONS: Array<{ id: AmbientSoundType; label: string; icon: React.ReactNode }> = [
  { id: 'none', label: 'ปิดเสียงบรรยากาศ', icon: <VolumeX className="h-4 w-4" /> },
  { id: 'rain', label: 'ฝนพรำ (Rain)', icon: <CloudRain className="h-4 w-4 text-sky-400" /> },
  { id: 'waves', label: 'คลื่นทะเล (Waves)', icon: <Waves className="h-4 w-4 text-cyan-400" /> },
  { id: 'fireplace', label: 'กองไฟผิง (Fireplace)', icon: <Flame className="h-4 w-4 text-amber-500" /> },
  { id: 'zen_bamboo', label: 'เซนไม้ไผ่ (Zen Bamboo)', icon: <TreePine className="h-4 w-4 text-emerald-400" /> },
  { id: 'night_forest', label: 'ป่ายามราตรี (Night Forest)', icon: <Moon className="h-4 w-4 text-indigo-400" /> },
  { id: 'cafe', label: 'ร้านน้ำชา/กาแฟ (Cafe)', icon: <Coffee className="h-4 w-4 text-orange-400" /> }
];

export const AudioPlayerBar: React.FC<AudioPlayerBarProps> = ({
  novel,
  chapter,
  paragraphs,
  currentParagraphIndex,
  isPlaying,
  isPaused,
  onTogglePlayPause,
  onNextParagraph,
  onPrevParagraph,
  onNextChapter,
  onPrevChapter,
  settings,
  onUpdateSettings,
  sleepRemainingSeconds,
  onOpenSleepTimer,
  availableVoices
}) => {
  const [isExpanded, setIsExpanded] = useState(false);
  const [showAmbientMenu, setShowAmbientMenu] = useState(false);

  const currentParagraphText = paragraphs[currentParagraphIndex] || 'พร้อมอ่านออกเสียง...';
  const progressPercent = paragraphs.length > 0 
    ? Math.min(100, Math.round(((currentParagraphIndex + 1) / paragraphs.length) * 100)) 
    : 0;

  // Format countdown mm:ss
  const formatSleepTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  const speedOptions = [0.75, 1.0, 1.25, 1.5, 1.75, 2.0];

  return (
    <div className="fixed bottom-0 left-0 right-0 z-40 border-t border-neutral-800/90 bg-neutral-950/95 backdrop-blur-xl shadow-2xl transition-all">
      {/* Visual chapter reading progress bar across the very top */}
      <div className="absolute top-0 left-0 right-0 h-1 bg-neutral-800/80 overflow-hidden">
        <div 
          className="h-full bg-gradient-to-r from-amber-500 via-amber-400 to-yellow-300 transition-all duration-300 ease-out shadow-[0_0_8px_rgba(245,158,11,0.6)]"
          style={{ width: `${progressPercent}%` }}
        />
      </div>

      <div className="mx-auto max-w-7xl px-4 py-2.5 sm:px-6">
        
        {/* Main compact player bar */}
        <div className="flex items-center justify-between gap-3 sm:gap-4">
          
          {/* Left: Chapter & Paragraph preview + Equalizer */}
          <div className="flex items-center gap-3 min-w-0 max-w-xs sm:max-w-sm lg:max-w-md">
            <div className="relative flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-amber-500/15 border border-amber-500/30 text-amber-400">
              {isPlaying && !isPaused ? (
                <div className="flex items-end gap-0.5 h-4">
                  <span className="w-1 bg-amber-400 rounded-full animate-[pulse_0.6s_ease-in-out_infinite] h-3" />
                  <span className="w-1 bg-yellow-300 rounded-full animate-[pulse_0.4s_ease-in-out_infinite] h-4" />
                  <span className="w-1 bg-amber-500 rounded-full animate-[pulse_0.7s_ease-in-out_infinite] h-2.5" />
                  <span className="w-1 bg-amber-300 rounded-full animate-[pulse_0.5s_ease-in-out_infinite] h-3.5" />
                </div>
              ) : (
                <Headphones className="h-5 w-5 text-amber-400/80" />
              )}
            </div>

            <div className="min-w-0">
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-neutral-200 truncate">
                  {chapter.title}
                </span>
                <span className="text-[10px] text-amber-400 font-mono bg-amber-500/10 px-1.5 py-0.5 rounded border border-amber-500/20">
                  {currentParagraphIndex + 1}/{paragraphs.length} ({progressPercent}%)
                </span>
              </div>
              <p className="text-[11px] text-neutral-400 truncate italic">
                "{currentParagraphText.slice(0, 60)}..."
              </p>
            </div>
          </div>

          {/* Center: Audio Controls */}
          <div className="flex items-center gap-1 sm:gap-2">
            {/* Previous Chapter */}
            {onPrevChapter && (
              <button
                onClick={onPrevChapter}
                className="p-1.5 text-neutral-400 hover:text-neutral-100 transition-colors hidden sm:inline-flex rounded-lg hover:bg-neutral-900"
                title="ตอนก่อนหน้า"
                aria-label="Previous chapter"
              >
                <ChevronsLeft className="h-4 w-4" />
              </button>
            )}

            {/* Previous Paragraph */}
            <button
              onClick={onPrevParagraph}
              className="p-2 text-neutral-400 hover:text-neutral-100 transition-colors rounded-lg hover:bg-neutral-900"
              title="ย่อหน้าก่อนหน้า"
              aria-label="Previous paragraph"
            >
              <SkipBack className="h-4 w-4" />
            </button>

            {/* Play / Pause Toggle */}
            <button
              onClick={onTogglePlayPause}
              className="flex h-11 w-11 items-center justify-center rounded-full bg-gradient-to-tr from-amber-500 to-yellow-400 text-neutral-950 shadow-lg shadow-amber-500/25 hover:brightness-110 active:scale-95 transition-all"
              title={isPlaying && !isPaused ? 'หยุดชั่วคราว' : 'เล่นเสียงอ่าน'}
              aria-label="Play/Pause"
            >
              {isPlaying && !isPaused ? (
                <Pause className="h-5 w-5 fill-current" />
              ) : (
                <Play className="h-5 w-5 fill-current ml-0.5" />
              )}
            </button>

            {/* Next Paragraph */}
            <button
              onClick={onNextParagraph}
              className="p-2 text-neutral-400 hover:text-neutral-100 transition-colors rounded-lg hover:bg-neutral-900"
              title="ย่อหน้าถัดไป"
              aria-label="Next paragraph"
            >
              <SkipForward className="h-4 w-4" />
            </button>

            {/* Next Chapter */}
            {onNextChapter && (
              <button
                onClick={onNextChapter}
                className="p-1.5 text-neutral-400 hover:text-neutral-100 transition-colors hidden sm:inline-flex rounded-lg hover:bg-neutral-900"
                title="ตอนถัดไป"
                aria-label="Next chapter"
              >
                <ChevronsRight className="h-4 w-4" />
              </button>
            )}
          </div>

          {/* Right: Auto Next Badge, Speed, Soundscape, Sleep Timer & Expand */}
          <div className="flex items-center gap-1.5 sm:gap-2">
            
            {/* Auto Next Chapter Quick Indicator & Switch */}
            <button
              onClick={() => onUpdateSettings({ autoNextChapter: !settings.autoNextChapter })}
              className={`hidden md:flex items-center gap-1.5 px-2.5 py-1 rounded-lg border text-[11px] font-medium transition-colors ${
                settings.autoNextChapter
                  ? 'border-amber-500/40 bg-amber-500/15 text-amber-300'
                  : 'border-neutral-800 bg-neutral-900 text-neutral-500 hover:text-neutral-400'
              }`}
              title={settings.autoNextChapter ? 'อ่านจบตอนแล้วจะเปลี่ยนไปบทถัดไปอัตโนมัติ (คลิกเพื่อปิด)' : 'ไม่เปลี่ยนตอนอัตโนมัติ (คลิกเพื่อเปิด)'}
            >
              <span className={`h-1.5 w-1.5 rounded-full ${settings.autoNextChapter ? 'bg-amber-400 animate-pulse' : 'bg-neutral-600'}`} />
              <span>ตอนต่อไปอัตโนมัติ</span>
            </button>

            {/* Speed selector button */}
            <button
              onClick={() => {
                const currIdx = speedOptions.indexOf(settings.rate);
                const nextSpeed = speedOptions[(currIdx + 1) % speedOptions.length];
                onUpdateSettings({ rate: nextSpeed });
              }}
              className="rounded-lg border border-neutral-800 bg-neutral-900 px-2 py-1 text-xs font-bold text-amber-400 hover:border-neutral-700 transition-colors"
              title="ความเร็วเสียงอ่าน"
            >
              {settings.rate}x
            </button>

            {/* Ambient Soundscape selector button */}
            <div className="relative">
              <button
                onClick={() => setShowAmbientMenu(!showAmbientMenu)}
                className={`flex items-center gap-1.5 rounded-lg border px-2.5 py-1 text-xs font-medium transition-colors ${
                  settings.ambientSound !== 'none'
                    ? 'border-emerald-500/50 bg-emerald-500/15 text-emerald-300'
                    : 'border-neutral-800 bg-neutral-900 text-neutral-400 hover:text-neutral-200'
                }`}
                title="เสียงบรรยากาศ (Ambient Sound)"
              >
                <CloudRain className="h-3.5 w-3.5" />
                <span className="hidden sm:inline">
                  {settings.ambientSound === 'none' ? 'บรรยากาศ' : settings.ambientSound}
                </span>
              </button>

              {/* Ambient Menu Dropdown */}
              {showAmbientMenu && (
                <div className="absolute right-0 bottom-12 w-64 rounded-2xl border border-neutral-800 bg-neutral-900 p-3 text-neutral-100 shadow-2xl z-50">
                  <div className="flex items-center justify-between pb-2 border-b border-neutral-800 text-xs font-bold text-neutral-400">
                    <span>เสียงบรรยากาศประกอบ</span>
                    <button onClick={() => setShowAmbientMenu(false)}>✕</button>
                  </div>

                  <div className="mt-2 space-y-1">
                    {AMBIENT_OPTIONS.map(opt => (
                      <button
                        key={opt.id}
                        onClick={() => {
                          onUpdateSettings({ ambientSound: opt.id });
                          setShowAmbientMenu(false);
                        }}
                        className={`flex w-full items-center gap-2.5 rounded-lg px-2.5 py-1.5 text-xs text-left transition-colors ${
                          settings.ambientSound === opt.id
                            ? 'bg-amber-500/20 text-amber-300 font-bold'
                            : 'hover:bg-neutral-800 text-neutral-300'
                        }`}
                      >
                        {opt.icon}
                        <span>{opt.label}</span>
                      </button>
                    ))}
                  </div>

                  {settings.ambientSound !== 'none' && (
                    <div className="mt-3 pt-2 border-t border-neutral-800">
                      <div className="flex justify-between text-[11px] text-neutral-400 mb-1">
                        <span>ระดับเสียงบรรยากาศ</span>
                        <span>{Math.round(settings.ambientVolume * 100)}%</span>
                      </div>
                      <input
                        type="range"
                        min="0.05"
                        max="1"
                        step="0.05"
                        value={settings.ambientVolume}
                        onChange={(e) => onUpdateSettings({ ambientVolume: parseFloat(e.target.value) })}
                        className="w-full accent-amber-500 cursor-pointer"
                      />
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* Sleep Timer */}
            <button
              onClick={onOpenSleepTimer}
              className={`flex items-center gap-1 rounded-lg border px-2 py-1 text-xs font-medium transition-colors ${
                sleepRemainingSeconds
                  ? 'border-amber-500/50 bg-amber-500/20 text-amber-300 font-bold animate-pulse'
                  : 'border-neutral-800 bg-neutral-900 text-neutral-400 hover:text-neutral-200'
              }`}
              title="ตั้งเวลาปิดการอ่าน"
            >
              <Clock className="h-3.5 w-3.5" />
              {sleepRemainingSeconds ? formatSleepTime(sleepRemainingSeconds) : <span className="hidden sm:inline">ตั้งเวลา</span>}
            </button>

            {/* Expand / Minimize Details */}
            <button
              onClick={() => setIsExpanded(!isExpanded)}
              className="p-1.5 text-neutral-400 hover:text-neutral-200 rounded-lg hover:bg-neutral-900"
              aria-label="Toggle Player Details"
            >
              {isExpanded ? <ChevronDown className="h-4 w-4" /> : <ChevronUp className="h-4 w-4" />}
            </button>

          </div>

        </div>

        {/* Expanded Panel for Voice and Audio Settings */}
        {isExpanded && (
          <div className="mt-3 pt-3 border-t border-neutral-800 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 text-xs">
            
            {/* Voice Selection */}
            <div>
              <label className="text-neutral-400 block mb-1">เสียงผู้บรรยาย (TTS Voice)</label>
              <select
                value={settings.voiceURI}
                onChange={(e) => onUpdateSettings({ voiceURI: e.target.value })}
                className="w-full rounded-lg border border-neutral-800 bg-neutral-900 p-2 text-neutral-200 focus:outline-none focus:border-amber-500/40"
              >
                {availableVoices.map((v, idx) => (
                  <option key={`voice-bar-${v.voiceURI || v.name}-${v.lang}-${idx}`} value={v.voiceURI}>
                    {v.name} ({v.lang})
                  </option>
                ))}
              </select>
            </div>

            {/* Pitch adjustment */}
            <div>
              <div className="flex justify-between text-neutral-400 mb-1">
                <span>โทนเสียงสูงต่ำ (Pitch)</span>
                <span>{settings.pitch.toFixed(1)}x</span>
              </div>
              <input
                type="range"
                min="0.7"
                max="1.3"
                step="0.05"
                value={settings.pitch}
                onChange={(e) => onUpdateSettings({ pitch: parseFloat(e.target.value) })}
                className="w-full accent-amber-500 cursor-pointer"
              />
            </div>

            {/* Auto-Next Chapter Toggle */}
            <div className="flex items-center justify-between sm:col-span-2 lg:col-span-1 bg-neutral-900/80 p-2.5 rounded-xl border border-neutral-800">
              <div>
                <span className="text-neutral-200 font-medium block">อ่านต่อตอนถัดไปอัตโนมัติ</span>
                <span className="text-[10px] text-neutral-500">เมื่ออ่านจบย่อหน้าสุดท้ายจะเปลี่ยนตอนทันที</span>
              </div>
              <input
                type="checkbox"
                checked={settings.autoNextChapter}
                onChange={(e) => onUpdateSettings({ autoNextChapter: e.target.checked })}
                className="h-4 w-4 accent-amber-500 rounded cursor-pointer"
              />
            </div>

          </div>
        )}

      </div>
    </div>
  );
};
