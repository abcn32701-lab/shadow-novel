import React, { useState } from 'react';
import { Novel, Chapter } from '../types';
import { Plus, X, BookOpen, FileUp } from 'lucide-react';
import { detectChapterTitle, estimateReadingTime } from '../utils/textParser';

interface AddChapterModalProps {
  isOpen: boolean;
  onClose: () => void;
  novel: Novel;
  onAddChapter: (chapter: Chapter) => void;
  onOpenBatchImport?: () => void;
}

export const AddChapterModal: React.FC<AddChapterModalProps> = ({
  isOpen,
  onClose,
  novel,
  onAddChapter,
  onOpenBatchImport
}) => {
  const nextNum = novel.chapters.length + 1;
  const [chapterNumber, setChapterNumber] = useState(nextNum);
  const [title, setTitle] = useState(`ตอนที่ ${nextNum}`);
  const [content, setContent] = useState('');

  if (!isOpen) return null;

  const handlePasteDetect = (pastedText: string) => {
    setContent(pastedText);
    const detected = detectChapterTitle(pastedText);
    if (detected.chapterNumber) {
      setChapterNumber(detected.chapterNumber);
      setTitle(`ตอนที่ ${detected.chapterNumber}: ${detected.title}`);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!content.trim()) {
      alert('กรุณากรอกเนื้อหาของตอน');
      return;
    }

    const { wordCount } = estimateReadingTime(content);

    const newChap: Chapter = {
      id: 'chap_' + novel.id + '_' + Date.now(),
      novelId: novel.id,
      chapterNumber,
      title: title.trim() || `ตอนที่ ${chapterNumber}`,
      content: content.trim(),
      wordCount,
      publishedAt: new Date().toISOString().split('T')[0]
    };

    onAddChapter(newChap);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4">
      <div 
        className="w-full max-w-xl rounded-3xl border border-neutral-800 bg-neutral-950 p-6 text-neutral-100 shadow-2xl flex flex-col max-h-[90vh]"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between pb-3 border-b border-neutral-800">
          <div>
            <span className="text-xs text-amber-500 font-semibold">{novel.titleThai}</span>
            <h2 className="text-base font-bold font-serif">เพิ่มตอนใหม่</h2>
          </div>
          <button onClick={onClose} className="p-1.5 rounded-lg text-neutral-400 hover:text-white">
            <X className="h-5 w-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="mt-4 space-y-4 flex-1 flex flex-col min-h-0">
          {onOpenBatchImport && (
            <div className="flex items-center justify-between rounded-xl border border-amber-500/30 bg-amber-500/10 p-2.5">
              <div className="flex items-center gap-2">
                <FileUp className="h-4 w-4 text-amber-400 shrink-0" />
                <span className="text-xs text-amber-300">มีไฟล์หลายตอน (.TXT / .PDF)?</span>
              </div>
              <button
                type="button"
                onClick={() => {
                  onClose();
                  onOpenBatchImport();
                }}
                className="rounded-lg bg-amber-500 px-2.5 py-1 text-[11px] font-bold text-neutral-950 hover:bg-amber-400"
              >
                นำเข้าหลายตอนพร้อมกัน
              </button>
            </div>
          )}

          <div className="grid grid-cols-3 gap-3">
            <div>
              <label className="text-xs font-semibold text-neutral-300 block mb-1">ตอนที่</label>
              <input
                type="number"
                min="1"
                value={chapterNumber}
                onChange={(e) => setChapterNumber(parseInt(e.target.value, 10) || 1)}
                className="w-full rounded-xl border border-neutral-800 bg-neutral-900 p-2.5 text-xs text-neutral-100 focus:border-amber-500 focus:outline-none"
              />
            </div>
            <div className="col-span-2">
              <label className="text-xs font-semibold text-neutral-300 block mb-1">ชื่อตอน</label>
              <input
                type="text"
                required
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="เช่น การประลองบนลานหิน..."
                className="w-full rounded-xl border border-neutral-800 bg-neutral-900 p-2.5 text-xs text-neutral-100 focus:border-amber-500 focus:outline-none"
              />
            </div>
          </div>

          <div className="flex-1 flex flex-col min-h-0">
            <label className="text-xs font-semibold text-neutral-300 block mb-1">
              เนื้อหาของตอน (รองรับการวางข้อความดิบ ระบบจะแยกย่อหน้าให้อัตโนมัติ) *
            </label>
            <textarea
              required
              rows={10}
              value={content}
              onChange={(e) => handlePasteDetect(e.target.value)}
              placeholder="วางเนื้อหานิยายที่นี่..."
              className="flex-1 w-full rounded-2xl border border-neutral-800 bg-neutral-900 p-3 text-xs leading-relaxed text-neutral-100 focus:border-amber-500 focus:outline-none resize-none"
            />
          </div>

          <div className="flex justify-end gap-3 pt-3 border-t border-neutral-800">
            <button
              type="button"
              onClick={onClose}
              className="rounded-xl border border-neutral-800 px-4 py-2 text-xs font-semibold text-neutral-400 hover:text-white"
            >
              ยกเลิก
            </button>
            <button
              type="submit"
              className="rounded-xl bg-amber-500 px-5 py-2 text-xs font-bold text-neutral-950 hover:bg-amber-400 shadow-md shadow-amber-500/20"
            >
              บันทึกตอนใหม่
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
