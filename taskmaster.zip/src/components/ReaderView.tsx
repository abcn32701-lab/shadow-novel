import React, { useState, useEffect, useRef } from 'react';
import { Novel, Chapter, ReaderSettings, CultivationTerm } from '../types';
import { 
  ArrowLeft, 
  ChevronLeft, 
  ChevronRight, 
  List, 
  Bookmark, 
  BookmarkCheck,
  Maximize2, 
  Minimize2, 
  Type, 
  Headphones, 
  Share2, 
  Sparkles,
  Info,
  Clock,
  BookOpen
} from 'lucide-react';
import { splitIntoParagraphs, estimateReadingTime } from '../utils/textParser';
import { CULTIVATION_TERMS } from '../utils/chineseNovelHelper';
import { authService } from '../utils/authService';

interface ReaderViewProps {
  novel: Novel;
  chapterIndex: number;
  onBack: () => void;
  onSelectChapter: (index: number) => void;
  onOpenTableOfContents: () => void;
  onOpenAIToolsWithText: (text: string, defaultMode?: 'summarize' | 'translate') => void;
  onOpenShareModal: (quote: string, novelTitle: string, chapterTitle: string) => void;
  readerSettings: ReaderSettings;
  onUpdateReaderSettings: (newSettings: Partial<ReaderSettings>) => void;
  currentAudioParagraphIndex: number;
  isAudioPlaying: boolean;
  onPlayParagraphFromReader: (index: number) => void;
}

export const ReaderView: React.FC<ReaderViewProps> = ({
  novel,
  chapterIndex,
  onBack,
  onSelectChapter,
  onOpenTableOfContents,
  onOpenAIToolsWithText,
  onOpenShareModal,
  readerSettings,
  onUpdateReaderSettings,
  currentAudioParagraphIndex,
  isAudioPlaying,
  onPlayParagraphFromReader
}) => {
  const currentChapter = novel.chapters[chapterIndex] || novel.chapters[0];
  const paragraphs = React.useMemo(() => splitIntoParagraphs(currentChapter.content), [currentChapter.content]);
  
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [showSettingsPopover, setShowSettingsPopover] = useState(false);
  const [activeGlossaryTerm, setActiveGlossaryTerm] = useState<CultivationTerm | null>(null);
  const [readingProgress, setReadingProgress] = useState(0);
  const [bookmarked, setBookmarked] = useState(false);
  
  const activeParagraphRef = useRef<HTMLParagraphElement | null>(null);
  const readerContainerRef = useRef<HTMLDivElement | null>(null);

  // Scroll to active paragraph when audio is playing
  useEffect(() => {
    if (isAudioPlaying && activeParagraphRef.current) {
      activeParagraphRef.current.scrollIntoView({
        behavior: 'smooth',
        block: 'center'
      });
    }
  }, [currentAudioParagraphIndex, isAudioPlaying]);

  // Track scroll progress & save history
  useEffect(() => {
    const handleScroll = () => {
      const el = document.documentElement;
      const totalHeight = el.scrollHeight - el.clientHeight;
      if (totalHeight > 0) {
        const percent = Math.min(100, Math.max(0, Math.round((el.scrollTop / totalHeight) * 100)));
        setReadingProgress(percent);
        
        // Update reading history in background every so often
        authService.updateReadingHistory(
          novel.id,
          currentChapter.id,
          currentChapter.chapterNumber,
          currentAudioParagraphIndex,
          percent
        );
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, [novel.id, currentChapter.id, currentChapter.chapterNumber, currentAudioParagraphIndex]);

  // Fullscreen toggle
  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen().then(() => setIsFullscreen(true)).catch(() => {});
    } else {
      document.exitFullscreen().then(() => setIsFullscreen(false)).catch(() => {});
    }
  };

  // Bookmark current position
  const handleBookmark = () => {
    authService.addBookmark({
      novelId: novel.id,
      chapterId: currentChapter.id,
      chapterNumber: currentChapter.chapterNumber,
      paragraphIndex: currentAudioParagraphIndex,
      snippet: paragraphs[currentAudioParagraphIndex]?.slice(0, 100) || currentChapter.title
    });
    setBookmarked(true);
    setTimeout(() => setBookmarked(false), 2500);
  };

  // Reader theme class mappings
  const themeClasses: Record<string, { bg: string; text: string; subtext: string; border: string; highlight: string }> = {
    dark: {
      bg: 'bg-neutral-950',
      text: 'text-neutral-200',
      subtext: 'text-neutral-500',
      border: 'border-neutral-800',
      highlight: 'bg-amber-500/20 text-amber-100 ring-1 ring-amber-500/40'
    },
    midnight: {
      bg: 'bg-black',
      text: 'text-neutral-300',
      subtext: 'text-neutral-600',
      border: 'border-neutral-900',
      highlight: 'bg-blue-600/20 text-blue-100 ring-1 ring-blue-500/40'
    },
    sepia: {
      bg: 'bg-[#f4ecd8]',
      text: 'text-[#433422]',
      subtext: 'text-[#8c7355]',
      border: 'border-[#dfd3b9]',
      highlight: 'bg-[#e2cb9c] text-[#2b1f13] ring-1 ring-[#c2a66e]'
    },
    emerald: {
      bg: 'bg-[#0f241d]',
      text: 'text-[#d1fae5]',
      subtext: 'text-[#6ee7b7]/60',
      border: 'border-[#1b4332]',
      highlight: 'bg-emerald-500/25 text-emerald-100 ring-1 ring-emerald-400/50'
    },
    paper: {
      bg: 'bg-[#fbfbf8]',
      text: 'text-[#1c1917]',
      subtext: 'text-[#78716c]',
      border: 'border-[#e7e5e4]',
      highlight: 'bg-amber-200/60 text-neutral-900 ring-1 ring-amber-300'
    },
    light: {
      bg: 'bg-white',
      text: 'text-neutral-850',
      subtext: 'text-neutral-400',
      border: 'border-neutral-200',
      highlight: 'bg-amber-100 text-neutral-900 ring-1 ring-amber-300'
    }
  };

  const currentTheme = themeClasses[readerSettings.theme] || themeClasses.dark;

  // Font family class mappings
  const fontClasses: Record<string, string> = {
    sarabun: 'font-["Sarabun",sans-serif]',
    kanit: 'font-["Kanit",sans-serif]',
    baijamjuree: 'font-["Bai_Jamjuree",sans-serif]',
    serif: 'font-["Noto_Serif_Thai",serif]',
    sans: 'font-sans',
    mono: 'font-mono'
  };

  const maxWidthClasses: Record<string, string> = {
    narrow: 'max-w-xl',
    prose: 'max-w-3xl',
    wide: 'max-w-4xl',
    full: 'max-w-5xl'
  };

  const { minutes } = estimateReadingTime(currentChapter.content);

  // Render paragraph with highlighted Chinese cultivation terms
  const renderParagraphContent = (text: string, pIdx: number) => {
    if (!readerSettings.showChineseAnnotation) {
      return text;
    }

    // Check matches in cultivation dictionary
    let elements: React.ReactNode[] = [text];
    let keyCounter = 0;

    CULTIVATION_TERMS.forEach(term => {
      const keyword = term.thai.split(' ')[0];
      const newElements: React.ReactNode[] = [];

      elements.forEach(part => {
        if (typeof part !== 'string') {
          newElements.push(part);
          return;
        }

        const index = part.indexOf(keyword);
        if (index === -1) {
          newElements.push(part);
          return;
        }

        const before = part.slice(0, index);
        const match = part.slice(index, index + keyword.length);
        const after = part.slice(index + keyword.length);

        if (before) newElements.push(before);
        newElements.push(
          <button
            key={`p-${pIdx}-term-${term.chinese}-${keyCounter++}`}
            onClick={(e) => {
              e.stopPropagation();
              setActiveGlossaryTerm(term);
            }}
            className="inline font-semibold underline decoration-amber-500/60 decoration-dashed underline-offset-4 hover:text-amber-400 hover:decoration-amber-400 transition-colors"
            title={`คลิกเพื่อดูคำอธิบาย: ${term.thai}`}
          >
            {match}
          </button>
        );
        if (after) newElements.push(after);
      });

      elements = newElements;
    });

    return elements;
  };

  return (
    <div 
      ref={readerContainerRef}
      className={`min-h-screen transition-colors duration-200 ${currentTheme.bg} ${currentTheme.text}`}
    >
      {/* Top Reading Progress Bar */}
      <div className="fixed top-0 left-0 right-0 z-50 h-1 bg-neutral-800/40">
        <div 
          className="h-full bg-gradient-to-r from-amber-500 to-yellow-400 transition-all duration-150"
          style={{ width: `${readingProgress}%` }}
        />
      </div>

      {/* Floating Reader Header */}
      <header className={`sticky top-0 z-40 border-b backdrop-blur-md transition-colors ${currentTheme.bg}/90 ${currentTheme.border}`}>
        <div className="mx-auto flex h-14 max-w-7xl items-center justify-between px-4 sm:px-6">
          
          {/* Left: Back & Table of contents */}
          <div className="flex items-center gap-2">
            <button
              onClick={onBack}
              className="flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-xs font-medium hover:bg-neutral-500/10 transition-colors"
            >
              <ArrowLeft className="h-4 w-4" />
              <span className="hidden sm:inline">หน้าหลัก</span>
            </button>

            <button
              onClick={onOpenTableOfContents}
              className="flex items-center gap-1.5 rounded-lg border border-neutral-700/50 px-2.5 py-1.5 text-xs font-medium hover:bg-neutral-500/10 transition-colors"
              title="สารบัญตอนทั้งหมด"
            >
              <List className="h-4 w-4 text-amber-500" />
              <span className="hidden sm:inline">สารบัญ</span>
            </button>
          </div>

          {/* Center: Novel & Chapter Title */}
          <div className="flex-1 text-center px-4 max-w-md truncate">
            <span className="text-xs font-bold truncate block">
              {currentChapter.title}
            </span>
            <span className={`text-[11px] truncate block ${currentTheme.subtext}`}>
              {novel.titleThai}
            </span>
          </div>

          {/* Right: Actions */}
          <div className="flex items-center gap-1.5 sm:gap-2">
            
            {/* Bookmark button */}
            <button
              onClick={handleBookmark}
              className="p-2 rounded-lg hover:bg-neutral-500/10 text-neutral-400 hover:text-amber-400 transition-colors"
              title="บันทึกหน้าที่กำลังอ่าน"
            >
              {bookmarked ? (
                <BookmarkCheck className="h-4 w-4 text-amber-400" />
              ) : (
                <Bookmark className="h-4 w-4" />
              )}
            </button>

            {/* AI Assistant button */}
            <button
              onClick={() => onOpenAIToolsWithText(currentChapter.content)}
              className="flex items-center gap-1 p-2 rounded-lg bg-purple-500/15 text-purple-400 hover:bg-purple-500/25 border border-purple-500/30 transition-colors"
              title="สรุปหรือแปลด้วย AI"
            >
              <Sparkles className="h-4 w-4" />
              <span className="hidden lg:inline text-xs font-semibold">AI สรุป/แปล</span>
            </button>

            {/* Reader Typography Settings Trigger */}
            <div className="relative">
              <button
                onClick={() => setShowSettingsPopover(!showSettingsPopover)}
                className="p-2 rounded-lg hover:bg-neutral-500/10 transition-colors"
                title="ปรับขนาดตัวอักษรและธีม"
              >
                <Type className="h-4 w-4" />
              </button>

              {/* Settings Popover */}
              {showSettingsPopover && (
                <div className="absolute right-0 top-12 w-80 rounded-2xl border border-neutral-700/80 bg-neutral-900 p-4 text-neutral-100 shadow-2xl z-50">
                  <div className="flex items-center justify-between pb-2 border-b border-neutral-800">
                    <span className="text-sm font-bold">ปรับแต่งการอ่าน</span>
                    <button
                      onClick={() => setShowSettingsPopover(false)}
                      className="text-xs text-neutral-400 hover:text-white"
                    >
                      ปิด
                    </button>
                  </div>

                  {/* Theme Colors */}
                  <div className="mt-3 space-y-2">
                    <label className="text-xs font-medium text-neutral-400">โทนสีอ่านสบายตา</label>
                    <div className="grid grid-cols-3 gap-1.5">
                      {[
                        { id: 'dark', label: 'มืด (Dark)', bg: 'bg-neutral-950', border: 'border-neutral-800' },
                        { id: 'sepia', label: 'ซีเปีย (Sepia)', bg: 'bg-[#f4ecd8] text-[#433422]', border: 'border-[#dfd3b9]' },
                        { id: 'emerald', label: 'เขียวถนอมตา', bg: 'bg-[#0f241d] text-[#6ee7b7]', border: 'border-[#1b4332]' },
                        { id: 'paper', label: 'กระดาษนวล', bg: 'bg-[#fbfbf8] text-neutral-800', border: 'border-[#e7e5e4]' },
                        { id: 'midnight', label: 'ดำสนิท OLED', bg: 'bg-black text-neutral-300', border: 'border-neutral-900' },
                        { id: 'light', label: 'สว่าง (Light)', bg: 'bg-white text-neutral-900', border: 'border-neutral-300' },
                      ].map(item => (
                        <button
                          key={item.id}
                          onClick={() => onUpdateReaderSettings({ theme: item.id as any })}
                          className={`flex items-center justify-center rounded-lg p-2 text-xs font-semibold border ${item.bg} ${item.border} ${
                            readerSettings.theme === item.id ? 'ring-2 ring-amber-500' : ''
                          }`}
                        >
                          {item.label}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Font Size */}
                  <div className="mt-4 space-y-2">
                    <div className="flex justify-between text-xs text-neutral-400">
                      <span>ขนาดตัวอักษร</span>
                      <span className="font-bold text-amber-400">{readerSettings.fontSize}px</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => onUpdateReaderSettings({ fontSize: Math.max(14, readerSettings.fontSize - 1) })}
                        className="h-8 w-8 rounded-lg bg-neutral-800 font-bold hover:bg-neutral-700"
                      >
                        A-
                      </button>
                      <input
                        type="range"
                        min="14"
                        max="30"
                        value={readerSettings.fontSize}
                        onChange={(e) => onUpdateReaderSettings({ fontSize: Number(e.target.value) })}
                        className="flex-1 accent-amber-500 cursor-pointer"
                      />
                      <button
                        onClick={() => onUpdateReaderSettings({ fontSize: Math.min(30, readerSettings.fontSize + 1) })}
                        className="h-8 w-8 rounded-lg bg-neutral-800 font-bold hover:bg-neutral-700"
                      >
                        A+
                      </button>
                    </div>
                  </div>

                  {/* Font Family */}
                  <div className="mt-4 space-y-2">
                    <label className="text-xs font-medium text-neutral-400">แบบอักษร</label>
                    <div className="grid grid-cols-2 gap-1.5">
                      {[
                        { id: 'sarabun', label: 'สารบรรณ (Sarabun)' },
                        { id: 'kanit', label: 'คณิต (Kanit)' },
                        { id: 'baijamjuree', label: 'จามจุรี (Bai Jamjuree)' },
                        { id: 'serif', label: 'เซริฟ (Serif โบราณ)' }
                      ].map(f => (
                        <button
                          key={f.id}
                          onClick={() => onUpdateReaderSettings({ font: f.id as any })}
                          className={`rounded-lg p-2 text-xs border text-left truncate transition-colors ${
                            readerSettings.font === f.id
                              ? 'bg-amber-500/20 border-amber-500 text-amber-300 font-bold'
                              : 'bg-neutral-800/80 border-neutral-700 text-neutral-300 hover:bg-neutral-700'
                          }`}
                        >
                          {f.label}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Line Height & Width */}
                  <div className="mt-4 grid grid-cols-2 gap-3 pt-3 border-t border-neutral-800">
                    <div>
                      <label className="text-xs text-neutral-400 block mb-1">ระยะห่างบรรทัด</label>
                      <select
                        value={readerSettings.lineHeight}
                        onChange={(e) => onUpdateReaderSettings({ lineHeight: Number(e.target.value) })}
                        className="w-full rounded-lg border border-neutral-700 bg-neutral-800 p-1.5 text-xs text-neutral-200"
                      >
                        <option value="1.6">พอดี (1.6x)</option>
                        <option value="1.9">สบายตา (1.9x)</option>
                        <option value="2.2">กว้าง (2.2x)</option>
                      </select>
                    </div>

                    <div>
                      <label className="text-xs text-neutral-400 block mb-1">ความกว้างหน้า</label>
                      <select
                        value={readerSettings.maxWidth}
                        onChange={(e) => onUpdateReaderSettings({ maxWidth: e.target.value as any })}
                        className="w-full rounded-lg border border-neutral-700 bg-neutral-800 p-1.5 text-xs text-neutral-200"
                      >
                        <option value="narrow">กะทัดรัด</option>
                        <option value="prose">มาตรฐาน</option>
                        <option value="wide">กว้าง</option>
                        <option value="full">เต็มจอ</option>
                      </select>
                    </div>
                  </div>

                  {/* Chinese Annotation Toggle */}
                  <div className="mt-4 pt-3 border-t border-neutral-800 flex items-center justify-between">
                    <span className="text-xs text-neutral-300">คำศัพท์กำลังภายใน (จิ้มดูความหมาย)</span>
                    <input
                      type="checkbox"
                      checked={readerSettings.showChineseAnnotation}
                      onChange={(e) => onUpdateReaderSettings({ showChineseAnnotation: e.target.checked })}
                      className="h-4 w-4 accent-amber-500 rounded cursor-pointer"
                    />
                  </div>

                </div>
              )}
            </div>

            {/* Fullscreen button */}
            <button
              onClick={toggleFullscreen}
              className="p-2 rounded-lg hover:bg-neutral-500/10 transition-colors hidden sm:block"
              title="เต็มจอ"
            >
              {isFullscreen ? <Minimize2 className="h-4 w-4" /> : <Maximize2 className="h-4 w-4" />}
            </button>

          </div>
        </div>
      </header>

      {/* Main Reader Content */}
      <main className="mx-auto px-4 py-8 sm:py-12">
        <article className={`mx-auto ${maxWidthClasses[readerSettings.maxWidth] || 'max-w-3xl'}`}>
          
          {/* Chapter Header Banner */}
          <div className="mb-10 text-center border-b border-neutral-800/40 pb-8">
            <span className={`text-xs font-semibold tracking-wider uppercase ${currentTheme.subtext}`}>
              {novel.titleThai} • ตอนที่ {currentChapter.chapterNumber}
            </span>
            <h1 className="mt-2 font-serif text-2xl sm:text-3xl font-extrabold tracking-tight">
              {currentChapter.title}
            </h1>
            <div className={`mt-3 flex items-center justify-center gap-4 text-xs ${currentTheme.subtext}`}>
              <span className="flex items-center gap-1">
                <Clock className="h-3.5 w-3.5" />
                ประมาณ {minutes} นาที
              </span>
              <span>•</span>
              <span className="flex items-center gap-1">
                <BookOpen className="h-3.5 w-3.5" />
                {currentChapter.wordCount.toLocaleString()} คำ
              </span>
            </div>
          </div>

          {/* Chinese Content Translation Notice */}
          {/[\u4e00-\u9fa5]/.test(currentChapter.content) && (
            <div className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-purple-500/40 bg-purple-500/10 p-3.5 mb-8">
              <div className="flex items-center gap-2.5">
                <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-purple-500/20 text-purple-300 font-serif font-bold text-sm shrink-0">
                  译
                </div>
                <div>
                  <p className="text-xs font-bold text-purple-300">ตรวจพบเนื้อหาภาษาจีนในบทนี้</p>
                  <p className="text-[11px] text-neutral-400">ต้องการแปลบทนี้เป็นภาษาไทยสละสลวยด้วย AI เพื่อให้ระบบอ่านออกเสียงเป็นภาษาไทยหรือไม่?</p>
                </div>
              </div>
              <button
                onClick={() => onOpenAIToolsWithText(currentChapter.content, 'translate')}
                className="shrink-0 flex items-center gap-1.5 rounded-xl bg-purple-500 px-3.5 py-1.5 text-xs font-bold text-neutral-950 hover:bg-purple-400 transition-colors shadow-md shadow-purple-500/20"
              >
                <Sparkles className="h-3.5 w-3.5" />
                <span>แปลบทนี้ด้วย AI</span>
              </button>
            </div>
          )}

          {/* Paragraphs with interactive click-to-audio and highlighting */}
          <div 
            className={`space-y-6 ${fontClasses[readerSettings.font] || 'font-sans'} text-left selection:bg-amber-500/30`}
            style={{ 
              fontSize: `${readerSettings.fontSize}px`, 
              lineHeight: readerSettings.lineHeight,
              letterSpacing: `${readerSettings.letterSpacing}px`
            }}
          >
            {paragraphs.map((p, idx) => {
              const isCurrentPlaying = isAudioPlaying && currentAudioParagraphIndex === idx;

              return (
                <div
                  key={`para-${currentChapter.id}-${idx}`}
                  ref={isCurrentPlaying ? activeParagraphRef : null}
                  onClick={() => onPlayParagraphFromReader(idx)}
                  className={`group relative rounded-xl px-4 py-2.5 -mx-4 transition-all duration-200 cursor-pointer ${
                    isCurrentPlaying 
                      ? currentTheme.highlight 
                      : 'hover:bg-neutral-500/5'
                  }`}
                >
                  {/* Currently playing sound wave or hover play button */}
                  {isCurrentPlaying ? (
                    <div className="absolute -left-3 top-3.5 flex h-6 w-6 items-center justify-center rounded-full bg-amber-500 text-neutral-950 shadow-md shadow-amber-500/30">
                      <div className="flex items-end gap-0.5 h-3">
                        <span className="w-0.5 bg-neutral-950 rounded-full animate-[pulse_0.6s_ease-in-out_infinite] h-2.5" />
                        <span className="w-0.5 bg-neutral-950 rounded-full animate-[pulse_0.4s_ease-in-out_infinite] h-3" />
                        <span className="w-0.5 bg-neutral-950 rounded-full animate-[pulse_0.7s_ease-in-out_infinite] h-2" />
                      </div>
                    </div>
                  ) : (
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onPlayParagraphFromReader(idx);
                      }}
                      className="absolute -left-3 top-3.5 hidden h-6 w-6 items-center justify-center rounded-full bg-amber-500 text-neutral-950 shadow-md group-hover:flex transition-transform hover:scale-110"
                      title="เริ่มอ่านออกเสียงจากย่อหน้านี้"
                    >
                      <Headphones className="h-3 w-3" />
                    </button>
                  )}

                  <p className="leading-relaxed indent-6">
                    {renderParagraphContent(p, idx)}
                  </p>
                </div>
              );
            })}
          </div>

          {/* Bottom Chapter Navigation */}
          <div className="mt-16 pt-8 border-t border-neutral-800/60 flex flex-col sm:flex-row items-center justify-between gap-4">
            <button
              onClick={() => onSelectChapter(chapterIndex - 1)}
              disabled={chapterIndex <= 0}
              className="flex w-full sm:w-auto items-center justify-center gap-2 rounded-xl border border-neutral-700/80 bg-neutral-900/60 px-5 py-3 text-sm font-semibold disabled:opacity-30 disabled:pointer-events-none hover:border-amber-500/60 hover:bg-neutral-800 transition-all"
            >
              <ChevronLeft className="h-4 w-4" />
              ตอนก่อนหน้า
            </button>

            <button
              onClick={onOpenTableOfContents}
              className="flex w-full sm:w-auto items-center justify-center gap-2 rounded-xl border border-neutral-700/80 bg-neutral-900/60 px-5 py-3 text-sm font-semibold hover:border-amber-500/60 hover:bg-neutral-800 transition-all"
            >
              <List className="h-4 w-4 text-amber-400" />
              สารบัญ ({chapterIndex + 1}/{novel.chapters.length})
            </button>

            <button
              onClick={() => onSelectChapter(chapterIndex + 1)}
              disabled={chapterIndex >= novel.chapters.length - 1}
              className="flex w-full sm:w-auto items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 px-6 py-3 text-sm font-bold text-neutral-950 shadow-lg shadow-amber-500/20 disabled:opacity-30 disabled:pointer-events-none hover:brightness-110 transition-all"
            >
              ตอนถัดไป
              <ChevronRight className="h-4 w-4 stroke-[2.5]" />
            </button>
          </div>

        </article>
      </main>

      {/* Interactive Cultivation Glossary Popover Modal */}
      {activeGlossaryTerm && (
        <div 
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4"
          onClick={() => setActiveGlossaryTerm(null)}
        >
          <div 
            className="w-full max-w-md rounded-2xl border border-amber-500/40 bg-neutral-950 p-6 text-neutral-100 shadow-2xl relative"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-start justify-between">
              <div>
                <span className="rounded bg-amber-500/15 px-2 py-0.5 text-xs font-semibold text-amber-400">
                  {activeGlossaryTerm.category === 'realm' ? 'ลำดับขั้นพลัง' : 'คำศัพท์วิถีเซียน'}
                </span>
                <h3 className="mt-2 text-xl font-bold font-serif text-amber-300">
                  {activeGlossaryTerm.thai}
                </h3>
                <p className="text-xs text-neutral-400 font-mono">
                  {activeGlossaryTerm.chinese} • {activeGlossaryTerm.pinyin}
                </p>
              </div>
              <button
                onClick={() => setActiveGlossaryTerm(null)}
                className="rounded-lg p-1.5 text-neutral-400 hover:text-white"
              >
                ✕
              </button>
            </div>

            <p className="mt-4 text-sm leading-relaxed text-neutral-300 bg-neutral-900/80 p-3 rounded-xl border border-neutral-800">
              {activeGlossaryTerm.meaning}
            </p>

            <div className="mt-5 flex justify-end">
              <button
                onClick={() => setActiveGlossaryTerm(null)}
                className="rounded-xl bg-amber-500 px-4 py-2 text-xs font-bold text-neutral-950 hover:bg-amber-400"
              >
                เข้าใจแล้ว
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
