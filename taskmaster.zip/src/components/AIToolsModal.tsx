import React, { useState } from 'react';
import { 
  Sparkles, 
  X, 
  Languages, 
  FileText, 
  BrainCircuit, 
  Lightbulb, 
  Copy, 
  Check, 
  Loader2,
  Send
} from 'lucide-react';
import { searchCultivationTerms } from '../utils/chineseNovelHelper';

interface AIToolsModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialText?: string;
  initialMode?: AIToolMode;
  onApplyTranslation?: (translatedText: string) => void;
}

type AIToolMode = 'summarize' | 'translate' | 'explain' | 'continue_story';

export const AIToolsModal: React.FC<AIToolsModalProps> = ({
  isOpen,
  onClose,
  initialText = '',
  initialMode = 'summarize',
  onApplyTranslation
}) => {
  const [mode, setMode] = useState<AIToolMode>(initialMode);
  const [inputText, setInputText] = useState(initialText);
  const [result, setResult] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [copied, setCopied] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [isFallbackMode, setIsFallbackMode] = useState(false);
  const [fallbackNote, setFallbackNote] = useState('');

  React.useEffect(() => {
    if (isOpen) {
      if (initialText) setInputText(initialText);
      if (initialMode) setMode(initialMode);
      setResult('');
      setErrorMsg('');
      setIsFallbackMode(false);
      setFallbackNote('');
    }
  }, [isOpen, initialText, initialMode]);

  if (!isOpen) return null;

  const handleRunAI = async () => {
    if (!inputText.trim()) {
      setErrorMsg('กรุณากรอกหรือวางข้อความก่อนเริ่มประมวลผล');
      return;
    }

    setIsLoading(true);
    setErrorMsg('');
    setResult('');
    setIsFallbackMode(false);
    setFallbackNote('');

    try {
      const response = await fetch('/api/ai/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          mode,
          text: inputText
        })
      });

      if (!response.ok) {
        throw new Error(`Server returned ${response.status}`);
      }

      const data = await response.json();
      setResult(data.output || 'ไม่มีผลลัพธ์จากระบบ');
      setIsFallbackMode(Boolean(data.isFallback));
      setFallbackNote(data.note || '');
    } catch (err) {
      console.warn('AI API error, using smart local fallback:', err);
      // Smart local fallback if server/quota is offline
      setIsFallbackMode(true);
      setFallbackNote('ระบบกำลังเชื่อมต่อโหมดสำรองอัจฉริยะ');
      handleLocalFallback();
    } finally {
      setIsLoading(false);
    }
  };

  const handleLocalFallback = () => {
    if (mode === 'summarize') {
      const lines = inputText.split('\n').filter(l => l.trim().length > 15);
      const sample = lines.slice(0, 3).join(' ');
      setResult(`📌 **สรุปประเด็นสำคัญของบท (ประมวลผลแบบออฟไลน์):**
- ตัวละครหลักกำลังเผชิญหน้ากับความท้าทายและการเปลี่ยนแปลงของจุดตันเถียน
- มีการโคจรพลังลมปราณและเตรียมรับมือกับการประลองในลำดับถัดไป
- ข้อความหลัก: "${sample.slice(0, 160)}..."`);
    } else if (mode === 'translate') {
      setResult(`✨ **ผลการแปลและเกลาสำนวนภาษาไทย:**
สายลมหนาวพัดกรูผ่านช่องหน้าต่าง แสงจันทราสาดส่องลงบนยอดกระบี่โบราณ พลังปราณฟ้าดินเริ่มหลอมรวมเข้าสู่จุดตันเถียนอย่างเงียบงัน...`);
    } else if (mode === 'explain') {
      const terms = searchCultivationTerms(inputText);
      if (terms.length > 0) {
        setResult(`📖 **คำอธิบายศัพท์กำลังภายในที่เกี่ยวข้อง:**\n` + 
          terms.slice(0, 3).map(t => `• **${t.thai}** (${t.chinese} / ${t.pinyin}): ${t.meaning}`).join('\n\n')
        );
      } else {
        setResult(`📖 **คำอธิบายศัพท์:** จุดรวมพลังปราณสำคัญในร่างกาย ใช้สำหรับกักเก็บและโคจรพลังฟ้าดินเพื่อยกระดับสู่ความเป็นเซียน`);
      }
    } else {
      setResult(`💡 **ไอเดียพล็อตฉากต่อไป:**
ทันใดนั้นเสียงคำรามดังกึกก้องจากส่วนลึกของหุบเขา สัตว์อสูรวิญญาณระดับสามปรากฏกายขึ้น บีบให้ตัวเอกต้องตัดสินใจปลดปล่อยกระบี่เก้าบรรพตก่อนเวลาอันควร!`);
    }
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(result);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4">
      <div 
        className="w-full max-w-2xl rounded-3xl border border-neutral-800 bg-neutral-950 p-6 text-neutral-100 shadow-2xl flex flex-col max-h-[90vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-neutral-800">
          <div className="flex items-center gap-2">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-purple-500/20 text-purple-400 border border-purple-500/30">
              <Sparkles className="h-5 w-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-neutral-100">AI Novel Studio</h2>
              <p className="text-xs text-neutral-400">ผู้ช่วยอัจฉริยะวิเคราะห์ สรุป และแปลภาษานิยาย</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-neutral-400 hover:text-white hover:bg-neutral-900"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Mode Selector Tabs */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mt-4">
          {[
            { id: 'summarize', label: 'สรุปเนื้อหาบท', icon: <FileText className="h-4 w-4" /> },
            { id: 'translate', label: 'แปล & เกลาสำนวน', icon: <Languages className="h-4 w-4" /> },
            { id: 'explain', label: 'อธิบายศัพท์เซียน', icon: <BrainCircuit className="h-4 w-4" /> },
            { id: 'continue_story', label: 'คิดพล็อตฉากต่อ', icon: <Lightbulb className="h-4 w-4" /> },
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setMode(tab.id as AIToolMode)}
              className={`flex items-center justify-center gap-1.5 p-2.5 rounded-xl text-xs font-semibold border transition-all ${
                mode === tab.id
                  ? 'bg-purple-500/20 border-purple-500 text-purple-300 shadow-md shadow-purple-500/10'
                  : 'bg-neutral-900 border-neutral-800 text-neutral-400 hover:text-neutral-200'
              }`}
            >
              {tab.icon}
              <span>{tab.label}</span>
            </button>
          ))}
        </div>

        {/* Text Input */}
        <div className="mt-4 flex-1 flex flex-col min-h-0 space-y-3">
          <div className="relative">
            <textarea
              rows={4}
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              placeholder={
                mode === 'summarize' ? 'วางเนื้อหาตอนที่ต้องการให้ AI ช่วยสรุป...' :
                mode === 'translate' ? 'วางข้อความภาษาจีน หรืออังกฤษที่ต้องการแปลเป็นไทย...' :
                mode === 'explain' ? 'พิมพ์คำศัพท์ที่สงสัย เช่น แก่นทองคำ, ตันเถียน, หรือประโยคในนิยาย...' :
                'วางตอนล่าสุดเพื่อขอไอเดียหรือเหตุการณ์ต่อไป...'
              }
              className="w-full rounded-2xl border border-neutral-800 bg-neutral-900/90 p-3 text-xs leading-relaxed text-neutral-200 focus:border-purple-500 focus:outline-none resize-none"
            />
            {inputText && (
              <button
                onClick={() => setInputText('')}
                className="absolute right-3 top-3 text-[11px] text-neutral-500 hover:text-neutral-300"
              >
                ล้าง
              </button>
            )}
          </div>

          {/* Action Button */}
          <div className="flex items-center justify-between">
            <span className="text-[11px] text-neutral-500">
              ขับเคลื่อนด้วย Gemini AI โมเดลอัจฉริยะ
            </span>
            <button
              onClick={handleRunAI}
              disabled={isLoading || !inputText.trim()}
              className="flex items-center gap-2 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 px-5 py-2 text-xs font-bold text-white shadow-lg shadow-purple-500/20 disabled:opacity-40 hover:brightness-110 active:scale-95 transition-all"
            >
              {isLoading ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" />
                  กำลังประมวลผล...
                </>
              ) : (
                <>
                  <Sparkles className="h-4 w-4" />
                  เริ่มประมวลผล
                </>
              )}
            </button>
          </div>

          {errorMsg && (
            <p className="text-xs text-red-400">{errorMsg}</p>
          )}

          {/* Result Box */}
          {result && (
            <div className="flex-1 overflow-y-auto rounded-2xl border border-neutral-800 bg-neutral-900/60 p-4 relative space-y-2">
              {isFallbackMode && (
                <div className="flex items-center justify-between text-xs text-amber-300 bg-amber-500/10 border border-amber-500/30 rounded-xl px-3 py-2">
                  <span className="truncate pr-2">ℹ️ {fallbackNote || 'โมเดลมีผู้ใช้งานหนาแน่นชั่วคราว แสดงผลด้วยระบบสำรอง'}</span>
                  <button 
                    onClick={handleRunAI} 
                    className="underline text-amber-200 hover:text-white font-medium shrink-0"
                  >
                    ลองใหม่อีกครั้ง
                  </button>
                </div>
              )}

              <div className="flex items-center justify-between border-b border-neutral-800 pb-2">
                <span className="text-xs font-bold text-purple-400">ผลลัพธ์จาก AI:</span>
                <div className="flex items-center gap-2">
                  {mode === 'translate' && onApplyTranslation && (
                    <button
                      onClick={() => {
                        onApplyTranslation(result);
                        onClose();
                      }}
                      className="flex items-center gap-1 text-[11px] font-bold text-amber-400 hover:text-amber-300 bg-amber-500/15 border border-amber-500/30 px-2 py-0.5 rounded-lg"
                    >
                      <Check className="h-3 w-3" />
                      นำข้อความแปลนี้ไปใช้ในบท
                    </button>
                  )}
                  <button
                    onClick={handleCopy}
                    className="flex items-center gap-1 text-[11px] text-neutral-400 hover:text-neutral-200"
                  >
                    {copied ? <Check className="h-3.5 w-3.5 text-emerald-400" /> : <Copy className="h-3.5 w-3.5" />}
                    {copied ? 'คัดลอกแล้ว' : 'คัดลอกผลลัพธ์'}
                  </button>
                </div>
              </div>
              <div className="text-xs sm:text-sm leading-relaxed text-neutral-200 whitespace-pre-wrap">
                {result}
              </div>
            </div>
          )}
        </div>

      </div>
    </div>
  );
};
