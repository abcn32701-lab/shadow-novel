import React, { useState, useEffect } from 'react';
import { ReaderSettings, AudioSettings } from '../types';
import { Settings, X, Moon, Sun, Type, Volume2, Sparkles, BookOpen, Play, Square } from 'lucide-react';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  readerSettings: ReaderSettings;
  onUpdateReaderSettings: (s: Partial<ReaderSettings>) => void;
  audioSettings: AudioSettings;
  onUpdateAudioSettings: (s: Partial<AudioSettings>) => void;
  availableVoices: SpeechSynthesisVoice[];
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  readerSettings,
  onUpdateReaderSettings,
  audioSettings,
  onUpdateAudioSettings,
  availableVoices
}) => {
  const [isTestingVoice, setIsTestingVoice] = useState(false);

  useEffect(() => {
    if (!isOpen && isTestingVoice) {
      if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
      setIsTestingVoice(false);
    }
  }, [isOpen, isTestingVoice]);

  if (!isOpen) return null;

  const handleToggleTestVoice = () => {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) return;

    if (isTestingVoice) {
      window.speechSynthesis.cancel();
      setIsTestingVoice(false);
      return;
    }

    window.speechSynthesis.cancel();
    const testUtterance = new SpeechSynthesisUtterance('ยินดีต้อนรับสู่ระบบอ่านนิยายเสียง Novelia คุณกำลังทดสอบคุณภาพเสียงอ่าน');
    const matchedVoice = availableVoices.find(v => v.voiceURI === audioSettings.voiceURI);
    if (matchedVoice) {
      testUtterance.voice = matchedVoice;
      testUtterance.lang = matchedVoice.lang;
    } else {
      testUtterance.lang = 'th-TH';
    }

    testUtterance.rate = audioSettings.rate;
    testUtterance.pitch = audioSettings.pitch;
    testUtterance.volume = audioSettings.volume;

    testUtterance.onend = () => setIsTestingVoice(false);
    testUtterance.onerror = () => setIsTestingVoice(false);

    setIsTestingVoice(true);
    window.speechSynthesis.speak(testUtterance);
  };


  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4">
      <div 
        className="w-full max-w-xl rounded-3xl border border-neutral-800 bg-neutral-950 p-6 text-neutral-100 shadow-2xl flex flex-col max-h-[88vh]"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between pb-4 border-b border-neutral-800">
          <div className="flex items-center gap-2.5">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-neutral-800 text-neutral-300">
              <Settings className="h-5 w-5" />
            </div>
            <div>
              <h2 className="text-base font-bold font-serif">การตั้งค่าทั่วไป (Settings)</h2>
              <p className="text-xs text-neutral-400">ปรับแต่งรูปแบบการอ่านและระบบเสียงสังเคราะห์</p>
            </div>
          </div>
          <button onClick={onClose} className="p-1.5 rounded-lg text-neutral-400 hover:text-white">
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto mt-4 space-y-6 pr-1">
          
          {/* Reader Appearance */}
          <div>
            <h3 className="text-xs font-bold uppercase tracking-wider text-amber-500 mb-3 flex items-center gap-1.5">
              <Type className="h-4 w-4" />
              การแสดงผลและการอ่าน
            </h3>

            <div className="space-y-4 rounded-2xl bg-neutral-900/60 p-4 border border-neutral-800">
              <div>
                <label className="text-xs text-neutral-400 block mb-2">ชุดสีถนอมสายตา (Theme)</label>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { id: 'dark', label: 'Dark มืด' },
                    { id: 'sepia', label: 'Sepia ซีเปีย' },
                    { id: 'emerald', label: 'Emerald เขียวถนอมตา' },
                    { id: 'paper', label: 'Paper กระดาษถนอมสายตา' },
                    { id: 'midnight', label: 'OLED ดำสนิท' },
                    { id: 'light', label: 'Light สว่าง' },
                  ].map(t => (
                    <button
                      key={t.id}
                      onClick={() => onUpdateReaderSettings({ theme: t.id as any })}
                      className={`p-2 rounded-xl text-xs font-semibold border transition-all ${
                        readerSettings.theme === t.id
                          ? 'border-amber-500 bg-amber-500/20 text-amber-300 font-bold'
                          : 'border-neutral-800 bg-neutral-950 text-neutral-400 hover:text-neutral-200'
                      }`}
                    >
                      {t.label}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="text-xs text-neutral-400 block mb-2">แบบอักษร (Font Family)</label>
                <div className="grid grid-cols-2 gap-2">
                  {[
                    { id: 'sarabun', label: 'สารบรรณ (Sarabun)' },
                    { id: 'kanit', label: 'คณิต (Kanit)' },
                    { id: 'baijamjuree', label: 'จามจุรี (Bai Jamjuree)' },
                    { id: 'serif', label: 'เซริฟโบราณ (Noto Serif Thai)' },
                  ].map(f => (
                    <button
                      key={f.id}
                      onClick={() => onUpdateReaderSettings({ font: f.id as any })}
                      className={`p-2 rounded-xl text-xs border text-left transition-all ${
                        readerSettings.font === f.id
                          ? 'border-amber-500 bg-amber-500/20 text-amber-300 font-bold'
                          : 'border-neutral-800 bg-neutral-950 text-neutral-400 hover:text-neutral-200'
                      }`}
                    >
                      {f.label}
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex items-center justify-between pt-2 border-t border-neutral-800">
                <span className="text-xs text-neutral-300">ไฮไลต์และแปลศัพท์กำลังภายในอัตโนมัติ</span>
                <input
                  type="checkbox"
                  checked={readerSettings.showChineseAnnotation}
                  onChange={(e) => onUpdateReaderSettings({ showChineseAnnotation: e.target.checked })}
                  className="h-4 w-4 accent-amber-500 rounded cursor-pointer"
                />
              </div>
            </div>
          </div>

          {/* Audio & Speech Settings */}
          <div>
            <h3 className="text-xs font-bold uppercase tracking-wider text-amber-500 mb-3 flex items-center gap-1.5">
              <Volume2 className="h-4 w-4" />
              การสังเคราะห์เสียงอ่าน (Text-to-Speech)
            </h3>

            <div className="space-y-4 rounded-2xl bg-neutral-900/60 p-4 border border-neutral-800">
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-xs text-neutral-400">เสียงระบบที่เลือกใช้</label>
                  <button
                    type="button"
                    onClick={handleToggleTestVoice}
                    className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-lg text-xs font-medium transition-colors ${
                      isTestingVoice
                        ? 'bg-red-500/20 text-red-300 border border-red-500/40'
                        : 'bg-amber-500/20 text-amber-300 border border-amber-500/30 hover:bg-amber-500/30'
                    }`}
                  >
                    {isTestingVoice ? (
                      <>
                        <Square className="h-3 w-3 fill-current" />
                        <span>หยุดทดสอบ</span>
                      </>
                    ) : (
                      <>
                        <Play className="h-3 w-3 fill-current" />
                        <span>ทดสอบฟังเสียง</span>
                      </>
                    )}
                  </button>
                </div>
                <select
                  value={audioSettings.voiceURI}
                  onChange={(e) => {
                    if (isTestingVoice && typeof window !== 'undefined' && 'speechSynthesis' in window) {
                      window.speechSynthesis.cancel();
                      setIsTestingVoice(false);
                    }
                    onUpdateAudioSettings({ voiceURI: e.target.value });
                  }}
                  className="w-full rounded-xl border border-neutral-800 bg-neutral-950 p-2.5 text-xs text-neutral-200 focus:outline-none focus:border-amber-500/50"
                >
                  {availableVoices.map((v, idx) => (
                    <option key={`settings-voice-${v.voiceURI || v.name}-${v.lang}-${idx}`} value={v.voiceURI}>
                      {v.name} [{v.lang}]
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <div className="flex justify-between text-xs text-neutral-400 mb-1">
                    <span>ความเร็วเริ่มต้น</span>
                    <span className="font-bold text-amber-400">{audioSettings.rate}x</span>
                  </div>
                  <input
                    type="range"
                    min="0.75"
                    max="2.0"
                    step="0.25"
                    value={audioSettings.rate}
                    onChange={(e) => onUpdateAudioSettings({ rate: parseFloat(e.target.value) })}
                    className="w-full accent-amber-500 cursor-pointer"
                  />
                </div>

                <div>
                  <div className="flex justify-between text-xs text-neutral-400 mb-1">
                    <span>โทนเสียงสูงต่ำ (Pitch)</span>
                    <span className="font-bold text-amber-400">{audioSettings.pitch.toFixed(1)}x</span>
                  </div>
                  <input
                    type="range"
                    min="0.8"
                    max="1.2"
                    step="0.05"
                    value={audioSettings.pitch}
                    onChange={(e) => onUpdateAudioSettings({ pitch: parseFloat(e.target.value) })}
                    className="w-full accent-amber-500 cursor-pointer"
                  />
                </div>
              </div>

              <div className="flex items-center justify-between pt-2 border-t border-neutral-800">
                <span className="text-xs text-neutral-300">อ่านจบตอนแล้วเปิดตอนถัดไปอัตโนมัติ</span>
                <input
                  type="checkbox"
                  checked={audioSettings.autoNextChapter}
                  onChange={(e) => onUpdateAudioSettings({ autoNextChapter: e.target.checked })}
                  className="h-4 w-4 accent-amber-500 rounded cursor-pointer"
                />
              </div>
            </div>
          </div>

        </div>

        <div className="mt-6 pt-4 border-t border-neutral-800 flex justify-end">
          <button
            onClick={onClose}
            className="rounded-xl bg-amber-500 px-6 py-2 text-xs font-bold text-neutral-950 hover:bg-amber-400"
          >
            เรียบร้อย
          </button>
        </div>
      </div>
    </div>
  );
};
