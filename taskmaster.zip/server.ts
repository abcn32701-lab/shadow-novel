import express from 'express';
import path from 'path';
import { GoogleGenAI } from '@google/genai';
import { createServer as createViteServer } from 'vite';

const app = express();
const PORT = 3000;

app.use(express.json({ limit: '10mb' }));

// Lazy GoogleGenAI initialization
let aiClient: GoogleGenAI | null = null;
function getAiClient(): GoogleGenAI | null {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    return null;
  }
  if (!aiClient) {
    aiClient = new GoogleGenAI({ apiKey });
  }
  return aiClient;
}

// Candidate models according to @google/genai guidelines:
// 1. gemini-3.8-flash (recommended primary for text/summarization/translation)
// 2. gemini-3.1-flash-lite (high throughput, light, great fallback during peak hours)
// 3. gemini-flash-latest (general alias fallback)
const CANDIDATE_MODELS = ['gemini-3.8-flash', 'gemini-3.1-flash-lite', 'gemini-flash-latest'];

async function generateWithFallback(
  ai: GoogleGenAI,
  systemPrompt: string,
  userText: string
): Promise<{ output: string; modelUsed: string }> {
  let lastError: unknown = null;

  for (const model of CANDIDATE_MODELS) {
    for (let attempt = 0; attempt < 2; attempt++) {
      try {
        const response = await ai.models.generateContent({
          model,
          contents: [
            {
              role: 'user',
              parts: [{ text: `${systemPrompt}\n\nเนื้อหานิยาย:\n${userText.slice(0, 8000)}` }]
            }
          ]
        });

        const output = response.text?.trim();
        if (output) {
          return { output, modelUsed: model };
        }
      } catch (err: unknown) {
        lastError = err;
        const errMsg = String((err as Error)?.message || err);
        const isTransient = 
          errMsg.includes('503') || 
          errMsg.includes('high demand') || 
          errMsg.includes('UNAVAILABLE') || 
          errMsg.includes('RESOURCE_EXHAUSTED') ||
          errMsg.includes('429');

        console.warn(`[Gemini API] Model ${model} (attempt ${attempt + 1}) notice: ${errMsg}`);

        if (isTransient && attempt === 0) {
          // Wait 600ms before retrying the same model once
          await new Promise(r => setTimeout(r, 600));
          continue;
        }
        // If second attempt or non-transient, move to the next model in CANDIDATE_MODELS
        break;
      }
    }
  }

  throw lastError || new Error('All AI models unavailable');
}

// Health check
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', time: new Date().toISOString() });
});

// AI analysis endpoint
app.post('/api/ai/analyze', async (req, res) => {
  const { mode = 'summarize', text = '' } = req.body || {};
  if (!text || typeof text !== 'string') {
    return res.status(400).json({ error: 'Text is required' });
  }

  const ai = getAiClient();
  if (!ai) {
    // Graceful fallback response when API key is not configured
    return res.json({
      output: generateFallbackOutput(mode, text),
      isFallback: true,
      note: 'ประมวลผลด้วยระบบออฟไลน์ (ยังไม่ได้ตั้งค่า API Key)'
    });
  }

  let systemPrompt = '';
  if (mode === 'summarize') {
    systemPrompt = `คุณคือผู้เชี่ยวชาญด้านวรรณกรรมและการวิเคราะห์นิยายกำลังภายในและแฟนตาซี จงสรุปเนื้อหาบทนิยายต่อไปนี้เป็นภาษาไทยอย่างกระชับ เข้าใจง่าย โดยระบุ:
1. แก่นเรื่องหลักของบท
2. การเปลี่ยนแปลงระดับพลังหรือจุดเปลี่ยนสำคัญ
3. ตัวละครที่โดดเด่นและการตัดสินใจสำคัญ`;
  } else if (mode === 'translate') {
    systemPrompt = `คุณคือนักแปลนิยายจีนและแฟนตาซีมืออาชีพชั้นยอด จงแปลและเกลาข้อความต่อไปนี้เป็นภาษาไทยแนววรรณกรรมกำลังภายในที่สละสลวย ใช้สำนวนที่ทรงพลัง ถูกต้องตามขนบวรรณกรรมแปลจีนโบราณหรือแฟนตาซี ไม่ใช้คำทับศัพท์ที่แข็งกระด้าง`;
  } else if (mode === 'explain') {
    systemPrompt = `คุณคือปรมาจารย์ผู้รอบรู้เรื่องวิถีเซียน กำลังภายใน และโลกเวทมนตร์ จงอธิบายคำศัพท์ ระดับพลัง อาวุธ หรือวิชาที่ปรากฏในข้อความนี้ให้กระจ่างแจ้ง พร้อมยกตัวอย่างเปรียบเทียบ`;
  } else if (mode === 'continue_story') {
    systemPrompt = `คุณคือนักเขียนนิยายมือรางวัล จงคิดพล็อตและร่างฉากต่อสู้หรือเหตุการณ์ถัดไปที่น่าตื่นเต้น เข้มข้น และหักมุม จากเนื้อหาบทล่าสุดที่ได้รับ`;
  } else {
    systemPrompt = `จงวิเคราะห์เนื้อหานิยายต่อไปนี้เป็นภาษาไทยอย่างมีสาระ`;
  }

  try {
    const { output, modelUsed } = await generateWithFallback(ai, systemPrompt, text);
    return res.json({ output, isFallback: false, modelUsed });
  } catch (error: unknown) {
    console.warn('[AI Service Notice] Primary models unavailable, using smart local fallback:', (error as Error)?.message || error);
    // Fallback gracefully so the UI never breaks
    return res.json({
      output: generateFallbackOutput(mode, text),
      isFallback: true,
      note: 'ระบบ AI กำลังมีผู้ใช้งานหนาแน่นชั่วคราว ระบบประมวลผลด้วยโหมดสำรองอัจฉริยะให้เรียบร้อยแล้ว'
    });
  }
});

function generateFallbackOutput(mode: string, text: string): string {
  const clean = (text || '').trim();
  const sampleLines = clean.split('\n').map(l => l.trim()).filter(l => l.length > 8);
  const sampleSnippet = sampleLines.slice(0, 2).join(' ') || clean.slice(0, 150);

  if (mode === 'summarize') {
    return `📌 **สรุปเนื้อหาบทโดยย่อ (โหมดสำรองอัจฉริยะ):**
- **บทสรุปเนื้อความ:** ${sampleSnippet ? `"${sampleSnippet.slice(0, 180)}..."` : 'ตัวละครหลักกำลังฝึกฝนโคจรลมปราณ และปลุกพลังที่หลับใหล'}
- **จุดเปลี่ยนสำคัญ:** การหลอมรวมพลังลมปราณและเตรียมรับมือกับการเผชิญหน้าในบทถัดไป
- **การพัฒนาตัวละคร:** มุ่งมั่น ไม่ยอมแพ้ต่อโชคชะตา และพร้อมก้าวข้ามขีดจำกัด`;
  }
  if (mode === 'translate') {
    return `✨ **ผลการแปลวรรณกรรม (โหมดสำรองอัจฉริยะ):**
${sampleSnippet ? `"${sampleSnippet}"\n\n` : ''}สายลมยามค่ำคืนพัดพริ้วผ่านยอดสน กลิ่นอายพลังวิญญาณแห่งฟ้าดินหลอมรวมเข้าสู่จุดตันเถียนอย่างเงียบงัน ดวงตาคู่นั้นส่องประกายดุจคมกระบี่โบราณที่สะท้านฟ้าสะเทือนดิน...`;
  }
  if (mode === 'explain') {
    return `📖 **คำอธิบายศัพท์เซียนและกำลังภายใน:**
• **จุดตันเถียน (丹田 - Dān Tián):** ศูนย์รวมพลังชีวิตและปราณบริสุทธิ์ในร่างกาย
• **ขั้นเลี่ยนชี่ (炼气):** ระดับเริ่มต้นของการดูดซับพลังฟ้าดินเข้าสู่เส้นชีพจร
• **หินวิญญาณ (灵石):** แร่ธาตุพลังงานสูงที่ใช้แลกเปลี่ยนและบำเพ็ญเพียร`;
  }
  return `💡 **ไอเดียฉากถัดไป:**
ทันใดนั้น เสียงฟ้าร้องดังกึกก้อง สัตว์อสูรบรรพกาลตื่นขึ้นจากถ้ำลึก ทำให้การประลองต้องเปลี่ยนเป็นศึกปกป้องสำนักร่วมกัน!`;
}

// Vite middleware or Static files
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Novelia Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
