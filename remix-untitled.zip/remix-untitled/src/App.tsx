import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { DEFAULT_NOVELS } from './data/defaultNovels';
import { 
  Novel, 
  Chapter, 
  ReadingSettings, 
  SpeechSettings, 
  AmbientSoundType,
  UserRole,
  UserProfile
} from './types';
import { parseTextToSegments } from './utils/textParser';
import { useSpeechPlayer } from './hooks/useSpeechPlayer';
import { playAmbientSound, stopAmbientSound } from './utils/ambientAudio';
import { getCurrentUser, logoutAccount, toggleFavoriteNovel } from './utils/authService';
import { Navbar } from './components/Navbar';
import { ReaderView } from './components/ReaderView';
import { AudioPlayerBar } from './components/AudioPlayerBar';
import { ChapterSidebar } from './components/ChapterSidebar';
import { AddChapterModal } from './components/AddChapterModal';
import { CreateNovelModal } from './components/CreateNovelModal';
import { HomeNovelList } from './components/HomeNovelList';
import { LibraryModal } from './components/LibraryModal';
import { SettingsModal } from './components/SettingsModal';
import { SleepTimerModal } from './components/SleepTimerModal';
import { AIToolsModal } from './components/AIToolsModal';
import { AuthModal } from './components/AuthModal';
import { SharePortalModal } from './components/SharePortalModal';
import { UserProfileModal } from './components/UserProfileModal';

const STORAGE_KEY_NOVELS = 'novelvoice_novels_v3';
const STORAGE_KEY_ACTIVE_NOVEL = 'novelvoice_active_novel_v2';
const STORAGE_KEY_ACTIVE_CHAP = 'novelvoice_active_chap_v2';
const STORAGE_KEY_READ_SETTINGS = 'novelvoice_reading_settings_v1';
const STORAGE_KEY_SPEECH_SETTINGS = 'novelvoice_speech_settings_v1';
const STORAGE_KEY_SIDEBAR = 'novelvoice_chapter_sidebar_open';
const STORAGE_KEY_CURRENT_VIEW = 'novelvoice_current_view_v2';
const STORAGE_KEY_USER_ROLE = 'shadow_novel_user_role_v1';

export default function App() {
  // State: Novels collection (default + custom, ensuring test novel is present)
  const [novels, setNovels] = useState<Novel[]>(() => {
    const OLD_SAMPLE_IDS = ['novel-chinese-1', 'novel-1', 'novel-2', 'novel-3', 'novel-4'];
    try {
      let saved = localStorage.getItem(STORAGE_KEY_NOVELS);
      if (!saved) {
        saved = localStorage.getItem('novelvoice_novels_v2') || localStorage.getItem('novelvoice_novels_v1');
      }
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) {
          // Filter out old samples and placeholder
          const filtered = parsed.filter(n => !OLD_SAMPLE_IDS.includes(n.id) && n.id !== 'my-novel-1');
          const hasSwordNovel = filtered.some(n => n.id === 'novel-celestial-sword');
          if (!hasSwordNovel) {
            return [...DEFAULT_NOVELS, ...filtered];
          }
          if (filtered.length > 0) {
            return filtered;
          }
        }
      }
    } catch (e) {
      console.warn('Error reading saved novels', e);
    }
    return DEFAULT_NOVELS;
  });

  // Current view: 'home' (Bookshelf / Vertical Novel list) or 'reader' (Reading view)
  const [currentView, setCurrentView] = useState<'home' | 'reader'>(() => {
    const saved = localStorage.getItem(STORAGE_KEY_CURRENT_VIEW);
    return (saved === 'reader' || saved === 'home') ? saved : 'home';
  });

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_CURRENT_VIEW, currentView);
  }, [currentView]);

  // User Role: 'admin' (แอดมิน - สามารถสร้าง/แก้ไข/ลบได้) หรือ 'listener' (คนฟัง/คนดู - สะอาดตา ไม่มีปุ่มแอดมิน)
  const [userRole, setUserRole] = useState<UserRole>(() => {
    const saved = localStorage.getItem(STORAGE_KEY_USER_ROLE);
    return (saved === 'admin' || saved === 'listener') ? saved : 'admin';
  });

  // User Account & Session state
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(() => getCurrentUser());
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [authModalMode, setAuthModalMode] = useState<'login' | 'register'>('login');
  const [isShareModalOpen, setIsShareModalOpen] = useState(false);
  const [isProfileModalOpen, setIsProfileModalOpen] = useState(false);

  // Check URL parameter: if opened via ?role=listener link, automatically switch to listener mode
  useEffect(() => {
    try {
      const params = new URLSearchParams(window.location.search);
      const roleParam = params.get('role');
      if (roleParam === 'listener') {
        setUserRole('listener');
        setCurrentView('home');
      }
    } catch (e) {
      console.warn('URL params parse error', e);
    }
  }, []);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_USER_ROLE, userRole);
  }, [userRole]);

  const handleToggleUserRole = useCallback(() => {
    setUserRole(prev => (prev === 'admin' ? 'listener' : 'admin'));
  }, []);

  const handleAuthSuccess = (user: UserProfile) => {
    setCurrentUser(user);
    if (user.role) {
      setUserRole(user.role);
    }
  };

  const handleLogout = () => {
    logoutAccount();
    setCurrentUser(null);
    setUserRole('listener');
  };

  const handleToggleFavorite = (novelId: string) => {
    if (!currentUser) {
      setAuthModalMode('login');
      setIsAuthModalOpen(true);
      return;
    }
    const updated = toggleFavoriteNovel(currentUser.id, novelId);
    setCurrentUser(prev => prev ? { ...prev, favorites: updated } : null);
  };

  // State: Currently selected novel & chapter
  const [activeNovelId, setActiveNovelId] = useState<string>(() => {
    const saved = localStorage.getItem(STORAGE_KEY_ACTIVE_NOVEL);
    if (saved) return saved;
    return DEFAULT_NOVELS[0].id;
  });

  const [activeChapterId, setActiveChapterId] = useState<string>(() => {
    const saved = localStorage.getItem(STORAGE_KEY_ACTIVE_CHAP);
    if (saved) return saved;
    return DEFAULT_NOVELS[0].chapters[0].id;
  });

  // Reading appearance settings
  const [readingSettings, setReadingSettings] = useState<ReadingSettings>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_READ_SETTINGS);
      if (saved) return JSON.parse(saved);
    } catch (e) {}
    return {
      theme: 'sepia', // Warm paper by default
      fontFamily: 'sarabun',
      fontSize: 18,
      lineHeight: 1.85,
      autoScroll: true,
      autoNextChapter: true,
    };
  });

  // Speech voice settings
  const [speechSettings, setSpeechSettings] = useState<SpeechSettings>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_SPEECH_SETTINGS);
      if (saved) {
        const parsed = JSON.parse(saved);
        return {
          engine: 'edge-tts',
          edgeVoice: 'th-TH-PremwadeeNeural',
          rate: 1.0,
          pitch: 1.0,
          volume: 1.0,
          lang: 'th-TH',
          ...parsed,
        };
      }
    } catch (e) {}
    return {
      engine: 'edge-tts',
      edgeVoice: 'th-TH-PremwadeeNeural',
      voiceURI: '',
      rate: 1.0,
      pitch: 1.0,
      volume: 1.0,
      lang: 'th-TH',
    };
  });

  // Ambient sound type
  const [ambientSound, setAmbientSound] = useState<AmbientSoundType>('off');

  // Modals state
  const [isLibraryOpen, setIsLibraryOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isSleepTimerOpen, setIsSleepTimerOpen] = useState(false);
  const [isAIOpen, setIsAIOpen] = useState(false);

  // Left Chapter Sidebar state
  const [isChapterSidebarOpen, setIsChapterSidebarOpen] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_SIDEBAR);
      if (saved !== null) return JSON.parse(saved);
    } catch (e) {}
    return typeof window !== 'undefined' ? window.innerWidth >= 768 : true;
  });

  // Add/Edit Chapter Modal state
  const [isAddChapterModalOpen, setIsAddChapterModalOpen] = useState(false);
  const [editingChapter, setEditingChapter] = useState<Chapter | null>(null);
  const [addChapterMode, setAddChapterMode] = useState<'single' | 'bulk'>('single');

  // Create Novel Modal state
  const [isCreateNovelModalOpen, setIsCreateNovelModalOpen] = useState(false);

  // Active Novel and Chapter computation
  const currentNovel = useMemo(() => {
    return novels.find(n => n.id === activeNovelId) || novels[0];
  }, [novels, activeNovelId]);

  const currentChapter = useMemo(() => {
    return currentNovel.chapters.find(c => c.id === activeChapterId) || currentNovel.chapters[0];
  }, [currentNovel, activeChapterId]);

  // Current Chapter index & next/prev checks
  const currentChapterIndex = useMemo(() => {
    return currentNovel.chapters.findIndex(c => c.id === currentChapter.id);
  }, [currentNovel, currentChapter]);

  const hasPrevChapter = currentChapterIndex > 0;
  const hasNextChapter = currentChapterIndex < currentNovel.chapters.length - 1;

  // Next / Prev chapter navigation
  const handlePrevChapter = useCallback(() => {
    if (hasPrevChapter) {
      const prevChap = currentNovel.chapters[currentChapterIndex - 1];
      setActiveChapterId(prevChap.id);
    }
  }, [hasPrevChapter, currentNovel, currentChapterIndex]);

  const handleNextChapter = useCallback(() => {
    if (hasNextChapter) {
      const nextChap = currentNovel.chapters[currentChapterIndex + 1];
      setActiveChapterId(nextChap.id);
    }
  }, [hasNextChapter, currentNovel, currentChapterIndex]);

  // Handle Chapter Completion (called by speech hook)
  const handleChapterComplete = useCallback(() => {
    if (readingSettings.autoNextChapter && hasNextChapter) {
      handleNextChapter();
    }
  }, [readingSettings.autoNextChapter, hasNextChapter, handleNextChapter]);

  // Parse chapter content into sentence segments
  const { paragraphs, allSegments } = useMemo(() => {
    return parseTextToSegments(currentChapter.content);
  }, [currentChapter.content]);

  // Speech player hook
  const {
    isPlaying,
    isPaused,
    currentIndex,
    availableVoices,
    sleepTimerRemaining,
    play,
    pause,
    stop,
    jumpToSegment,
    nextSegment,
    prevSegment,
    restartChapter,
    setSleepTimer,
  } = useSpeechPlayer({
    segments: allSegments,
    speechSettings,
    onChapterComplete: handleChapterComplete,
    autoScroll: readingSettings.autoScroll,
  });

  // Current active segment
  const currentSegment = allSegments[currentIndex] || null;

  // Persist state updates to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_NOVELS, JSON.stringify(novels));
    } catch (e) {}
  }, [novels]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_ACTIVE_NOVEL, activeNovelId);
  }, [activeNovelId]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_ACTIVE_CHAP, activeChapterId);
  }, [activeChapterId]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_READ_SETTINGS, JSON.stringify(readingSettings));
    } catch (e) {}
  }, [readingSettings]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_SPEECH_SETTINGS, JSON.stringify(speechSettings));
    } catch (e) {}
  }, [speechSettings]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_SIDEBAR, JSON.stringify(isChapterSidebarOpen));
    } catch (e) {}
  }, [isChapterSidebarOpen]);

  // When chapter changes, stop previous utterance and reset to 0
  useEffect(() => {
    stop();
    jumpToSegment(0, false);
  }, [activeChapterId]);

  // Handle ambient sound changes
  useEffect(() => {
    playAmbientSound(ambientSound, 0.25);
    return () => {
      stopAmbientSound();
    };
  }, [ambientSound]);

  // Ambient sound cycling helper
  const handleCycleAmbient = () => {
    const sequence: AmbientSoundType[] = ['off', 'rain', 'campfire', 'cafe', 'waves'];
    const currentIdx = sequence.indexOf(ambientSound);
    const nextType = sequence[(currentIdx + 1) % sequence.length];
    setAmbientSound(nextType);
  };

  // Toggle theme helper
  const handleToggleTheme = () => {
    setReadingSettings(prev => {
      const isCurrentlyDark = prev.theme === 'night' || prev.theme === 'oled';
      return {
        ...prev,
        theme: isCurrentlyDark ? 'sepia' : 'night',
      };
    });
  };

  // Test voice in settings
  const handleTestVoice = async () => {
    if (speechSettings.engine === 'edge-tts') {
      try {
        const isPremwadee = speechSettings.edgeVoice !== 'th-TH-NiwatNeural';
        const sampleText = isPremwadee
          ? 'สวัสดีค่ะ คุณกำลังฟังเสียงเปรมวดี จาก Microsoft Edge TTS ระบบเสียงสมจริงระดับมนุษย์ พร้อมอ่านนิยายจีนแปลไทยให้คุณฟังแล้วค่ะ'
          : 'สวัสดีครับ คุณกำลังฟังเสียงนิวัต จาก Microsoft Edge TTS พร้อมอ่านนิยายให้คุณฟังแล้วครับ';

        const res = await fetch('/api/tts/edge-tts', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            text: sampleText,
            voice: speechSettings.edgeVoice || 'th-TH-PremwadeeNeural',
            rate: speechSettings.rate,
            pitch: speechSettings.pitch,
          }),
        });

        if (!res.ok) throw new Error('Edge TTS test error');

        const blob = await res.blob();
        const url = URL.createObjectURL(blob);
        const audio = new Audio(url);
        audio.play();
      } catch (err) {
        console.warn('Edge TTS test failed, fallback to Web Speech', err);
      }
      return;
    }

    if (typeof window === 'undefined' || !('speechSynthesis' in window)) return;
    window.speechSynthesis.cancel();

    const sampleText = 'ยินดีต้อนรับสู่แอปอ่านนิยายเสียง ขอให้เพลิดเพลินกับการฟังนิยายครับ';
    const utterance = new SpeechSynthesisUtterance(sampleText);
    utterance.rate = speechSettings.rate;
    utterance.pitch = speechSettings.pitch;
    utterance.volume = speechSettings.volume;

    const voices = window.speechSynthesis.getVoices();
    const selectedVoice = voices.find(v => v.voiceURI === speechSettings.voiceURI);
    if (selectedVoice) {
      utterance.voice = selectedVoice;
      utterance.lang = selectedVoice.lang;
    } else {
      utterance.lang = 'th-TH';
    }

    window.speechSynthesis.speak(utterance);
  };

  // Select novel from switcher or library
  const handleSelectNovel = (novelId: string) => {
    const nov = novels.find(n => n.id === novelId);
    if (nov) {
      setActiveNovelId(novelId);
      if (nov.chapters.length > 0) {
        setActiveChapterId(nov.chapters[0].id);
      }
    }
  };

  // Add custom novel
  const handleAddNovel = (newNovel: Novel) => {
    setNovels(prev => [newNovel, ...prev]);
    setActiveNovelId(newNovel.id);
    if (newNovel.chapters.length > 0) {
      setActiveChapterId(newNovel.chapters[0].id);
    }
  };

  // Update novel cover image (uploaded by user)
  const handleUpdateNovelCover = (novelId: string, coverImage: string | undefined) => {
    setNovels(prev => prev.map(nov => {
      if (nov.id === novelId) {
        return {
          ...nov,
          coverImage,
          updatedAt: Date.now(),
        };
      }
      return nov;
    }));
  };

  // Delete novel
  const handleDeleteNovel = (novelId: string) => {
    setNovels(prev => prev.filter(n => n.id !== novelId));
    if (activeNovelId === novelId) {
      const remaining = novels.filter(n => n.id !== novelId);
      if (remaining.length > 0) {
        setActiveNovelId(remaining[0].id);
        setActiveChapterId(remaining[0].chapters[0].id);
      } else {
        setActiveNovelId(DEFAULT_NOVELS[0].id);
        setActiveChapterId(DEFAULT_NOVELS[0].chapters[0].id);
      }
    }
  };

  // Chapter handlers for current novel
  const handleOpenAddChapter = (mode: 'single' | 'bulk' = 'single') => {
    setEditingChapter(null);
    setAddChapterMode(mode);
    setIsAddChapterModalOpen(true);
  };

  const handleEditChapter = (chapter: Chapter) => {
    setEditingChapter(chapter);
    setAddChapterMode('single');
    setIsAddChapterModalOpen(true);
  };

  const handleSaveChapter = (chapter: Chapter) => {
    setNovels(prev => prev.map(nov => {
      if (nov.id === activeNovelId) {
        const exists = nov.chapters.some(c => c.id === chapter.id);
        let updatedChapters: Chapter[];
        if (exists) {
          updatedChapters = nov.chapters.map(c => c.id === chapter.id ? chapter : c);
        } else {
          updatedChapters = [...nov.chapters, chapter];
        }
        return {
          ...nov,
          chapters: updatedChapters,
          updatedAt: Date.now(),
        };
      }
      return nov;
    }));
    setActiveChapterId(chapter.id);
  };

  const handleBulkSaveChapters = (newChapters: Chapter[]) => {
    if (newChapters.length === 0) return;
    setNovels(prev => prev.map(nov => {
      if (nov.id === activeNovelId) {
        return {
          ...nov,
          chapters: [...nov.chapters, ...newChapters],
          updatedAt: Date.now(),
        };
      }
      return nov;
    }));
    setActiveChapterId(newChapters[0].id);
  };

  const handleDeleteChapter = (chapterId: string) => {
    setNovels(prev => prev.map(nov => {
      if (nov.id === activeNovelId) {
        const remaining = nov.chapters.filter(c => c.id !== chapterId);
        return {
          ...nov,
          chapters: remaining.length > 0 ? remaining : nov.chapters,
          updatedAt: Date.now(),
        };
      }
      return nov;
    }));
    if (activeChapterId === chapterId) {
      const remaining = currentNovel.chapters.filter(c => c.id !== chapterId);
      if (remaining.length > 0) {
        setActiveChapterId(remaining[0].id);
      }
    }
  };

  const handleEditNovelTitle = (newTitle: string) => {
    setNovels(prev => prev.map(nov => {
      if (nov.id === activeNovelId) {
        return {
          ...nov,
          title: newTitle,
          updatedAt: Date.now(),
        };
      }
      return nov;
    }));
  };

  const handleEditNovelTitleById = (novelId: string, newTitle: string) => {
    setNovels(prev => prev.map(nov => {
      if (nov.id === novelId) {
        return {
          ...nov,
          title: newTitle,
          updatedAt: Date.now(),
        };
      }
      return nov;
    }));
  };

  const handleSelectNovelAndChapter = (novelId: string, chapterId: string, autoPlay: boolean = false) => {
    setActiveNovelId(novelId);
    const targetNovel = novels.find(n => n.id === novelId);
    const targetChapter = targetNovel?.chapters.find(c => c.id === chapterId) || targetNovel?.chapters[0];
    if (targetChapter) {
      setActiveChapterId(targetChapter.id);
    }
    setCurrentView('reader');
    if (autoPlay) {
      setTimeout(() => {
        play();
      }, 150);
    }
  };

  const handleOpenAddChapterForNovel = (novelId: string) => {
    setActiveNovelId(novelId);
    handleOpenAddChapter('single');
  };

  // Append AI generated text to current chapter
  const handleAppendContent = (extraText: string) => {
    setNovels(prev => {
      return prev.map(nov => {
        if (nov.id === activeNovelId) {
          return {
            ...nov,
            chapters: nov.chapters.map(chap => {
              if (chap.id === activeChapterId) {
                return {
                  ...chap,
                  content: chap.content + extraText,
                };
              }
              return chap;
            }),
          };
        }
        return nov;
      });
    });
  };

  // Keyboard controls (Space = play/pause, ArrowLeft/Right = prev/next)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Don't trigger if user is typing in input or textarea
      if (
        e.target instanceof HTMLInputElement ||
        e.target instanceof HTMLTextAreaElement ||
        e.target instanceof HTMLSelectElement
      ) {
        return;
      }

      if (e.code === 'Space') {
        e.preventDefault();
        if (isPlaying) {
          pause();
        } else {
          play();
        }
      } else if (e.code === 'ArrowRight') {
        e.preventDefault();
        nextSegment();
      } else if (e.code === 'ArrowLeft') {
        e.preventDefault();
        prevSegment();
      } else if (e.code === 'Escape') {
        setIsLibraryOpen(false);
        setIsSettingsOpen(false);
        setIsSleepTimerOpen(false);
        setIsAIOpen(false);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isPlaying, play, pause, nextSegment, prevSegment]);

  return (
    <div className="min-h-screen flex flex-col antialiased selection:bg-amber-300 selection:text-amber-950">
      {/* Top Navigation */}
      <Navbar
        currentView={currentView}
        onSwitchView={setCurrentView}
        userRole={userRole}
        onToggleUserRole={handleToggleUserRole}
        totalNovelsCount={novels.length}
        currentNovel={currentNovel}
        currentChapter={currentChapter}
        readingSettings={readingSettings}
        ambientSound={ambientSound}
        sleepTimerRemaining={sleepTimerRemaining}
        isChapterSidebarOpen={isChapterSidebarOpen}
        onToggleChapterSidebar={() => setIsChapterSidebarOpen(prev => !prev)}
        onOpenAddChapter={() => handleOpenAddChapter('single')}
        onOpenCreateNovel={() => setIsCreateNovelModalOpen(true)}
        onOpenLibrary={() => setIsLibraryOpen(true)}
        onOpenSettings={() => setIsSettingsOpen(true)}
        onOpenAI={() => setIsAIOpen(true)}
        onOpenSleepTimer={() => setIsSleepTimerOpen(true)}
        onCycleAmbient={handleCycleAmbient}
        onToggleTheme={handleToggleTheme}
        currentUser={currentUser}
        onOpenAuthModal={() => {
          setAuthModalMode('login');
          setIsAuthModalOpen(true);
        }}
        onOpenProfileModal={() => setIsProfileModalOpen(true)}
        onOpenShareModal={() => setIsShareModalOpen(true)}
      />

      {/* 1. HOME VIEW (Vertical stack of novels from top to bottom) */}
      {currentView === 'home' && (
        <HomeNovelList
          novels={novels}
          activeNovelId={activeNovelId}
          activeChapterId={activeChapterId}
          readingSettings={readingSettings}
          isPlaying={isPlaying}
          userRole={userRole}
          onToggleUserRole={handleToggleUserRole}
          onSelectNovelAndChapter={handleSelectNovelAndChapter}
          onOpenCreateNovelModal={() => setIsCreateNovelModalOpen(true)}
          onOpenAddChapterModal={handleOpenAddChapterForNovel}
          onUpdateNovelCover={handleUpdateNovelCover}
          onEditNovelTitle={handleEditNovelTitleById}
          onDeleteNovel={handleDeleteNovel}
          currentUser={currentUser}
          onOpenAuthModal={() => {
            setAuthModalMode('login');
            setIsAuthModalOpen(true);
          }}
          onOpenShareModal={() => setIsShareModalOpen(true)}
          onToggleFavorite={handleToggleFavorite}
        />
      )}

      {/* 2. READER VIEW & DOCKED LEFT CHAPTER SIDEBAR */}
      {currentView === 'reader' && (
        <>
          {/* Docked Left Chapter Sidebar */}
          <ChapterSidebar
            isOpen={isChapterSidebarOpen}
            onToggle={() => setIsChapterSidebarOpen(prev => !prev)}
            novels={novels}
            currentNovel={currentNovel}
            currentChapterId={activeChapterId}
            readingSettings={readingSettings}
            isPlaying={isPlaying}
            userRole={userRole}
            onSelectNovel={handleSelectNovel}
            onSelectChapter={(cId) => setActiveChapterId(cId)}
            onOpenAddChapterModal={() => handleOpenAddChapter('single')}
            onOpenBulkImportModal={() => handleOpenAddChapter('bulk')}
            onOpenCreateNovelModal={() => setIsCreateNovelModalOpen(true)}
            onUpdateNovelCover={handleUpdateNovelCover}
            onEditNovelTitle={handleEditNovelTitle}
            onDeleteNovel={handleDeleteNovel}
            onDeleteChapter={handleDeleteChapter}
            onEditChapter={handleEditChapter}
          />

          {/* Main Reading View */}
          <ReaderView
            currentNovel={currentNovel}
            currentChapter={currentChapter}
            paragraphs={paragraphs}
            currentSegmentIndex={currentIndex}
            isPlaying={isPlaying}
            readingSettings={readingSettings}
            isChapterSidebarOpen={isChapterSidebarOpen}
            onSelectSegment={(index) => jumpToSegment(index, true)}
            onPrevChapter={handlePrevChapter}
            onNextChapter={handleNextChapter}
            onOpenAddChapter={() => handleOpenAddChapter('single')}
            hasPrevChapter={hasPrevChapter}
            hasNextChapter={hasNextChapter}
            onOpenAI={() => setIsAIOpen(true)}
          />
        </>
      )}

      {/* Floating Bottom Audio Player */}
      <AudioPlayerBar
        isPlaying={isPlaying}
        isPaused={isPaused}
        currentIndex={currentIndex}
        totalSegments={allSegments.length}
        currentSegment={currentSegment}
        speechSettings={speechSettings}
        readingSettings={readingSettings}
        sleepTimerRemaining={sleepTimerRemaining}
        onPlay={play}
        onPause={pause}
        onPrevSegment={prevSegment}
        onNextSegment={nextSegment}
        onRestartChapter={restartChapter}
        onChangeRate={(rate) => setSpeechSettings(prev => ({ ...prev, rate }))}
        onOpenSettings={() => setIsSettingsOpen(true)}
        onOpenSleepTimer={() => setIsSleepTimerOpen(true)}
        onToggleAutoScroll={() => setReadingSettings(prev => ({ ...prev, autoScroll: !prev.autoScroll }))}
      />

      {/* Modals */}
      <AddChapterModal
        isOpen={isAddChapterModalOpen}
        onClose={() => {
          setIsAddChapterModalOpen(false);
          setEditingChapter(null);
        }}
        novelTitle={currentNovel.title}
        nextChapterNumber={currentNovel.chapters.length + 1}
        initialChapter={editingChapter}
        onSaveChapter={handleSaveChapter}
        onBulkSaveChapters={handleBulkSaveChapters}
        mode={addChapterMode}
      />

      {/* Create Novel with Custom Cover Modal */}
      <CreateNovelModal
        isOpen={isCreateNovelModalOpen}
        onClose={() => setIsCreateNovelModalOpen(false)}
        onCreateNovel={handleAddNovel}
      />

      <LibraryModal
        isOpen={isLibraryOpen}
        onClose={() => setIsLibraryOpen(false)}
        novels={novels}
        currentNovelId={activeNovelId}
        currentChapterId={activeChapterId}
        onSelectChapter={(nId, cId) => {
          setActiveNovelId(nId);
          setActiveChapterId(cId);
        }}
        onAddNovel={handleAddNovel}
        onDeleteNovel={handleDeleteNovel}
      />

      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        speechSettings={speechSettings}
        readingSettings={readingSettings}
        availableVoices={availableVoices}
        onUpdateSpeechSettings={(newSettings) => setSpeechSettings(prev => ({ ...prev, ...newSettings }))}
        onUpdateReadingSettings={(newSettings) => setReadingSettings(prev => ({ ...prev, ...newSettings }))}
        onTestVoice={handleTestVoice}
      />

      <SleepTimerModal
        isOpen={isSleepTimerOpen}
        onClose={() => setIsSleepTimerOpen(false)}
        sleepTimerRemaining={sleepTimerRemaining}
        onSetTimer={setSleepTimer}
      />

      <AIToolsModal
        isOpen={isAIOpen}
        onClose={() => setIsAIOpen(false)}
        currentNovel={currentNovel}
        currentChapter={currentChapter}
        onAppendContent={handleAppendContent}
      />

      {/* Authentication Modal (Login & Registration) */}
      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        onSuccess={handleAuthSuccess}
        initialMode={authModalMode}
      />

      {/* Shareable Listener View Modal */}
      <SharePortalModal
        isOpen={isShareModalOpen}
        onClose={() => setIsShareModalOpen(false)}
      />

      {/* User Profile & Favorites Modal */}
      <UserProfileModal
        isOpen={isProfileModalOpen}
        onClose={() => setIsProfileModalOpen(false)}
        currentUser={currentUser}
        novels={novels}
        onLogout={handleLogout}
        onToggleUserRole={handleToggleUserRole}
        onSelectNovel={(nId) => {
          setActiveNovelId(nId);
          const nov = novels.find(n => n.id === nId);
          if (nov && nov.chapters[0]) {
            setActiveChapterId(nov.chapters[0].id);
          }
        }}
      />
    </div>
  );
}
