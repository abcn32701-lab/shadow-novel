import React, { useState, useRef } from 'react';
import { 
  Plus, 
  Trash2, 
  Edit3, 
  ChevronLeft, 
  ChevronRight, 
  Search, 
  Bookmark, 
  Volume2, 
  FileText,
  Copy,
  Layers,
  Sparkles,
  Check,
  Upload,
  Image as ImageIcon,
  ChevronsUpDown,
  BookOpen,
  Camera,
  FolderOpen
} from 'lucide-react';
import { Novel, Chapter, ReadingSettings, UserRole } from '../types';
import { compressCoverImage } from '../utils/imageHelper';

interface ChapterSidebarProps {
  isOpen: boolean;
  onToggle: () => void;
  novels: Novel[];
  currentNovel: Novel;
  currentChapterId: string;
  readingSettings: ReadingSettings;
  isPlaying: boolean;
  userRole?: UserRole;
  onSelectNovel: (novelId: string) => void;
  onSelectChapter: (chapterId: string) => void;
  onOpenAddChapterModal: () => void;
  onOpenBulkImportModal: () => void;
  onOpenCreateNovelModal: () => void;
  onUpdateNovelCover: (novelId: string, coverImage: string | undefined) => void;
  onEditNovelTitle: (newTitle: string) => void;
  onDeleteNovel: (novelId: string) => void;
  onDeleteChapter: (chapterId: string) => void;
  onEditChapter: (chapter: Chapter) => void;
}

export const ChapterSidebar: React.FC<ChapterSidebarProps> = ({
  isOpen,
  onToggle,
  novels,
  currentNovel,
  currentChapterId,
  readingSettings,
  isPlaying,
  userRole = 'admin',
  onSelectNovel,
  onSelectChapter,
  onOpenAddChapterModal,
  onOpenBulkImportModal,
  onOpenCreateNovelModal,
  onUpdateNovelCover,
  onEditNovelTitle,
  onDeleteNovel,
  onDeleteChapter,
  onEditChapter,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [isEditingNovelTitle, setIsEditingNovelTitle] = useState(false);
  const [tempNovelTitle, setTempNovelTitle] = useState(currentNovel.title);
  const [isNovelSelectorOpen, setIsNovelSelectorOpen] = useState(false);
  const [isUploadingCover, setIsUploadingCover] = useState(false);

  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const isDark = readingSettings.theme === 'night' || readingSettings.theme === 'oled';
  const isSepia = readingSettings.theme === 'sepia';

  const filteredChapters = currentNovel.chapters.filter((ch) =>
    ch.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    `ตอนที่ ${ch.number}`.includes(searchQuery) ||
    `บทที่ ${ch.number}`.includes(searchQuery)
  );

  const handleSaveTitle = () => {
    if (tempNovelTitle.trim()) {
      onEditNovelTitle(tempNovelTitle.trim());
    }
    setIsEditingNovelTitle(false);
  };

  const handleCoverUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      setIsUploadingCover(true);
      const dataUrl = await compressCoverImage(file, 500, 0.82);
      onUpdateNovelCover(currentNovel.id, dataUrl);
    } catch (err: any) {
      alert(err?.message || 'ไม่สามารถโหลดรูปภาพได้');
    } finally {
      setIsUploadingCover(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  const handleRemoveCover = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (confirm('คุณต้องการนำรูปปกนี้ออกหรือไม่?')) {
      onUpdateNovelCover(currentNovel.id, undefined);
    }
  };

  // Color schemes for sidebar based on reading theme
  const sidebarBg = readingSettings.theme === 'oled'
    ? 'bg-neutral-950 border-neutral-900 text-neutral-100'
    : readingSettings.theme === 'night'
    ? 'bg-neutral-900 border-neutral-800 text-neutral-200'
    : readingSettings.theme === 'sepia'
    ? 'bg-[#f4ecd8] border-[#dfcfb0] text-[#4a3b32]'
    : 'bg-white border-amber-200/80 text-stone-800';

  const cardActiveBg = readingSettings.theme === 'sepia'
    ? 'bg-[#e8dcbf] border-amber-600/60 shadow-sm text-amber-950'
    : isDark
    ? 'bg-amber-500/20 border-amber-500/60 text-amber-200 shadow-sm'
    : 'bg-amber-50 border-amber-500 shadow-sm text-amber-900';

  const cardInactiveBg = readingSettings.theme === 'sepia'
    ? 'bg-[#ede2c8]/60 hover:bg-[#e4d6b6] border-stone-300/40 text-stone-800'
    : isDark
    ? 'bg-neutral-800/60 hover:bg-neutral-800 border-neutral-700/60 text-neutral-300'
    : 'bg-stone-50/80 hover:bg-stone-100 border-stone-200 text-stone-700';

  return (
    <>
      {/* Floating Left Edge Tab (When sidebar is collapsed) */}
      {!isOpen && (
        <button
          id="btn-expand-chapter-sidebar"
          onClick={onToggle}
          title="เปิดแถบรายการตอนและนิยายด้านซ้าย"
          className="fixed top-20 left-0 z-40 flex items-center gap-1.5 py-2.5 px-3 rounded-r-xl bg-amber-500 hover:bg-amber-600 text-white shadow-lg transition-all active:scale-95 group font-medium text-xs border border-l-0 border-amber-600"
        >
          {currentNovel.coverImage ? (
            <img
              src={currentNovel.coverImage}
              alt=""
              className="w-4 h-5 object-cover rounded-xs"
            />
          ) : (
            <Layers className="w-4 h-4" />
          )}
          <span className="font-semibold tracking-wide">
            {currentNovel.chapters.length} ตอน
          </span>
          <ChevronRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 transition-transform" />
        </button>
      )}

      {/* Docked Left Sidebar */}
      <aside
        id="chapter-left-sidebar"
        className={`fixed top-14 bottom-20 sm:bottom-24 left-0 z-30 w-80 sm:w-84 border-r transition-transform duration-200 ease-in-out flex flex-col shadow-xl ${sidebarBg} ${
          isOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        {/* Hidden File Input for Cover Upload */}
        <input
          ref={fileInputRef}
          type="file"
          accept="image/*"
          onChange={handleCoverUpload}
          className="hidden"
        />

        {/* 1. TOP BAR: Novel Switcher Header & Collapse */}
        <div className="p-3 border-b border-inherit shrink-0 bg-black/5 dark:bg-white/5">
          <div className="flex items-center justify-between gap-2">
            {/* Novel Switcher Trigger Button */}
            <button
              id="btn-toggle-novel-switcher"
              onClick={() => setIsNovelSelectorOpen(!isNovelSelectorOpen)}
              className="flex-1 flex items-center gap-2 p-1.5 rounded-xl hover:bg-black/10 dark:hover:bg-white/10 transition-colors text-left min-w-0 group"
              title="กดเพื่อสลับดูนิยายเรื่องอื่น หรือสร้างเรื่องใหม่"
            >
              <div className="w-7 h-9 rounded-md bg-amber-500/20 text-amber-600 dark:text-amber-400 flex items-center justify-center font-bold text-xs shrink-0 overflow-hidden border border-amber-500/30">
                {currentNovel.coverImage ? (
                  <img
                    src={currentNovel.coverImage}
                    alt=""
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <BookOpen className="w-4 h-4" />
                )}
              </div>
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-1 text-[10px] uppercase font-bold text-amber-600 dark:text-amber-400">
                  <span>นิยายที่กำลังอ่าน</span>
                  <span className="text-[9px] px-1 py-0.2 rounded-xs bg-amber-500/15">
                    {novels.length} เรื่อง
                  </span>
                </div>
                <div className="text-xs sm:text-sm font-bold truncate leading-tight flex items-center gap-1">
                  <span className="truncate">{currentNovel.title}</span>
                  <ChevronsUpDown className="w-3.5 h-3.5 opacity-60 shrink-0 group-hover:opacity-100" />
                </div>
              </div>
            </button>

            {/* Collapse Sidebar Button */}
            <button
              id="btn-collapse-chapter-sidebar"
              onClick={onToggle}
              title="ซ่อนแถบข้าง"
              className="p-1.5 rounded-lg hover:bg-black/10 dark:hover:bg-white/10 transition-colors shrink-0"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
          </div>

          {/* 2. NOVEL SWITCHER DROPDOWN (When opened) */}
          {isNovelSelectorOpen && (
            <div className="mt-2.5 p-2 rounded-xl bg-white dark:bg-neutral-850 border border-stone-200 dark:border-neutral-750 shadow-lg animate-fade-in">
              <div className="flex items-center justify-between px-1 mb-1.5">
                <span className="text-[11px] font-bold opacity-75">
                  เลือกนิยายเรื่องที่ต้องการอ่าน:
                </span>
                {userRole === 'admin' && (
                  <button
                    onClick={() => {
                      setIsNovelSelectorOpen(false);
                      onOpenCreateNovelModal();
                    }}
                    className="text-[11px] font-bold text-amber-600 dark:text-amber-400 hover:underline flex items-center gap-1"
                  >
                    <Plus className="w-3 h-3" />
                    <span>สร้างเรื่องใหม่</span>
                  </button>
                )}
              </div>

              <div className="max-h-48 overflow-y-auto space-y-1.5 custom-scrollbar pr-0.5">
                {novels.map((novel) => {
                  const isCurrent = novel.id === currentNovel.id;
                  return (
                    <div
                      key={novel.id}
                      onClick={() => {
                        onSelectNovel(novel.id);
                        setIsNovelSelectorOpen(false);
                      }}
                      className={`p-2 rounded-lg flex items-center justify-between gap-2.5 cursor-pointer transition-all ${
                        isCurrent
                          ? 'bg-amber-500 text-white font-semibold shadow-xs'
                          : 'hover:bg-stone-100 dark:hover:bg-neutral-800 text-stone-800 dark:text-neutral-200'
                      }`}
                    >
                      <div className="flex items-center gap-2 min-w-0">
                        {novel.coverImage ? (
                          <img
                            src={novel.coverImage}
                            alt=""
                            className="w-8 h-10 object-cover rounded-sm shrink-0 border border-black/10"
                          />
                        ) : (
                          <div className={`w-8 h-10 rounded-sm flex items-center justify-center font-bold text-xs shrink-0 ${
                            isCurrent ? 'bg-white/20 text-white' : 'bg-stone-200 dark:bg-neutral-700 text-stone-700 dark:text-neutral-300'
                          }`}>
                            {novel.title.slice(0, 1)}
                          </div>
                        )}
                        <div className="truncate">
                          <div className="text-xs truncate font-bold">
                            {novel.title}
                          </div>
                          <div className={`text-[10px] truncate ${isCurrent ? 'text-white/80' : 'opacity-60'}`}>
                            {novel.chapters.length} บท • {novel.author}
                          </div>
                        </div>
                      </div>

                      {isCurrent ? (
                        <Check className="w-4 h-4 text-white shrink-0" />
                      ) : userRole === 'admin' && novels.length > 1 ? (
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            if (confirm(`คุณต้องการลบนิยาย "${novel.title}" หรือไม่?`)) {
                              onDeleteNovel(novel.id);
                            }
                          }}
                          title="ลบนิยายนี้"
                          className="opacity-40 hover:opacity-100 hover:text-red-500 p-1 rounded-sm"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      ) : null}
                    </div>
                  );
                })}
              </div>

              {userRole === 'admin' && (
                <button
                  onClick={() => {
                    setIsNovelSelectorOpen(false);
                    onOpenCreateNovelModal();
                  }}
                  className="w-full mt-2 py-1.5 rounded-lg border border-dashed border-amber-500/50 hover:bg-amber-500/10 text-amber-600 dark:text-amber-400 text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>+ เพิ่ม / สร้างนิยายเรื่องใหม่</span>
                </button>
              )}
            </div>
          )}
        </div>

        {/* 3. CURRENT NOVEL COVER & DETAILS CARD */}
        <div className="p-3 border-b border-inherit shrink-0">
          <div className="flex gap-3 items-start">
            {/* Novel Cover */}
            <div className="relative group shrink-0">
              <div
                onClick={() => {
                  if (userRole === 'admin') {
                    fileInputRef.current?.click();
                  }
                }}
                className={`w-18 h-24 sm:w-20 sm:h-27 rounded-lg overflow-hidden border border-stone-300 dark:border-neutral-700 bg-stone-100 dark:bg-neutral-800 shadow-sm flex flex-col items-center justify-center text-center relative ${
                  userRole === 'admin' ? 'cursor-pointer hover:ring-2 hover:ring-amber-500 transition-all' : ''
                }`}
                title={userRole === 'admin' ? 'คลิกเพื่ออัปโหลดหรือเปลี่ยนรูปปกนิยายจากเครื่องของคุณ' : currentNovel.title}
              >
                {currentNovel.coverImage ? (
                  <img
                    src={currentNovel.coverImage}
                    alt={currentNovel.title}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="p-1 text-center">
                    <BookOpen className="w-5 h-5 mx-auto opacity-50 mb-1 text-amber-500" />
                    <span className="text-[9px] opacity-70 block font-medium leading-tight">
                      {currentNovel.title.slice(0, 10)}
                    </span>
                  </div>
                )}

                {/* Hover overlay on cover (Admin only) */}
                {userRole === 'admin' && (
                  <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center text-white p-1 text-center">
                    <Camera className="w-4 h-4 mb-0.5" />
                    <span className="text-[9px] font-bold leading-tight">
                      {currentNovel.coverImage ? 'เปลี่ยนรูป' : 'ใส่รูปปก'}
                    </span>
                  </div>
                )}

                {isUploadingCover && (
                  <div className="absolute inset-0 bg-black/75 flex items-center justify-center text-white text-[9px]">
                    กำลังย่อ...
                  </div>
                )}
              </div>

              {/* Remove cover button if image exists (Admin only) */}
              {userRole === 'admin' && currentNovel.coverImage && (
                <button
                  type="button"
                  onClick={handleRemoveCover}
                  title="เอารูปปกออก"
                  className="absolute -top-1.5 -right-1.5 p-1 rounded-full bg-red-500 text-white shadow-xs hover:bg-red-600 transition-colors"
                >
                  <Trash2 className="w-2.5 h-2.5" />
                </button>
              )}
            </div>

            {/* Novel Info & Inline Edit Title */}
            <div className="flex-1 min-w-0">
              {userRole === 'admin' && isEditingNovelTitle ? (
                <div className="flex items-center gap-1.5 mb-1.5">
                  <input
                    type="text"
                    value={tempNovelTitle}
                    onChange={(e) => setTempNovelTitle(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && handleSaveTitle()}
                    autoFocus
                    className="flex-1 px-2 py-0.5 text-xs font-bold rounded-md border border-amber-500 bg-white dark:bg-neutral-800 outline-none"
                  />
                  <button
                    onClick={handleSaveTitle}
                    className="p-1 rounded-md bg-amber-500 text-white hover:bg-amber-600 shrink-0"
                    title="บันทึกชื่อเรื่อง"
                  >
                    <Check className="w-3.5 h-3.5" />
                  </button>
                </div>
              ) : (
                <div className="flex items-start justify-between group mb-1">
                  <h3
                    className="font-bold text-sm truncate leading-snug"
                    title={currentNovel.title}
                  >
                    {currentNovel.title}
                  </h3>
                  {userRole === 'admin' && (
                    <button
                      onClick={() => {
                        setTempNovelTitle(currentNovel.title);
                        setIsEditingNovelTitle(true);
                      }}
                      className="opacity-0 group-hover:opacity-100 p-0.5 rounded-sm hover:bg-black/10 dark:hover:bg-white/10 text-stone-500 transition-opacity shrink-0 ml-1"
                      title="เปลี่ยนชื่อเรื่องนิยาย"
                    >
                      <Edit3 className="w-3 h-3" />
                    </button>
                  )}
                </div>
              )}

              <p className="text-[11px] opacity-60 truncate">
                โดย {currentNovel.author}
              </p>

              <div className="flex items-center gap-1.5 mt-1">
                <span className="text-[10px] px-1.5 py-0.5 rounded-md bg-stone-200/80 dark:bg-neutral-750 font-medium">
                  {currentNovel.category || 'นิยายจีนแปลไทย'}
                </span>
                <span className="text-[10px] px-1.5 py-0.5 rounded-md bg-amber-500/15 text-amber-700 dark:text-amber-300 font-bold">
                  {currentNovel.chapters.length} บท
                </span>
              </div>

              {/* Cover upload prompt button (Admin only) */}
              {userRole === 'admin' && (
                <button
                  onClick={() => fileInputRef.current?.click()}
                  className="mt-2 text-[10px] text-amber-600 dark:text-amber-400 hover:underline flex items-center gap-1 font-medium"
                >
                  <Upload className="w-3 h-3" />
                  <span>{currentNovel.coverImage ? 'เปลี่ยนรูปปก' : 'อัปโหลดรูปปก'}</span>
                </button>
              )}
            </div>
          </div>

          {/* Quick Action Buttons for chapters (Admin only) */}
          {userRole === 'admin' && (
            <div className="grid grid-cols-2 gap-2 mt-3">
              <button
                id="btn-sidebar-add-chapter"
                onClick={onOpenAddChapterModal}
                className="py-2 px-2.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-white font-semibold text-xs flex items-center justify-center gap-1.5 shadow-xs active:scale-95 transition-all"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>+ เพิ่มตอนใหม่</span>
              </button>

              <button
                id="btn-sidebar-bulk-import"
                onClick={onOpenBulkImportModal}
                className="py-2 px-2 rounded-xl border border-amber-500/40 hover:bg-amber-500/10 text-amber-700 dark:text-amber-300 font-medium text-xs flex items-center justify-center gap-1 transition-colors"
              >
                <span>🏮 นำเข้าหลายบท</span>
              </button>
            </div>
          )}
        </div>

        {/* 4. CHAPTER SEARCH */}
        <div className="px-3 pt-2.5 pb-1 shrink-0">
          <div className="relative">
            <Search className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 opacity-50" />
            <input
              type="text"
              placeholder="ค้นหาตอนหรือบท..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-8 pr-2.5 py-1.5 text-xs rounded-lg border border-inherit bg-black/5 dark:bg-white/5 outline-none focus:ring-1 focus:ring-amber-500"
            />
          </div>
        </div>

        {/* 5. CHAPTERS LIST */}
        <div className="flex-1 overflow-y-auto px-3 py-2 space-y-1.5 custom-scrollbar">
          {filteredChapters.length === 0 ? (
            <div className="text-center py-8 text-xs opacity-60">
              {searchQuery ? 'ไม่พบตอนที่ค้นหา' : 'ยังไม่มีตอน กดปุ่ม "+ เพิ่มตอนใหม่" ด้านบน'}
            </div>
          ) : (
            filteredChapters.map((chapter) => {
              const isCurrent = chapter.id === currentChapterId;

              return (
                <div
                  key={chapter.id}
                  id={`sidebar-chapter-${chapter.id}`}
                  onClick={() => onSelectChapter(chapter.id)}
                  className={`group relative p-2.5 rounded-xl border transition-all cursor-pointer flex items-center justify-between gap-2 ${
                    isCurrent ? cardActiveBg : cardInactiveBg
                  }`}
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    {/* Chapter Number Badge / Speaker */}
                    <div className={`w-7 h-7 rounded-lg flex items-center justify-center text-xs font-bold shrink-0 transition-transform ${
                      isCurrent
                        ? 'bg-amber-500 text-white shadow-xs scale-105'
                        : 'bg-black/10 dark:bg-white/10'
                    }`}>
                      {isCurrent && isPlaying ? (
                        <Volume2 className="w-3.5 h-3.5 animate-pulse text-white" />
                      ) : (
                        <span>{chapter.number}</span>
                      )}
                    </div>

                    {/* Chapter Title & Word Count */}
                    <div className="min-w-0 truncate">
                      <p className="text-xs font-semibold truncate leading-tight">
                        {chapter.title}
                      </p>
                      <p className="text-[10px] opacity-60 truncate mt-0.5">
                        {chapter.content.length} ตัวอักษร
                      </p>
                    </div>
                  </div>

                  {/* Actions (Edit / Delete) - Admin Only */}
                  {userRole === 'admin' && (
                    <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity shrink-0">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onEditChapter(chapter);
                        }}
                        title="แก้ไขเนื้อหาตอนนี้"
                        className="p-1 rounded-md hover:bg-black/10 dark:hover:bg-white/10 text-stone-500 hover:text-amber-600 transition-colors"
                      >
                        <Edit3 className="w-3.5 h-3.5" />
                      </button>

                      {currentNovel.chapters.length > 1 && (
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            if (confirm(`คุณต้องการลบ "${chapter.title}" หรือไม่?`)) {
                              onDeleteChapter(chapter.id);
                            }
                          }}
                          title="ลบตอนนี้"
                          className="p-1 rounded-md hover:bg-black/10 dark:hover:bg-white/10 text-stone-500 hover:text-red-600 transition-colors"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  )}
                </div>
              );
            })
          )}
        </div>

        {/* 6. SIDEBAR FOOTER */}
        <div className="p-2.5 border-t border-inherit shrink-0 flex items-center justify-between text-[11px] opacity-70">
          <span>รวม {currentNovel.chapters.length} บท</span>
          <button
            onClick={onOpenBulkImportModal}
            className="text-amber-600 dark:text-amber-400 font-semibold hover:underline"
          >
            + วางหลายบท
          </button>
        </div>
      </aside>
    </>
  );
};
