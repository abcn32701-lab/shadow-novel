import React, { useState, useEffect } from 'react';
import { 
  X, 
  Plus, 
  Upload, 
  FileText, 
  CheckCircle2, 
  Sparkles,
  Layers
} from 'lucide-react';
import { Chapter } from '../types';
import { 
  cleanChineseNovelText, 
  splitNovelIntoChapters 
} from '../utils/chineseNovelHelper';

interface AddChapterModalProps {
  isOpen: boolean;
  onClose: () => void;
  novelTitle: string;
  nextChapterNumber: number;
  initialChapter?: Chapter | null; // For editing
  onSaveChapter: (chapter: Chapter) => void;
  onBulkSaveChapters: (chapters: Chapter[]) => void;
  mode?: 'single' | 'bulk';
}

export const AddChapterModal: React.FC<AddChapterModalProps> = ({
  isOpen,
  onClose,
  novelTitle,
  nextChapterNumber,
  initialChapter,
  onSaveChapter,
  onBulkSaveChapters,
  mode = 'single',
}) => {
  const [tab, setTab] = useState<'single' | 'bulk'>(mode);
  
  // Single chapter state
  const [chapterNumber, setChapterNumber] = useState(nextChapterNumber);
  const [chapterTitle, setChapterTitle] = useState(`ตอนที่ ${nextChapterNumber}`);
  const [content, setContent] = useState('');
  const [autoClean, setAutoClean] = useState(true);

  // Bulk chapters state
  const [bulkText, setBulkText] = useState('');
  const [bulkAutoClean, setBulkAutoClean] = useState(true);
  const [detectedChapters, setDetectedChapters] = useState<Chapter[]>([]);

  useEffect(() => {
    if (initialChapter) {
      setChapterNumber(initialChapter.number);
      setChapterTitle(initialChapter.title);
      setContent(initialChapter.content);
      setTab('single');
    } else {
      setChapterNumber(nextChapterNumber);
      setChapterTitle(`ตอนที่ ${nextChapterNumber}`);
      setContent('');
      setBulkText('');
      setDetectedChapters([]);
      setTab(mode);
    }
  }, [initialChapter, nextChapterNumber, mode, isOpen]);

  if (!isOpen) return null;

  // Handle single txt upload
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const text = event.target?.result as string;
      if (text) {
        setContent(text);
        if (!chapterTitle || chapterTitle === `ตอนที่ ${nextChapterNumber}`) {
          setChapterTitle(file.name.replace(/\.[^/.]+$/, ''));
        }
      }
    };
    reader.readAsText(file);
  };

  // Handle bulk txt upload
  const handleBulkFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const text = event.target?.result as string;
      if (text) {
        setBulkText(text);
        handleAnalyzeBulk(text);
      }
    };
    reader.readAsText(file);
  };

  const handleAnalyzeBulk = (raw: string) => {
    setBulkText(raw);
    if (!raw.trim()) {
      setDetectedChapters([]);
      return;
    }
    const processed = bulkAutoClean ? cleanChineseNovelText(raw) : raw;
    const split = splitNovelIntoChapters(processed, `cn-${Date.now()}`);
    // renumber starting from nextChapterNumber
    const renumbered = split.map((ch, idx) => ({
      ...ch,
      number: nextChapterNumber + idx,
      id: `chap-${Date.now()}-${idx}`,
    }));
    setDetectedChapters(renumbered);
  };

  const handleSaveSingle = (e: React.FormEvent) => {
    e.preventDefault();
    if (!content.trim()) return;

    const finalContent = autoClean ? cleanChineseNovelText(content) : content;
    const chapterObj: Chapter = {
      id: initialChapter ? initialChapter.id : `chap-${Date.now()}`,
      number: chapterNumber,
      title: chapterTitle.trim() || `ตอนที่ ${chapterNumber}`,
      content: finalContent.trim(),
    };

    onSaveChapter(chapterObj);
    onClose();
  };

  const handleSaveBulk = (e: React.FormEvent) => {
    e.preventDefault();
    if (detectedChapters.length === 0 && !bulkText.trim()) return;

    if (detectedChapters.length > 0) {
      onBulkSaveChapters(detectedChapters);
    } else {
      // Single fallback
      const processed = bulkAutoClean ? cleanChineseNovelText(bulkText) : bulkText;
      onSaveChapter({
        id: `chap-${Date.now()}`,
        number: nextChapterNumber,
        title: `ตอนที่ ${nextChapterNumber}`,
        content: processed.trim(),
      });
    }
    onClose();
  };

  return (
    <div
      id="modal-add-chapter-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-sm animate-fade-in"
    >
      <div
        id="modal-add-chapter-panel"
        className="bg-white dark:bg-neutral-900 text-stone-900 dark:text-neutral-100 w-full max-w-2xl max-h-[90vh] rounded-2xl shadow-2xl border border-stone-200 dark:border-neutral-800 flex flex-col overflow-hidden"
      >
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-3.5 border-b border-stone-200 dark:border-neutral-800 bg-stone-50/50 dark:bg-neutral-900/50">
          <div className="flex items-center gap-2">
            <span className="text-xl">🏮</span>
            <div>
              <h2 className="text-base font-bold">
                {initialChapter ? 'แก้ไขเนื้อหาตอน' : 'เพิ่มตอนใหม่ในเรื่อง'}
              </h2>
              <p className="text-[11px] opacity-60 truncate max-w-[320px] sm:max-w-md">
                {novelTitle}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg hover:bg-stone-200 dark:hover:bg-neutral-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Selection if not editing */}
        {!initialChapter && (
          <div className="flex border-b border-stone-200 dark:border-neutral-800 px-5 bg-stone-100/40 dark:bg-neutral-900/30">
            <button
              type="button"
              onClick={() => setTab('single')}
              className={`py-2.5 px-4 text-xs font-semibold border-b-2 flex items-center gap-1.5 transition-colors ${
                tab === 'single'
                  ? 'border-amber-500 text-amber-600 dark:text-amber-400'
                  : 'border-transparent opacity-60 hover:opacity-100'
              }`}
            >
              <FileText className="w-3.5 h-3.5" />
              <span>เพิ่มทีละตอน</span>
            </button>

            <button
              type="button"
              onClick={() => setTab('bulk')}
              className={`py-2.5 px-4 text-xs font-semibold border-b-2 flex items-center gap-1.5 transition-colors ${
                tab === 'bulk'
                  ? 'border-red-500 text-red-600 dark:text-red-400'
                  : 'border-transparent opacity-60 hover:opacity-100'
              }`}
            >
              <Layers className="w-3.5 h-3.5" />
              <span>วางหลายตอนพร้อมกัน (แบ่งตอนอัตโนมัติ)</span>
            </button>
          </div>
        )}

        {/* Mode 1: Single Chapter Form */}
        {tab === 'single' ? (
          <form onSubmit={handleSaveSingle} className="flex-1 overflow-y-auto p-5 space-y-3.5 custom-scrollbar">
            <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
              <div className="sm:col-span-1">
                <label className="block text-xs font-semibold mb-1">ตอนที่ (ลำดับ)</label>
                <input
                  type="number"
                  min={1}
                  value={chapterNumber}
                  onChange={(e) => setChapterNumber(parseInt(e.target.value) || 1)}
                  className="w-full px-3 py-2 text-sm rounded-xl bg-stone-100 dark:bg-neutral-800 border border-stone-200 dark:border-neutral-700 outline-none focus:ring-2 focus:ring-amber-500 font-bold"
                />
              </div>

              <div className="sm:col-span-3">
                <label className="block text-xs font-semibold mb-1">
                  ชื่อตอน <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={chapterTitle}
                  onChange={(e) => setChapterTitle(e.target.value)}
                  placeholder="เช่น ตอนที่ 2: ทะลวงชีพจรลมปราณ"
                  className="w-full px-3 py-2 text-sm rounded-xl bg-stone-100 dark:bg-neutral-800 border border-stone-200 dark:border-neutral-700 outline-none focus:ring-2 focus:ring-amber-500"
                />
              </div>
            </div>

            <div className="flex items-center justify-between">
              <label className="text-xs font-semibold">
                เนื้อหาของตอนนี้ <span className="text-red-500">*</span>
              </label>

              <label className="cursor-pointer inline-flex items-center gap-1 text-xs text-amber-600 dark:text-amber-400 font-medium hover:underline">
                <Upload className="w-3.5 h-3.5" />
                <span>นำเข้าไฟล์ .txt</span>
                <input
                  type="file"
                  accept=".txt"
                  className="hidden"
                  onChange={handleFileUpload}
                />
              </label>
            </div>

            <textarea
              rows={9}
              required
              value={content}
              onChange={(e) => setContent(e.target.value)}
              placeholder="วางเนื้อหานิยายจีนแปลไทยของตอนนี้ที่นี่... สามารถวางข้อความยาวๆ ได้เลย ระบบจะตัดแบ่งประโยคและอ่านออกเสียงด้วย Edge TTS Premwadee ทันที"
              className="w-full p-3 text-sm rounded-xl bg-stone-100 dark:bg-neutral-800 border border-stone-200 dark:border-neutral-700 outline-none focus:ring-2 focus:ring-amber-500 font-sarabun leading-relaxed"
            />

            <div className="flex items-center justify-between text-xs">
              <label className="flex items-center gap-2 cursor-pointer opacity-85">
                <input
                  type="checkbox"
                  checked={autoClean}
                  onChange={(e) => setAutoClean(e.target.checked)}
                  className="rounded text-amber-500 focus:ring-amber-400"
                />
                <span>ปรับแต่งวรรคตอนและเครื่องหมายคำพูดภาษาจีนให้อัตโนมัติ</span>
              </label>

              <span className="opacity-60">
                {content.length.toLocaleString()} ตัวอักษร
              </span>
            </div>

            <div className="flex justify-end gap-2.5 pt-2">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 text-xs sm:text-sm rounded-xl border border-stone-300 dark:border-neutral-700 hover:bg-stone-100 dark:hover:bg-neutral-800"
              >
                ยกเลิก
              </button>
              <button
                type="submit"
                className="px-5 py-2 text-xs sm:text-sm font-semibold rounded-xl bg-amber-500 hover:bg-amber-600 text-white shadow-sm active:scale-95 transition-all"
              >
                {initialChapter ? 'บันทึกการแก้ไข' : 'บันทึกตอนและเริ่มอ่าน'}
              </button>
            </div>
          </form>
        ) : (
          /* Mode 2: Bulk Import Multiple Chapters */
          <form onSubmit={handleSaveBulk} className="flex-1 overflow-y-auto p-5 space-y-3.5 custom-scrollbar">
            <div className="p-3 rounded-xl bg-red-50 dark:bg-red-950/30 border border-red-200 dark:border-red-900/50 text-xs text-red-900 dark:text-red-300">
              <p className="font-bold flex items-center gap-1.5">
                <span>🏮 นำเข้าหลายตอนในคราวเดียว:</span>
              </p>
              <p className="opacity-80 mt-0.5">
                วางนิยายจีนแปลไทยที่คัดลอกมาทีละ 5-50 ตอนได้เลย ระบบจะตรวจจับหัวข้อ "ตอนที่...", "บทที่...", หรือ "第...章" และแยกตอนให้โดยอัตโนมัติ
              </p>
            </div>

            <div className="flex items-center justify-between">
              <label className="text-xs font-semibold">
                วางเนื้อหานิยายรวมหลายตอน
              </label>

              <label className="cursor-pointer inline-flex items-center gap-1 text-xs text-red-600 dark:text-red-400 font-medium hover:underline">
                <Upload className="w-3.5 h-3.5" />
                <span>นำเข้าไฟล์ .txt รวมตอน</span>
                <input
                  type="file"
                  accept=".txt"
                  className="hidden"
                  onChange={handleBulkFileUpload}
                />
              </label>
            </div>

            <textarea
              rows={8}
              required
              value={bulkText}
              onChange={(e) => handleAnalyzeBulk(e.target.value)}
              placeholder="วางเนื้อหานิยายจีนแปลไทยรวมหลายตอนที่นี่..."
              className="w-full p-3 text-sm rounded-xl bg-stone-100 dark:bg-neutral-800 border border-stone-200 dark:border-neutral-700 outline-none focus:ring-2 focus:ring-red-500 font-sarabun leading-relaxed"
            />

            {detectedChapters.length > 0 && (
              <div className="p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-800 text-xs">
                <div className="flex items-center gap-1.5 font-bold text-emerald-800 dark:text-emerald-300">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  <span>ระบบตรวจจับและแยกได้: {detectedChapters.length} ตอน</span>
                </div>
                <div className="flex flex-wrap gap-1 mt-2">
                  {detectedChapters.slice(0, 6).map((c) => (
                    <span key={c.id} className="px-2 py-0.5 rounded bg-emerald-100 dark:bg-emerald-900/60 text-emerald-900 dark:text-emerald-200 text-[11px]">
                      {c.title}
                    </span>
                  ))}
                  {detectedChapters.length > 6 && (
                    <span className="text-emerald-600 text-[11px] self-center">
                      + อีก {detectedChapters.length - 6} ตอน
                    </span>
                  )}
                </div>
              </div>
            )}

            <div className="flex justify-end gap-2.5 pt-2">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 text-xs sm:text-sm rounded-xl border border-stone-300 dark:border-neutral-700 hover:bg-stone-100 dark:hover:bg-neutral-800"
              >
                ยกเลิก
              </button>
              <button
                type="submit"
                className="px-5 py-2 text-xs sm:text-sm font-semibold rounded-xl bg-red-600 hover:bg-red-700 text-white shadow-sm active:scale-95 transition-all"
              >
                บันทึกทั้ง {Math.max(1, detectedChapters.length)} ตอนเข้าเรื่องนี้
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
