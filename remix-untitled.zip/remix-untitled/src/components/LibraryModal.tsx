import React, { useState } from 'react';
import { 
  X, 
  BookOpen, 
  Plus, 
  Upload, 
  Trash2, 
  ChevronRight, 
  Search, 
  Bookmark,
  Sparkles,
  Scissors,
  CheckCircle2,
  HelpCircle
} from 'lucide-react';
import { Novel, Chapter } from '../types';
import { 
  splitNovelIntoChapters, 
  cleanChineseNovelText, 
  CHINESE_NOVEL_GLOSSARY 
} from '../utils/chineseNovelHelper';

interface LibraryModalProps {
  isOpen: boolean;
  onClose: () => void;
  novels: Novel[];
  currentNovelId: string;
  currentChapterId: string;
  onSelectChapter: (novelId: string, chapterId: string) => void;
  onAddNovel: (novel: Novel) => void;
  onDeleteNovel: (novelId: string) => void;
}

export const LibraryModal: React.FC<LibraryModalProps> = ({
  isOpen,
  onClose,
  novels,
  currentNovelId,
  currentChapterId,
  onSelectChapter,
  onAddNovel,
  onDeleteNovel,
}) => {
  const [activeTab, setActiveTab] = useState<'browse' | 'chinese' | 'add'>('browse');
  const [selectedNovelId, setSelectedNovelId] = useState<string>(currentNovelId);
  const [searchQuery, setSearchQuery] = useState('');

  // Form states for Chinese translated novel importer
  const [chineseTitle, setChineseTitle] = useState('');
  const [chineseAuthor, setChineseAuthor] = useState('');
  const [chineseRawText, setChineseRawText] = useState('');
  const [autoCleanQuotes, setAutoCleanQuotes] = useState(true);
  const [parsedChapters, setParsedChapters] = useState<Chapter[]>([]);
  const [showGlossary, setShowGlossary] = useState(false);

  // Form states for standard novel
  const [newTitle, setNewTitle] = useState('');
  const [newAuthor, setNewAuthor] = useState('');
  const [newCategory, setNewCategory] = useState('นิยายของฉัน');
  const [newChapterTitle, setNewChapterTitle] = useState('ตอนที่ 1: จุดเริ่มต้น');
  const [newContent, setNewContent] = useState('');

  if (!isOpen) return null;

  const filteredNovels = novels.filter(n => 
    n.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    n.author.toLowerCase().includes(searchQuery.toLowerCase()) ||
    n.category.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const selectedNovel = novels.find(n => n.id === selectedNovelId) || novels[0];

  // Handle txt file upload for standard novel
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      if (content) {
        setNewContent(content);
        if (!newTitle) {
          setNewTitle(file.name.replace(/\.[^/.]+$/, ''));
        }
      }
    };
    reader.readAsText(file);
  };

  // Handle txt file upload for Chinese novel
  const handleChineseFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      if (content) {
        setChineseRawText(content);
        if (!chineseTitle) {
          setChineseTitle(file.name.replace(/\.[^/.]+$/, ''));
        }
        // Auto parse
        const chaps = splitNovelIntoChapters(content, `cn-${Date.now()}`);
        setParsedChapters(chaps);
      }
    };
    reader.readAsText(file);
  };

  // Trigger chapter split analysis
  const handleAnalyzeChineseText = (text: string) => {
    setChineseRawText(text);
    if (!text.trim()) {
      setParsedChapters([]);
      return;
    }
    const processed = autoCleanQuotes ? cleanChineseNovelText(text) : text;
    const chaps = splitNovelIntoChapters(processed, `cn-${Date.now()}`);
    setParsedChapters(chaps);
  };

  // Submit Chinese novel import
  const handleImportChineseNovel = (e: React.FormEvent) => {
    e.preventDefault();
    if (!chineseTitle.trim() || !chineseRawText.trim()) return;

    const processedText = autoCleanQuotes ? cleanChineseNovelText(chineseRawText) : chineseRawText;
    const finalChapters = splitNovelIntoChapters(processedText, `cn-${Date.now()}`);

    const newNovel: Novel = {
      id: `novel-cn-${Date.now()}`,
      title: chineseTitle.trim(),
      author: chineseAuthor.trim() || 'นิยายแปลจีน',
      category: 'นิยายจีนแปลไทย',
      coverColor: 'from-red-950 to-stone-900',
      description: `นิยายจีนแปลไทย จำนวน ${finalChapters.length} ตอน พร้อมระบบอ่านออกเสียงด้วย Edge TTS Premwadee`,
      chapters: finalChapters.length > 0 ? finalChapters : [
        {
          id: `chap-${Date.now()}-1`,
          number: 1,
          title: 'ตอนที่ 1',
          content: processedText,
        },
      ],
      isCustom: true,
      createdAt: Date.now(),
      updatedAt: Date.now(),
    };

    onAddNovel(newNovel);
    onSelectChapter(newNovel.id, newNovel.chapters[0].id);
    onClose();
  };

  // Submit standard novel
  const handleCreateNovel = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim() || !newContent.trim()) return;

    const novelId = `novel-${Date.now()}`;
    const newNovel: Novel = {
      id: novelId,
      title: newTitle.trim(),
      author: newAuthor.trim() || 'ไม่ระบุผู้แต่ง',
      category: newCategory,
      coverColor: 'from-amber-700 to-stone-900',
      description: `นิยายส่วนตัว เพิ่มเมื่อ ${new Date().toLocaleDateString('th-TH')}`,
      chapters: [
        {
          id: `chap-${Date.now()}-1`,
          number: 1,
          title: newChapterTitle.trim() || 'ตอนที่ 1',
          content: newContent.trim(),
        },
      ],
      isCustom: true,
      createdAt: Date.now(),
      updatedAt: Date.now(),
    };

    onAddNovel(newNovel);
    onSelectChapter(newNovel.id, newNovel.chapters[0].id);
    onClose();
  };

  return (
    <div 
      id="modal-library-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-sm animate-fade-in"
    >
      <div 
        id="modal-library-panel"
        className="bg-white dark:bg-neutral-900 text-stone-900 dark:text-neutral-100 w-full max-w-4xl h-[88vh] rounded-2xl shadow-2xl border border-stone-200 dark:border-neutral-800 flex flex-col overflow-hidden"
      >
        {/* Modal Header */}
        <div className="flex items-center justify-between px-6 py-3.5 border-b border-stone-200 dark:border-neutral-800 bg-stone-50/50 dark:bg-neutral-900/50">
          <div className="flex items-center gap-2">
            <BookOpen className="w-5 h-5 text-amber-500" />
            <h2 className="text-lg font-bold">คลังนิยาย & นำเข้าเรื่องใหม่</h2>
          </div>
          <button
            id="btn-close-library-modal"
            onClick={onClose}
            className="p-1.5 rounded-lg hover:bg-stone-200 dark:hover:bg-neutral-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex border-b border-stone-200 dark:border-neutral-800 px-6 bg-stone-100/40 dark:bg-neutral-900/30 overflow-x-auto">
          <button
            id="tab-library-browse"
            onClick={() => setActiveTab('browse')}
            className={`py-3 px-4 text-xs sm:text-sm font-semibold border-b-2 flex items-center gap-2 whitespace-nowrap transition-colors ${
              activeTab === 'browse'
                ? 'border-amber-500 text-amber-600 dark:text-amber-400'
                : 'border-transparent text-stone-600 dark:text-neutral-400 hover:text-stone-900 dark:hover:text-neutral-100'
            }`}
          >
            <BookOpen className="w-4 h-4" />
            <span>คลังนิยายทั้งหมด ({novels.length})</span>
          </button>

          <button
            id="tab-library-chinese"
            onClick={() => setActiveTab('chinese')}
            className={`py-3 px-4 text-xs sm:text-sm font-semibold border-b-2 flex items-center gap-2 whitespace-nowrap transition-colors ${
              activeTab === 'chinese'
                ? 'border-red-500 text-red-600 dark:text-red-400 bg-red-50/40 dark:bg-red-950/20'
                : 'border-transparent text-stone-600 dark:text-neutral-400 hover:text-stone-900 dark:hover:text-neutral-100'
            }`}
          >
            <span>🏮</span>
            <span>นำเข้านิยายจีนแปลไทย</span>
            <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-red-500/15 text-red-600 dark:text-red-300 font-bold">
              แบ่งบทอัตโนมัติ
            </span>
          </button>

          <button
            id="tab-library-add"
            onClick={() => setActiveTab('add')}
            className={`py-3 px-4 text-xs sm:text-sm font-semibold border-b-2 flex items-center gap-2 whitespace-nowrap transition-colors ${
              activeTab === 'add'
                ? 'border-amber-500 text-amber-600 dark:text-amber-400'
                : 'border-transparent text-stone-600 dark:text-neutral-400 hover:text-stone-900 dark:hover:text-neutral-100'
            }`}
          >
            <Plus className="w-4 h-4" />
            <span>เพิ่มนิยายทั่วไป (.txt)</span>
          </button>
        </div>

        {/* Tab 1: Browse Existing Novels */}
        {activeTab === 'browse' && (
          <div className="flex-1 grid grid-cols-1 md:grid-cols-12 overflow-hidden">
            {/* Left Column: Novels List (5 cols) */}
            <div className="md:col-span-5 border-r border-stone-200 dark:border-neutral-800 flex flex-col h-full overflow-hidden p-4">
              <div className="relative mb-3">
                <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-stone-400" />
                <input
                  id="input-search-library"
                  type="text"
                  placeholder="ค้นหาชื่อเรื่อง, ผู้แต่ง, หมวดหมู่..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-9 pr-3 py-1.5 text-xs rounded-xl bg-stone-100 dark:bg-neutral-800 border border-stone-200 dark:border-neutral-700 outline-none focus:ring-1 focus:ring-amber-500"
                />
              </div>

              <div className="flex-1 overflow-y-auto space-y-2 pr-1 custom-scrollbar">
                {filteredNovels.map((novel) => {
                  const isSelected = novel.id === selectedNovelId;
                  const isCurrentReading = novel.id === currentNovelId;

                  return (
                    <div
                      key={novel.id}
                      id={`novel-card-${novel.id}`}
                      onClick={() => setSelectedNovelId(novel.id)}
                      className={`p-3 rounded-xl border text-left cursor-pointer transition-all ${
                        isSelected
                          ? 'border-amber-500 bg-amber-500/10 dark:bg-amber-500/15 ring-1 ring-amber-500/50'
                          : 'border-stone-200 dark:border-neutral-800 hover:border-amber-400/60 hover:bg-stone-50 dark:hover:bg-neutral-800/60'
                      }`}
                    >
                      <div className="flex gap-2.5 items-center">
                        {novel.coverImage ? (
                          <img
                            src={novel.coverImage}
                            alt=""
                            className="w-10 h-14 object-cover rounded-md shrink-0 border border-stone-200 dark:border-neutral-700 shadow-2xs"
                          />
                        ) : (
                          <div className="w-10 h-14 rounded-md bg-linear-to-br from-amber-600 to-stone-800 text-white flex items-center justify-center font-bold text-xs shrink-0 shadow-2xs">
                            {novel.title.slice(0, 1)}
                          </div>
                        )}

                        <div className="min-w-0 flex-1">
                          <div className="flex items-center justify-between mb-0.5">
                            <span className="text-[10px] font-medium px-2 py-0.5 rounded-full bg-stone-200 dark:bg-neutral-700 truncate max-w-[120px]">
                              {novel.category}
                            </span>
                            {isCurrentReading && (
                              <span className="text-[9px] font-semibold px-1.5 py-0.5 rounded-full bg-amber-500 text-white flex items-center gap-1 shrink-0">
                                <Bookmark className="w-2.5 h-2.5" />
                                กำลังอ่าน
                              </span>
                            )}
                          </div>

                          <h3 className="font-semibold text-sm line-clamp-1 mb-0.5">
                            {novel.title}
                          </h3>
                          <p className="text-xs opacity-60 mb-1 truncate">โดย {novel.author}</p>

                          <div className="flex items-center justify-between text-[11px] opacity-75">
                            <span>{novel.chapters.length} ตอน</span>
                            {(novel.isCustom || novels.length > 1) && (
                              <button
                                id={`btn-delete-novel-${novel.id}`}
                                onClick={(e) => {
                                  e.stopPropagation();
                                  if (confirm(`คุณต้องการลบนิยาย "${novel.title}" หรือไม่?`)) {
                                    onDeleteNovel(novel.id);
                                  }
                                }}
                                className="text-red-500 hover:text-red-700 p-1 rounded-sm"
                                title="ลบนิยายนี้"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Right Column: Chapters List for Selected Novel (7 cols) */}
            <div className="md:col-span-7 flex flex-col h-full overflow-hidden p-4 sm:p-6 bg-stone-50/30 dark:bg-neutral-900/40">
              {selectedNovel ? (
                <>
                  <div className="mb-4 pb-4 border-b border-stone-200 dark:border-neutral-800 flex gap-3.5 items-start">
                    {selectedNovel.coverImage ? (
                      <img
                        src={selectedNovel.coverImage}
                        alt=""
                        className="w-16 h-22 object-cover rounded-lg shadow-sm shrink-0 border border-stone-200 dark:border-neutral-700"
                      />
                    ) : (
                      <div className="w-16 h-22 rounded-lg bg-linear-to-br from-amber-600 to-stone-800 text-white flex items-center justify-center font-bold text-lg shrink-0 shadow-sm">
                        {selectedNovel.title.slice(0, 1)}
                      </div>
                    )}
                    <div className="min-w-0 flex-1">
                      <span className="text-xs text-amber-600 dark:text-amber-400 font-semibold uppercase tracking-wider">
                        {selectedNovel.category}
                      </span>
                      <h3 className="text-xl font-bold mt-0.5 leading-snug">{selectedNovel.title}</h3>
                      <p className="text-xs opacity-65 mt-1 leading-relaxed line-clamp-2">
                        โดย {selectedNovel.author} • ทั้งหมด {selectedNovel.chapters.length} ตอน
                      </p>
                    </div>
                  </div>

                  <h4 className="text-xs font-semibold opacity-60 uppercase tracking-wider mb-2">
                    เลือกตอนเพื่อเริ่มอ่านและฟังเสียง:
                  </h4>

                  <div className="flex-1 overflow-y-auto space-y-2 pr-1 custom-scrollbar">
                    {selectedNovel.chapters.map((chap) => {
                      const isCurrentChap = 
                        selectedNovel.id === currentNovelId && chap.id === currentChapterId;

                      return (
                        <div
                          key={chap.id}
                          onClick={() => {
                            onSelectChapter(selectedNovel.id, chap.id);
                            onClose();
                          }}
                          className={`p-3.5 rounded-xl border flex items-center justify-between cursor-pointer transition-all ${
                            isCurrentChap
                              ? 'bg-amber-500 text-white border-amber-600 shadow-md scale-[1.01]'
                              : 'bg-white dark:bg-neutral-800 border-stone-200 dark:border-neutral-750 hover:border-amber-400 dark:hover:border-amber-500/50 hover:bg-stone-50 dark:hover:bg-neutral-750'
                          }`}
                        >
                          <div className="flex items-center gap-3 min-w-0">
                            <span className={`w-7 h-7 rounded-lg flex items-center justify-center text-xs font-bold shrink-0 ${
                              isCurrentChap 
                                ? 'bg-white/20 text-white' 
                                : 'bg-stone-100 dark:bg-neutral-700 text-stone-700 dark:text-neutral-300'
                            }`}>
                              {chap.number}
                            </span>
                            <div className="truncate">
                              <p className="text-sm font-semibold truncate">{chap.title}</p>
                              <p className={`text-xs truncate ${isCurrentChap ? 'text-white/80' : 'opacity-50'}`}>
                                {chap.content.slice(0, 50)}...
                              </p>
                            </div>
                          </div>

                          <ChevronRight className={`w-4 h-4 shrink-0 ${isCurrentChap ? 'text-white' : 'opacity-40'}`} />
                        </div>
                      );
                    })}
                  </div>
                </>
              ) : (
                <div className="flex items-center justify-center h-full text-sm opacity-50">
                  กรุณาเลือกนิยายจากรายการด้านซ้าย
                </div>
              )}
            </div>
          </div>
        )}

        {/* Tab 2: Chinese Translated Novel Importer */}
        {activeTab === 'chinese' && (
          <form 
            onSubmit={handleImportChineseNovel}
            className="flex-1 overflow-y-auto p-5 sm:p-6 space-y-4 custom-scrollbar"
          >
            {/* Banner */}
            <div className="p-3.5 rounded-xl bg-red-50 dark:bg-red-950/30 border border-red-200 dark:border-red-900/50 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
              <div className="flex items-center gap-2.5">
                <span className="text-2xl">🏮</span>
                <div>
                  <h4 className="text-xs font-bold text-red-900 dark:text-red-300">
                    ระบบนำเข้านิยายจีนแปลไทย พร้อมตัดแบ่งบทอัตโนมัติ
                  </h4>
                  <p className="text-[11px] text-red-700/80 dark:text-red-400/80 mt-0.5">
                    วางข้อความนิยายที่แปลมาได้ไม่จำกัดความยาว ระบบจะตรวจจับ "ตอนที่ / บทที่ / 第...章" เพื่อแบ่งตอนให้ทันที
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setShowGlossary(!showGlossary)}
                className="text-xs px-2.5 py-1.5 rounded-lg border border-red-300 dark:border-red-800 bg-white dark:bg-neutral-900 text-red-700 dark:text-red-300 hover:bg-red-100/50 flex items-center gap-1.5 shrink-0"
              >
                <HelpCircle className="w-3.5 h-3.5" />
                <span>{showGlossary ? 'ซ่อนคำศัพท์จีน' : '📚 คลังคำศัพท์จีนเฉพาะ'}</span>
              </button>
            </div>

            {/* Glossary Drawer */}
            {showGlossary && (
              <div className="p-3.5 rounded-xl bg-stone-50 dark:bg-neutral-800 border border-stone-200 dark:border-neutral-700 text-xs space-y-2 animate-fade-in">
                <div className="font-semibold text-amber-600 dark:text-amber-400 flex items-center gap-1.5">
                  <span>พจนานุกรมคำเฉพาะนิยายจีนกำลังภายใน / ฝึกตน (Phonetic & Meaning):</span>
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {CHINESE_NOVEL_GLOSSARY.map((item, idx) => (
                    <div key={idx} className="p-2 rounded-lg bg-white dark:bg-neutral-900 border border-stone-200 dark:border-neutral-700">
                      <div className="font-bold text-stone-900 dark:text-neutral-100 flex items-center justify-between">
                        <span>{item.term}</span>
                        <span className="text-[10px] text-stone-400">({item.reading})</span>
                      </div>
                      <p className="text-[10px] text-stone-500 dark:text-neutral-400 mt-0.5 line-clamp-1">{item.meaning}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Title & Author Inputs */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold mb-1">
                  ชื่อเรื่องนิยายจีนแปลไทย <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={chineseTitle}
                  onChange={(e) => setChineseTitle(e.target.value)}
                  placeholder="เช่น มหาเทพยุทธ์สะท้านพิภพ หรือ บันทึกเส้นทางสู่เซียน"
                  className="w-full px-3 py-2 text-sm rounded-xl bg-stone-100 dark:bg-neutral-800 border border-stone-200 dark:border-neutral-700 focus:ring-2 focus:ring-red-500 outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold mb-1">
                  ชื่อผู้แต่ง / ผู้แปล
                </label>
                <input
                  type="text"
                  value={chineseAuthor}
                  onChange={(e) => setChineseAuthor(e.target.value)}
                  placeholder="เช่น เอ่อร์เกิน / แปลโดย นิยายแปลไทย"
                  className="w-full px-3 py-2 text-sm rounded-xl bg-stone-100 dark:bg-neutral-800 border border-stone-200 dark:border-neutral-700 focus:ring-2 focus:ring-red-500 outline-none"
                />
              </div>
            </div>

            {/* Options */}
            <div className="flex flex-wrap items-center justify-between gap-3 p-3 rounded-xl bg-stone-50 dark:bg-neutral-800/60 border border-stone-200 dark:border-neutral-750 text-xs">
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={autoCleanQuotes}
                  onChange={(e) => {
                    setAutoCleanQuotes(e.target.checked);
                    if (chineseRawText) handleAnalyzeChineseText(chineseRawText);
                  }}
                  className="rounded text-red-600 focus:ring-red-500"
                />
                <span className="font-medium">
                  ล้างวรรคตอนแบบจีนอัตโนมัติ (แปลง 「 」, 『 』, 《 》, …… เป็นอัญประกาศและจังหวะหยุดพูดที่เหมาะสม)
                </span>
              </label>

              <label className="cursor-pointer inline-flex items-center gap-1.5 text-xs text-red-600 dark:text-red-400 font-medium hover:underline">
                <Upload className="w-3.5 h-3.5" />
                <span>นำเข้าไฟล์ .txt นิยายจีน</span>
                <input
                  type="file"
                  accept=".txt"
                  className="hidden"
                  onChange={handleChineseFileUpload}
                />
              </label>
            </div>

            {/* Raw Textarea */}
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="text-xs font-semibold">
                  วางเนื้อหานิยายจีนแปลไทย <span className="text-red-500">*</span>
                </label>
                <span className="text-[11px] text-stone-500 dark:text-neutral-400">
                  {chineseRawText.length.toLocaleString()} ตัวอักษร
                </span>
              </div>
              <textarea
                rows={8}
                required
                value={chineseRawText}
                onChange={(e) => handleAnalyzeChineseText(e.target.value)}
                placeholder="วางเนื้อหานิยายจีนที่แปลไทยที่นี่... สามารถวางทีเดียวหลายๆ ตอนได้ ระบบจะตรวจจับ 'ตอนที่ 1', 'ตอนที่ 2', 'บทที่...' หรือ '第...章' และตัดแบ่งบทให้โดยอัตโนมัติ"
                className="w-full p-3 text-sm rounded-xl bg-stone-100 dark:bg-neutral-800 border border-stone-200 dark:border-neutral-700 focus:ring-2 focus:ring-red-500 outline-none font-sarabun leading-relaxed"
              />
            </div>

            {/* Detected Chapters Status */}
            {parsedChapters.length > 0 && (
              <div className="p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-800 text-xs">
                <div className="flex items-center gap-2 font-bold text-emerald-800 dark:text-emerald-300">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  <span>ตรวจพบและแบ่งตอนอัตโนมัติสำเร็จ: {parsedChapters.length} ตอน</span>
                </div>
                <div className="flex flex-wrap gap-1.5 mt-2">
                  {parsedChapters.slice(0, 8).map((ch) => (
                    <span key={ch.id} className="px-2 py-0.5 rounded-md bg-emerald-100 dark:bg-emerald-900/60 text-emerald-900 dark:text-emerald-200 text-[11px]">
                      {ch.title}
                    </span>
                  ))}
                  {parsedChapters.length > 8 && (
                    <span className="text-emerald-600 text-[11px] self-center">
                      + อีก {parsedChapters.length - 8} ตอน
                    </span>
                  )}
                </div>
              </div>
            )}

            {/* Footer Buttons */}
            <div className="flex justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => setActiveTab('browse')}
                className="px-4 py-2 text-sm rounded-xl border border-stone-300 dark:border-neutral-700 hover:bg-stone-100 dark:hover:bg-neutral-800"
              >
                ยกเลิก
              </button>
              <button
                type="submit"
                className="px-6 py-2 text-sm font-semibold rounded-xl bg-red-600 hover:bg-red-700 text-white shadow-sm active:scale-95 transition-all flex items-center gap-2"
              >
                <span>🏮 บันทึกนิยายจีนและเริ่มฟัง</span>
              </button>
            </div>
          </form>
        )}

        {/* Tab 3: Add Standard Novel */}
        {activeTab === 'add' && (
          <form 
            onSubmit={handleCreateNovel}
            className="flex-1 overflow-y-auto p-6 space-y-4 custom-scrollbar"
          >
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold mb-1">
                  ชื่อเรื่องนิยาย <span className="text-red-500">*</span>
                </label>
                <input
                  id="input-new-novel-title"
                  type="text"
                  required
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  placeholder="เช่น มหาศึกทวยเทพ หรือ ความรักในรอยทราย"
                  className="w-full px-3 py-2 text-sm rounded-xl bg-stone-100 dark:bg-neutral-800 border border-stone-200 dark:border-neutral-700 focus:ring-2 focus:ring-amber-500 outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold mb-1">
                  ชื่อผู้แต่ง / นามปากกา
                </label>
                <input
                  id="input-new-novel-author"
                  type="text"
                  value={newAuthor}
                  onChange={(e) => setNewAuthor(e.target.value)}
                  placeholder="เช่น กวีสายลม หรือชื่อของคุณ"
                  className="w-full px-3 py-2 text-sm rounded-xl bg-stone-100 dark:bg-neutral-800 border border-stone-200 dark:border-neutral-700 focus:ring-2 focus:ring-amber-500 outline-none"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold mb-1">หมวดหมู่</label>
                <select
                  id="select-new-novel-category"
                  value={newCategory}
                  onChange={(e) => setNewCategory(e.target.value)}
                  className="w-full px-3 py-2 text-sm rounded-xl bg-stone-100 dark:bg-neutral-800 border border-stone-200 dark:border-neutral-700 focus:ring-2 focus:ring-amber-500 outline-none"
                >
                  <option value="นิยายของฉัน">นิยายของฉัน (My Stories)</option>
                  <option value="นิยายจีนแปลไทย">นิยายจีนแปลไทย</option>
                  <option value="แฟนตาซี / กำลังภายใน">แฟนตาซี / กำลังภายใน</option>
                  <option value="รักโรแมนติก">รักโรแมนติก</option>
                  <option value="ลึกลับ / สืบสวน">ลึกลับ / สืบสวน</option>
                  <option value="บทความ / สาระน่ารู้">บทความ / สาระน่ารู้</option>
                  <option value="เรื่องสั้น">เรื่องสั้น</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold mb-1">ชื่อตอนแรก</label>
                <input
                  id="input-new-novel-chapter-title"
                  type="text"
                  value={newChapterTitle}
                  onChange={(e) => setNewChapterTitle(e.target.value)}
                  placeholder="เช่น ตอนที่ 1: การเดินทางครั้งใหม่"
                  className="w-full px-3 py-2 text-sm rounded-xl bg-stone-100 dark:bg-neutral-800 border border-stone-200 dark:border-neutral-700 focus:ring-2 focus:ring-amber-500 outline-none"
                />
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="text-xs font-semibold">
                  เนื้อหานิยาย <span className="text-red-500">*</span> (วางข้อความหรืออัปโหลดไฟล์ .txt)
                </label>
                <label className="cursor-pointer inline-flex items-center gap-1.5 text-xs text-amber-600 dark:text-amber-400 font-medium hover:underline">
                  <Upload className="w-3.5 h-3.5" />
                  <span>นำเข้าจากไฟล์ .txt</span>
                  <input
                    type="file"
                    accept=".txt"
                    className="hidden"
                    onChange={handleFileUpload}
                  />
                </label>
              </div>
              <textarea
                id="textarea-new-novel-content"
                rows={9}
                required
                value={newContent}
                onChange={(e) => setNewContent(e.target.value)}
                placeholder="พิมพ์หรือวางเนื้อหานิยายที่นี่... ระบบจะตัดแบ่งประโยคและอ่านออกเสียงให้แบบเรียลไทม์"
                className="w-full p-3 text-sm rounded-xl bg-stone-100 dark:bg-neutral-800 border border-stone-200 dark:border-neutral-700 focus:ring-2 focus:ring-amber-500 outline-none font-sarabun leading-relaxed"
              />
              <p className="text-[11px] opacity-60 mt-1">
                จำนวนตัวอักษร: {newContent.length.toLocaleString()} ตัวอักษร
              </p>
            </div>

            <div className="flex justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => setActiveTab('browse')}
                className="px-4 py-2 text-sm rounded-xl border border-stone-300 dark:border-neutral-700 hover:bg-stone-100 dark:hover:bg-neutral-800"
              >
                ยกเลิก
              </button>
              <button
                id="btn-submit-create-novel"
                type="submit"
                className="px-5 py-2 text-sm font-semibold rounded-xl bg-amber-500 hover:bg-amber-600 text-white shadow-sm active:scale-95 transition-all"
              >
                บันทึกและเริ่มอ่าน
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
