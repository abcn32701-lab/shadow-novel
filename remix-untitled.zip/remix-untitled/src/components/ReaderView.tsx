import React, { useEffect, useRef } from 'react';
import { Play, Pause, ChevronLeft, ChevronRight, Volume2, Sparkles, Share2 } from 'lucide-react';
import { Novel, Chapter, ReadingSettings, TextSegment } from '../types';

interface ReaderViewProps {
  currentNovel: Novel;
  currentChapter: Chapter;
  paragraphs: { paragraphIndex: number; segments: TextSegment[] }[];
  currentSegmentIndex: number;
  isPlaying: boolean;
  readingSettings: ReadingSettings;
  isChapterSidebarOpen?: boolean;
  onSelectSegment: (index: number) => void;
  onPrevChapter: () => void;
  onNextChapter: () => void;
  onOpenAddChapter?: () => void;
  hasPrevChapter: boolean;
  hasNextChapter: boolean;
  onOpenAI: () => void;
}

export const ReaderView: React.FC<ReaderViewProps> = ({
  currentNovel,
  currentChapter,
  paragraphs,
  currentSegmentIndex,
  isPlaying,
  readingSettings,
  isChapterSidebarOpen = false,
  onSelectSegment,
  onPrevChapter,
  onNextChapter,
  onOpenAddChapter,
  hasPrevChapter,
  hasNextChapter,
  onOpenAI,
}) => {
  const activeSegmentRef = useRef<HTMLSpanElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);

  // Auto-scroll to active sentence when playing
  useEffect(() => {
    if (readingSettings.autoScroll && isPlaying && activeSegmentRef.current) {
      activeSegmentRef.current.scrollIntoView({
        behavior: 'smooth',
        block: 'center',
      });
    }
  }, [currentSegmentIndex, isPlaying, readingSettings.autoScroll]);

  // Determine theme style classes
  const getThemeContainerClass = () => {
    switch (readingSettings.theme) {
      case 'sepia':
        return 'bg-[#fbf7ee] text-[#382e25] selection:bg-amber-200';
      case 'night':
        return 'bg-[#18181b] text-[#e4e4e7] selection:bg-indigo-900';
      case 'oled':
        return 'bg-[#000000] text-[#d4d4d8] selection:bg-neutral-800';
      case 'light':
      default:
        return 'bg-[#fafaf9] text-[#1c1917] selection:bg-amber-100';
    }
  };

  const getFontClass = () => {
    switch (readingSettings.fontFamily) {
      case 'prompt':
        return 'font-prompt';
      case 'noto':
        return 'font-noto';
      case 'sans':
        return 'font-sans';
      case 'sarabun':
      default:
        return 'font-sarabun';
    }
  };

  const getActiveHighlightClass = () => {
    switch (readingSettings.theme) {
      case 'sepia':
        return 'bg-amber-300/45 text-amber-950 font-medium rounded-sm px-1 py-0.5 shadow-xs ring-1 ring-amber-400/50';
      case 'night':
        return 'bg-indigo-500/25 text-indigo-200 font-medium rounded-sm px-1 py-0.5 shadow-xs ring-1 ring-indigo-400/40';
      case 'oled':
        return 'bg-neutral-800 text-amber-300 font-medium rounded-sm px-1 py-0.5 shadow-xs ring-1 ring-neutral-700';
      case 'light':
      default:
        return 'bg-amber-200/60 text-amber-950 font-medium rounded-sm px-1 py-0.5 shadow-xs ring-1 ring-amber-300/60';
    }
  };

  // Find global index of segment
  let globalCount = 0;

  return (
    <main
      ref={containerRef}
      id="reader-view-container"
      className={`flex-1 overflow-y-auto px-4 sm:px-8 py-8 md:py-12 transition-all duration-200 custom-scrollbar ${
        isChapterSidebarOpen ? 'lg:pl-88 md:pl-84' : ''
      } ${getThemeContainerClass()}`}
    >
      <div className="max-w-3xl mx-auto pb-28 sm:pb-36">
        {/* Chapter Header Info */}
        <header className="mb-10 text-center border-b pb-8 border-current/10">
          {currentNovel.coverImage && (
            <div className="mb-5 flex justify-center">
              <img
                src={currentNovel.coverImage}
                alt={currentNovel.title}
                className="w-24 h-34 sm:w-28 sm:h-40 object-cover rounded-xl shadow-lg border border-current/15"
              />
            </div>
          )}

          <div className="inline-block px-3 py-1 rounded-full text-xs font-medium tracking-wide uppercase mb-3 bg-current/5 opacity-80">
            {currentNovel.category}
          </div>
          <h1 className="text-2xl sm:text-3xl md:text-4xl font-bold tracking-tight mb-2">
            {currentChapter.title}
          </h1>
          <div className="text-xs sm:text-sm opacity-70 flex items-center justify-center gap-2">
            <span className="font-semibold">{currentNovel.title}</span>
            <span>•</span>
            <span>โดย {currentNovel.author}</span>
          </div>

          <div className="mt-4 flex items-center justify-center gap-2">
            <button
              id="btn-quick-summarize"
              onClick={onOpenAI}
              className="inline-flex items-center gap-1.5 text-xs px-3 py-1.5 rounded-full border border-purple-400/30 bg-purple-500/10 hover:bg-purple-500/20 text-purple-700 dark:text-purple-300 transition-colors"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>สรุปบทนี้ด้วย AI</span>
            </button>
          </div>
        </header>

        {/* Story Text Content with Interactive Paragraphs */}
        <article 
          className={`space-y-6 md:space-y-8 leading-relaxed ${getFontClass()}`}
          style={{ 
            fontSize: `${readingSettings.fontSize}px`,
            lineHeight: readingSettings.lineHeight,
          }}
        >
          {paragraphs.map((para) => (
            <p 
              key={`p-${para.paragraphIndex}`}
              className="text-justify indent-6 sm:indent-8"
            >
              {para.segments.map((segment) => {
                const isCurrent = globalCount === currentSegmentIndex;
                const segmentIndex = globalCount;
                globalCount++;

                return (
                  <span
                    key={segment.id}
                    ref={isCurrent ? activeSegmentRef : null}
                    onClick={() => onSelectSegment(segmentIndex)}
                    className={`cursor-pointer transition-all duration-200 inline ${
                      isCurrent 
                        ? getActiveHighlightClass() 
                        : 'hover:opacity-80 hover:bg-current/5 rounded-xs'
                    }`}
                    title="คลิกเพื่อฟังเสียงอ่านจากประโยคนี้"
                  >
                    {isCurrent && isPlaying && (
                      <Volume2 className="inline-block w-3.5 h-3.5 mr-1 text-amber-600 dark:text-amber-400 animate-pulse align-middle" />
                    )}
                    {segment.text}
                    {' '}
                  </span>
                );
              })}
            </p>
          ))}
        </article>

        {/* Chapter Footer Navigation */}
        <footer className="mt-16 pt-8 border-t border-current/10 flex flex-col sm:flex-row items-center justify-between gap-4">
          <button
            id="btn-prev-chapter-bottom"
            onClick={onPrevChapter}
            disabled={!hasPrevChapter}
            className={`w-full sm:w-auto flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl border text-sm font-medium transition-all ${
              !hasPrevChapter 
                ? 'opacity-30 cursor-not-allowed border-current/10' 
                : 'hover:bg-current/10 border-current/20 active:scale-95'
            }`}
          >
            <ChevronLeft className="w-4 h-4" />
            <span>บทก่อนหน้า</span>
          </button>

          <span className="text-xs opacity-60">
            {currentChapter.title}
          </span>

          <div className="flex items-center gap-2">
            {hasNextChapter ? (
              <button
                id="btn-next-chapter-bottom"
                onClick={onNextChapter}
                className="w-full sm:w-auto flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl border text-sm font-medium transition-all bg-amber-500 hover:bg-amber-600 text-white border-amber-500 active:scale-95 shadow-sm"
              >
                <span>บทถัดไป</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            ) : onOpenAddChapter ? (
              <button
                id="btn-add-next-chapter-bottom"
                onClick={onOpenAddChapter}
                className="w-full sm:w-auto flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl border text-sm font-semibold transition-all bg-amber-500 hover:bg-amber-600 text-white border-amber-500 active:scale-95 shadow-sm"
              >
                <span>+ เพิ่มตอนใหม่ถัดไป</span>
              </button>
            ) : (
              <button
                disabled
                className="w-full sm:w-auto flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl border text-sm font-medium opacity-30 cursor-not-allowed border-current/10"
              >
                <span>สิ้นสุดตอน</span>
              </button>
            )}
          </div>
        </footer>
      </div>
    </main>
  );
};
