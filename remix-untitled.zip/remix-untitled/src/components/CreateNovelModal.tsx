import React, { useState, useRef } from 'react';
import { 
  X, 
  Upload, 
  Image as ImageIcon, 
  BookOpen, 
  Trash2,
  Sparkles,
  Check
} from 'lucide-react';
import { Novel, Chapter } from '../types';
import { compressCoverImage } from '../utils/imageHelper';
import { cleanChineseNovelText } from '../utils/chineseNovelHelper';

interface CreateNovelModalProps {
  isOpen: boolean;
  onClose: () => void;
  onCreateNovel: (novel: Novel) => void;
}

export const CreateNovelModal: React.FC<CreateNovelModalProps> = ({
  isOpen,
  onClose,
  onCreateNovel,
}) => {
  const [title, setTitle] = useState('');
  const [author, setAuthor] = useState('แปลไทย');
  const [category, setCategory] = useState('นิยายจีนแปลไทย');
  const [coverImage, setCoverImage] = useState<string | undefined>(undefined);
  const [initialChapterTitle, setInitialChapterTitle] = useState('ตอนที่ 1: ปฐมบท');
  const [initialChapterContent, setInitialChapterContent] = useState('');
  const [isProcessingImage, setIsProcessingImage] = useState(false);

  const fileInputRef = useRef<HTMLInputElement | null>(null);

  if (!isOpen) return null;

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      setIsProcessingImage(true);
      const dataUrl = await compressCoverImage(file, 500, 0.82);
      setCoverImage(dataUrl);
    } catch (err: any) {
      alert(err?.message || 'ไม่สามารถโหลดรูปภาพได้');
    } finally {
      setIsProcessingImage(false);
    }
  };

  const handleRemoveCover = () => {
    setCoverImage(undefined);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;

    const novelId = `novel-${Date.now()}`;
    const chapterId = `chap-${Date.now()}-1`;

    const cleanedContent = initialChapterContent.trim() 
      ? cleanChineseNovelText(initialChapterContent.trim())
      : 'ยังไม่มีเนื้อหาในตอนนี้ สามารถกดแก้ไขเนื้อหาหรือเพิ่มตอนใหม่ได้เลยครับ';

    const newChapter: Chapter = {
      id: chapterId,
      number: 1,
      title: initialChapterTitle.trim() || 'ตอนที่ 1',
      content: cleanedContent,
    };

    const newNovel: Novel = {
      id: novelId,
      title: title.trim(),
      author: author.trim() || 'แปลไทย',
      category: category.trim() || 'นิยายจีนแปลไทย',
      coverColor: 'from-amber-700 to-stone-900',
      coverImage: coverImage,
      description: `นิยายเรื่อง ${title.trim()}`,
      createdAt: Date.now(),
      updatedAt: Date.now(),
      isCustom: true,
      chapters: [newChapter],
    };

    onCreateNovel(newNovel);
    onClose();
  };

  return (
    <div
      id="modal-create-novel-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-sm animate-fade-in"
    >
      <div
        id="modal-create-novel-panel"
        className="bg-white dark:bg-neutral-900 text-stone-900 dark:text-neutral-100 w-full max-w-xl max-h-[90vh] rounded-2xl shadow-2xl border border-stone-200 dark:border-neutral-800 flex flex-col overflow-hidden"
      >
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-stone-200 dark:border-neutral-800 bg-stone-50/50 dark:bg-neutral-900/50">
          <div className="flex items-center gap-2">
            <BookOpen className="w-5 h-5 text-amber-500" />
            <h2 className="text-base sm:text-lg font-bold">
              สร้างนิยายเรื่องใหม่
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg hover:bg-stone-200 dark:hover:bg-neutral-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-5 space-y-4 custom-scrollbar">
          {/* Cover Image Upload Area */}
          <div>
            <label className="block text-xs font-semibold mb-2">
              รูปภาพหน้าปกนิยาย (คุณสามารถเลือกใส่รูปเองได้)
            </label>

            <div className="flex items-center gap-4">
              {/* Cover Preview Card */}
              <div className="w-24 h-32 sm:w-28 sm:h-38 rounded-xl border border-stone-300 dark:border-neutral-700 bg-stone-100 dark:bg-neutral-800 flex flex-col items-center justify-center overflow-hidden relative shadow-sm shrink-0 group">
                {coverImage ? (
                  <>
                    <img
                      src={coverImage}
                      alt="Novel Cover Preview"
                      className="w-full h-full object-cover"
                    />
                    <button
                      type="button"
                      onClick={handleRemoveCover}
                      title="ลบรูปปก"
                      className="absolute top-1 right-1 p-1 rounded-md bg-black/70 text-white hover:bg-red-600 transition-colors opacity-0 group-hover:opacity-100"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </>
                ) : (
                  <div className="text-center p-2">
                    <ImageIcon className="w-8 h-8 mx-auto opacity-40 mb-1 text-amber-500" />
                    <span className="text-[10px] opacity-60 block leading-tight">
                      ยังไม่มีรูปปก
                    </span>
                  </div>
                )}

                {isProcessingImage && (
                  <div className="absolute inset-0 bg-black/60 flex items-center justify-center text-white text-xs">
                    กำลังย่อรูป...
                  </div>
                )}
              </div>

              {/* Upload Actions */}
              <div className="flex-1 space-y-2">
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  onChange={handleImageUpload}
                  className="hidden"
                />

                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="px-3.5 py-2 rounded-xl bg-amber-500 hover:bg-amber-600 text-white font-semibold text-xs flex items-center gap-2 shadow-xs active:scale-95 transition-all"
                >
                  <Upload className="w-3.5 h-3.5" />
                  <span>{coverImage ? 'เปลี่ยนรูปภาพปก' : 'อัปโหลดรูปภาพปกจากเครื่อง'}</span>
                </button>

                <p className="text-[11px] opacity-65 leading-normal">
                  รองรับไฟล์รูปภาพ JPG, PNG, WebP (ระบบจะย่อขนาดให้อัตโนมัติ เพื่อให้บันทึกได้เร็วและประหยัดพื้นที่)
                </p>

                {coverImage && (
                  <button
                    type="button"
                    onClick={handleRemoveCover}
                    className="text-[11px] text-red-500 hover:underline inline-flex items-center gap-1"
                  >
                    <Trash2 className="w-3 h-3" />
                    <span>เอารูปปกออก (ใช้สีปกอัตโนมัติ)</span>
                  </button>
                )}
              </div>
            </div>
          </div>

          {/* Title & Author */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold mb-1">
                ชื่อเรื่องนิยาย <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                required
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="เช่น มหาเทพยุทธ์, จอมมารคืนบัลลังก์"
                className="w-full px-3 py-2 text-sm rounded-xl bg-stone-100 dark:bg-neutral-800 border border-stone-200 dark:border-neutral-700 outline-none focus:ring-2 focus:ring-amber-500 font-bold"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold mb-1">
                ผู้แต่ง / ผู้แปล
              </label>
              <input
                type="text"
                value={author}
                onChange={(e) => setAuthor(e.target.value)}
                placeholder="เช่น แปลไทย, สำนักแปลมังกร"
                className="w-full px-3 py-2 text-sm rounded-xl bg-stone-100 dark:bg-neutral-800 border border-stone-200 dark:border-neutral-700 outline-none focus:ring-2 focus:ring-amber-500"
              />
            </div>
          </div>

          {/* Category */}
          <div>
            <label className="block text-xs font-semibold mb-1">
              หมวดหมู่นิยาย
            </label>
            <div className="flex flex-wrap gap-1.5 mb-2">
              {['นิยายจีนแปลไทย', 'กำลังภายในฝึกตน', 'แฟนตาซีต่างโลก', 'ย้อนเวลาเกิดใหม่', 'รักโรแมนติก'].map((cat) => (
                <button
                  key={cat}
                  type="button"
                  onClick={() => setCategory(cat)}
                  className={`text-[11px] px-2.5 py-1 rounded-lg border transition-colors ${
                    category === cat
                      ? 'bg-amber-500 text-white border-amber-600 font-medium'
                      : 'bg-stone-100 dark:bg-neutral-800 border-stone-200 dark:border-neutral-700 hover:bg-stone-200 dark:hover:bg-neutral-700'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
            <input
              type="text"
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              placeholder="ระบุหมวดหมู่เอง..."
              className="w-full px-3 py-1.5 text-xs rounded-xl bg-stone-100 dark:bg-neutral-800 border border-stone-200 dark:border-neutral-700 outline-none focus:ring-2 focus:ring-amber-500"
            />
          </div>

          {/* Initial Chapter (Optional) */}
          <div className="pt-2 border-t border-stone-200 dark:border-neutral-800">
            <h3 className="text-xs font-bold text-amber-600 dark:text-amber-400 mb-2">
              บทที่ 1 (สามารถใส่เนื้อหาตอนนี้เลย หรือค่อยมาเพิ่มทีหลังได้)
            </h3>

            <div className="space-y-2">
              <input
                type="text"
                value={initialChapterTitle}
                onChange={(e) => setInitialChapterTitle(e.target.value)}
                placeholder="ชื่อตอนที่ 1"
                className="w-full px-3 py-1.5 text-xs rounded-xl bg-stone-100 dark:bg-neutral-800 border border-stone-200 dark:border-neutral-700 outline-none focus:ring-2 focus:ring-amber-500 font-semibold"
              />

              <textarea
                rows={4}
                value={initialChapterContent}
                onChange={(e) => setInitialChapterContent(e.target.value)}
                placeholder="วางเนื้อหานิยายตอนที่ 1 (เว้นว่างไว้เพื่อใส่ทีหลังได้)..."
                className="w-full p-2.5 text-xs rounded-xl bg-stone-100 dark:bg-neutral-800 border border-stone-200 dark:border-neutral-700 outline-none focus:ring-2 focus:ring-amber-500 font-sarabun leading-relaxed"
              />
            </div>
          </div>

          {/* Footer Buttons */}
          <div className="flex justify-end gap-2.5 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs sm:text-sm rounded-xl border border-stone-300 dark:border-neutral-700 hover:bg-stone-100 dark:hover:bg-neutral-800"
            >
              ยกเลิก
            </button>
            <button
              type="submit"
              className="px-5 py-2 text-xs sm:text-sm font-semibold rounded-xl bg-amber-500 hover:bg-amber-600 text-white shadow-sm active:scale-95 transition-all"
            >
              สร้างนิยายและเปิดอ่าน
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
