import React from 'react';
import { 
  X, 
  User, 
  Mail, 
  ShieldCheck, 
  Headphones, 
  LogOut, 
  Heart, 
  Calendar, 
  Clock, 
  BookOpen, 
  ExternalLink 
} from 'lucide-react';
import { UserProfile, UserRole, Novel } from '../types';

interface UserProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: UserProfile | null;
  novels: Novel[];
  onLogout: () => void;
  onToggleUserRole: () => void;
  onSelectNovel: (novelId: string) => void;
}

export const UserProfileModal: React.FC<UserProfileModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  novels,
  onLogout,
  onToggleUserRole,
  onSelectNovel
}) => {
  if (!isOpen || !currentUser) return null;

  const favoriteNovels = novels.filter(n => (currentUser.favorites || []).includes(n.id));

  const memberSinceFormatted = new Date(currentUser.createdAt).toLocaleDateString('th-TH', {
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  });

  return (
    <div
      id="user-profile-modal-overlay"
      className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-3.5 sm:p-5 animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div
        className="w-full max-w-md rounded-3xl border border-stone-200 dark:border-neutral-800 bg-white dark:bg-neutral-900 text-stone-900 dark:text-neutral-100 shadow-2xl overflow-hidden flex flex-col transition-all"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-stone-200 dark:border-neutral-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <User className="w-5 h-5 text-amber-500" />
            <span className="font-extrabold text-base">โปรไฟล์ผู้ใช้งาน</span>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-stone-100 dark:hover:bg-neutral-800 text-stone-500 hover:text-stone-800 dark:hover:text-neutral-200 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Profile Card */}
        <div className="p-5 sm:p-6 space-y-5 overflow-y-auto max-h-[75vh]">
          <div className="flex items-center gap-4">
            {/* User Avatar Circle */}
            <div className={`w-16 h-16 rounded-2xl bg-gradient-to-br ${currentUser.avatarColor || 'from-amber-500 to-amber-600'} text-white flex items-center justify-center text-2xl font-black shadow-md shrink-0`}>
              {currentUser.name.slice(0, 1).toUpperCase()}
            </div>

            <div className="min-w-0 flex-1">
              <div className="flex items-center gap-2 mb-1">
                <h3 className="font-black text-lg truncate">
                  {currentUser.name}
                </h3>
                <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full flex items-center gap-1 ${
                  currentUser.role === 'admin'
                    ? 'bg-amber-500/20 text-amber-700 dark:text-amber-300'
                    : 'bg-indigo-500/20 text-indigo-700 dark:text-indigo-300'
                }`}>
                  {currentUser.role === 'admin' ? <ShieldCheck className="w-3 h-3" /> : <Headphones className="w-3 h-3" />}
                  <span>{currentUser.role === 'admin' ? 'แอดมิน' : 'คนฟัง'}</span>
                </span>
              </div>

              <p className="text-xs text-stone-500 dark:text-neutral-400 flex items-center gap-1.5 truncate">
                <Mail className="w-3.5 h-3.5 opacity-60" />
                <span>{currentUser.email}</span>
              </p>

              <p className="text-[11px] text-stone-400 dark:text-neutral-500 mt-1 flex items-center gap-1">
                <Calendar className="w-3 h-3" />
                <span>สมัครเมื่อ: {memberSinceFormatted}</span>
              </p>
            </div>
          </div>

          {/* Quick Switch Role or Role Info */}
          <div className="p-3 rounded-2xl bg-stone-100 dark:bg-neutral-800 flex items-center justify-between gap-3 text-xs">
            <div>
              <span className="font-bold block">บทบาทของคุณในปัจจุบัน:</span>
              <span className="opacity-75">
                {currentUser.role === 'admin' ? '👑 ผู้ดูแลระบบ (จัดการนิยายได้เต็มที่)' : '🎧 ผู้ฟัง (เปิดรับฟังและอ่านนิยาย)'}
              </span>
            </div>
            <button
              onClick={() => {
                onToggleUserRole();
              }}
              className="px-3 py-1.5 rounded-xl border border-current/20 hover:bg-black/5 dark:hover:bg-white/5 font-bold transition-colors shrink-0"
            >
              สลับบทบาท
            </button>
          </div>

          {/* Saved / Favorite Novels */}
          <div className="space-y-2 pt-2 border-t border-stone-200 dark:border-neutral-800">
            <div className="flex items-center justify-between">
              <span className="font-bold text-xs flex items-center gap-1.5 text-stone-700 dark:text-neutral-300">
                <Heart className="w-3.5 h-3.5 text-rose-500 fill-current" />
                <span>นิยายที่บันทึกไว้ / รายการโปรด ({favoriteNovels.length}):</span>
              </span>
            </div>

            {favoriteNovels.length === 0 ? (
              <p className="text-xs text-stone-400 dark:text-neutral-500 py-3 text-center bg-stone-50 dark:bg-neutral-800/50 rounded-xl">
                ยังไม่มีนิยายในรายการโปรด คุณสามารถกดรูปหัวใจที่หน้านิยายเพื่อบันทึกไว้ได้
              </p>
            ) : (
              <div className="space-y-1.5 max-h-40 overflow-y-auto pr-1 custom-scrollbar">
                {favoriteNovels.map((novel) => (
                  <div
                    key={novel.id}
                    onClick={() => {
                      onSelectNovel(novel.id);
                      onClose();
                    }}
                    className="p-2 rounded-xl border border-stone-200 dark:border-neutral-800 hover:border-amber-500/50 hover:bg-amber-500/5 flex items-center justify-between gap-2 cursor-pointer transition-colors"
                  >
                    <div className="flex items-center gap-2 min-w-0">
                      <BookOpen className="w-4 h-4 text-amber-500 shrink-0" />
                      <span className="text-xs font-bold truncate">{novel.title}</span>
                    </div>
                    <span className="text-[10px] opacity-60 shrink-0">{novel.chapters.length} ตอน</span>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Logout Button */}
          <div className="pt-3 border-t border-stone-200 dark:border-neutral-800">
            <button
              onClick={() => {
                onLogout();
                onClose();
              }}
              className="w-full py-2.5 px-4 rounded-xl border border-red-500/30 hover:bg-red-500/10 text-red-600 dark:text-red-400 font-bold text-xs sm:text-sm flex items-center justify-center gap-2 transition-colors"
            >
              <LogOut className="w-4 h-4" />
              <span>ออกจากระบบ (Log Out)</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
