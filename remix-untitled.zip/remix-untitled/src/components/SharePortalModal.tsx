import React, { useState } from 'react';
import { 
  X, 
  Copy, 
  Check, 
  ExternalLink, 
  Share2, 
  Headphones, 
  Globe, 
  Sparkles, 
  QrCode,
  ShieldCheck,
  CheckCircle2
} from 'lucide-react';

interface SharePortalModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const SharePortalModal: React.FC<SharePortalModalProps> = ({ isOpen, onClose }) => {
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  // Build the direct listener link
  const origin = window.location.origin;
  const pathname = window.location.pathname;
  const listenerLink = `${origin}${pathname}?role=listener`;

  const handleCopy = () => {
    navigator.clipboard.writeText(listenerLink).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    }).catch(() => {
      // Fallback
      const textArea = document.createElement('textarea');
      textArea.value = listenerLink;
      document.body.appendChild(textArea);
      textArea.select();
      document.execCommand('copy');
      document.body.removeChild(textArea);
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    });
  };

  const handleOpenNewTab = () => {
    window.open(listenerLink, '_blank');
  };

  return (
    <div
      id="share-portal-modal-overlay"
      className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-3.5 sm:p-5 animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div
        className="w-full max-w-lg rounded-3xl border border-stone-200 dark:border-neutral-800 bg-white dark:bg-neutral-900 text-stone-900 dark:text-neutral-100 shadow-2xl overflow-hidden flex flex-col transition-all"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-stone-200 dark:border-neutral-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-indigo-500 to-purple-600 text-white flex items-center justify-center shadow-xs">
              <Globe className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-extrabold text-base sm:text-lg leading-tight">
                ลิงก์หน้าเว็บสำหรับคนดู / คนฟังเต็มรูปแบบ
              </h3>
              <p className="text-xs text-stone-500 dark:text-neutral-400">
                Shadow Novel Listener Web Portal Link
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-stone-100 dark:hover:bg-neutral-800 text-stone-500 hover:text-stone-800 dark:hover:text-neutral-200 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="p-4 sm:p-6 space-y-4">
          {/* Explanation Card */}
          <div className="p-3.5 rounded-2xl bg-indigo-500/10 border border-indigo-500/20 text-indigo-950 dark:text-indigo-200 flex items-start gap-3 text-xs leading-relaxed">
            <Headphones className="w-5 h-5 text-indigo-600 dark:text-indigo-400 shrink-0 mt-0.5" />
            <div>
              <span className="font-bold block mb-0.5">
                ลิงก์นี้คือหน้าเว็บแบบไหน?
              </span>
              <span>
                เมื่อนำลิงก์นี้ไปเปิด หรือส่งให้เพื่อน/ผู้ฟัง หน้าเว็บจะเปิดเป็น <strong>"โหมดคนดูเต็มจอ (Viewer Portal)"</strong> ทันที โดยอัตโนมัติ 
                สะอาดตา ไม่มีปุ่มแอดมินหรือปุ่มลบมารบกวนสายตา คนดูสามารถเลือกนิยาย กดฟังเสียงบรรยาย และอ่านเนื้อหาได้ทันทีครับ
              </span>
            </div>
          </div>

          {/* URL Box with Copy Button */}
          <div>
            <label className="block text-xs font-bold text-stone-700 dark:text-neutral-300 mb-1.5">
              ลิงก์ตรงสำหรับเปิดดู / แชร์ (Direct Shareable Link):
            </label>
            <div className="flex items-center gap-2">
              <input
                type="text"
                readOnly
                value={listenerLink}
                className="flex-1 px-3 py-2.5 rounded-xl border border-stone-300 dark:border-neutral-700 bg-stone-50 dark:bg-neutral-800 text-xs font-mono text-stone-800 dark:text-neutral-200 select-all focus:outline-none"
              />
              <button
                onClick={handleCopy}
                className={`px-3.5 py-2.5 rounded-xl font-bold text-xs flex items-center gap-1.5 transition-all shrink-0 ${
                  copied 
                    ? 'bg-emerald-600 text-white' 
                    : 'bg-amber-500 hover:bg-amber-600 text-white shadow-xs active:scale-95'
                }`}
                title="คลิกเพื่อคัดลอกลิงก์"
              >
                {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                <span>{copied ? 'คัดลอกแล้ว!' : 'คัดลอกลิงก์'}</span>
              </button>
            </div>
            {copied && (
              <p className="text-[11px] font-semibold text-emerald-600 dark:text-emerald-400 mt-1 flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>คัดลอกลิงก์ลงคลิปบอร์ดแล้ว คุณสามารถกด Paste / วาง ในแชท หรือเบราว์เซอร์ได้เลย</span>
              </p>
            )}
          </div>

          {/* Primary Action: Open in Fullscreen / New Tab */}
          <div className="pt-2">
            <button
              onClick={handleOpenNewTab}
              className="w-full py-3 px-4 rounded-2xl bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-white font-extrabold text-sm flex items-center justify-center gap-2 shadow-md active:scale-98 transition-all"
            >
              <ExternalLink className="w-4 h-4" />
              <span>เปิดดูหน้าเว็บคนดูเต็มจอในแท็บใหม่ (Open in New Tab)</span>
            </button>
            <p className="text-[11px] text-center text-stone-500 dark:text-neutral-400 mt-1.5">
              ระบบจะเปิดเบราว์เซอร์แท็บใหม่แบบเต็มหน้าจอ ให้คุณสัมผัสประสบการณ์เหมือนคนดูจริง
            </p>
          </div>

          {/* How to use checklist */}
          <div className="pt-3 border-t border-stone-200 dark:border-neutral-800 space-y-2">
            <span className="text-xs font-bold text-stone-700 dark:text-neutral-300 block">
              วิธีนำไปใช้:
            </span>
            <ul className="text-xs text-stone-600 dark:text-neutral-400 space-y-1 list-disc list-inside">
              <li>ส่งลิงก์นี้ให้เพื่อนทาง LINE, Facebook หรือโซเชียลมีเดีย</li>
              <li>ผู้ฟังเปิดผ่านมือถือหรือคอมพิวเตอร์ได้ทันทีโดยไม่ต้องโหลดแอป</li>
              <li>ผู้ฟังสามารถสมัครสมาชิกเพื่อบันทึกประวัติการฟังและรายการโปรดของตนเองได้</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};
