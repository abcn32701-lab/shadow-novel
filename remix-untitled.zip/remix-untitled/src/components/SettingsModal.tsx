import React from 'react';
import { 
  X, 
  Sliders, 
  Volume2, 
  Type, 
  Palette, 
  Mic, 
  Gauge, 
  Music,
  Check
} from 'lucide-react';
import { 
  SpeechSettings, 
  ReadingSettings, 
  ReaderTheme, 
  ReaderFont 
} from '../types';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  speechSettings: SpeechSettings;
  readingSettings: ReadingSettings;
  availableVoices: SpeechSynthesisVoice[];
  onUpdateSpeechSettings: (newSettings: Partial<SpeechSettings>) => void;
  onUpdateReadingSettings: (newSettings: Partial<ReadingSettings>) => void;
  onTestVoice: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  speechSettings,
  readingSettings,
  availableVoices,
  onUpdateSpeechSettings,
  onUpdateReadingSettings,
  onTestVoice,
}) => {
  if (!isOpen) return null;

  // Filter Thai voices first
  const thaiVoices = availableVoices.filter(v => 
    v.lang.toLowerCase().startsWith('th') || v.name.toLowerCase().includes('thai')
  );
  const otherVoices = availableVoices.filter(v => 
    !v.lang.toLowerCase().startsWith('th') && !v.name.toLowerCase().includes('thai')
  );

  const themeOptions: { id: ReaderTheme; name: string; bg: string; border: string; text: string }[] = [
    { id: 'sepia', name: 'ถนอมสายตา', bg: 'bg-[#fbf7ee]', border: 'border-[#dfcfb0]', text: 'text-[#382e25]' },
    { id: 'light', name: 'สว่าง', bg: 'bg-white', border: 'border-stone-300', text: 'text-stone-900' },
    { id: 'night', name: 'กลางคืน', bg: 'bg-[#18181b]', border: 'border-neutral-700', text: 'text-neutral-100' },
    { id: 'oled', name: 'มิดไนท์ดำสนิท', bg: 'bg-black', border: 'border-neutral-800', text: 'text-neutral-200' },
  ];

  const fontOptions: { id: ReaderFont; name: string; fontClass: string }[] = [
    { id: 'sarabun', name: 'Sarabun (สารบัญ - อ่านง่ายสบายตา)', fontClass: 'font-sarabun' },
    { id: 'prompt', name: 'Prompt (พร้อมท์ - โมเดิร์นทันสมัย)', fontClass: 'font-prompt' },
    { id: 'noto', name: 'Noto Serif (นิยายคลาสสิก)', fontClass: 'font-noto' },
    { id: 'sans', name: 'System Sans (ค่าเริ่มต้นของระบบ)', fontClass: 'font-sans' },
  ];

  return (
    <div 
      id="modal-settings-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fade-in"
    >
      <div 
        id="modal-settings-panel"
        className="bg-white dark:bg-neutral-900 text-stone-900 dark:text-neutral-100 w-full max-w-2xl max-h-[85vh] rounded-2xl shadow-2xl border border-stone-200 dark:border-neutral-800 flex flex-col overflow-hidden"
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-stone-200 dark:border-neutral-800">
          <div className="flex items-center gap-2">
            <Sliders className="w-5 h-5 text-amber-500" />
            <h2 className="text-lg font-bold">ตั้งค่าเสียงและรูปแบบการอ่าน</h2>
          </div>
          <button
            id="btn-close-settings-modal"
            onClick={onClose}
            className="p-1.5 rounded-lg hover:bg-stone-100 dark:hover:bg-neutral-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body content with tabs/sections */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6 custom-scrollbar">
          {/* SECTION 1: VOICE & TTS SETTINGS */}
          <section className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold flex items-center gap-2 text-amber-600 dark:text-amber-400">
                <Mic className="w-4 h-4" />
                <span>การอ่านออกเสียง (Text-to-Speech)</span>
              </h3>
              <button
                id="btn-test-voice"
                type="button"
                onClick={onTestVoice}
                className="text-xs px-2.5 py-1 rounded-lg border border-amber-500/40 bg-amber-500/10 text-amber-700 dark:text-amber-300 hover:bg-amber-500/20 transition-colors"
              >
                🔊 ทดสอบเสียงอ่าน
              </button>
            </div>

            {/* Engine & Voice Select */}
            <div className="space-y-3">
              <div>
                <label className="block text-xs font-semibold mb-1 text-stone-600 dark:text-neutral-400">
                  แหล่งเสียง (TTS Engine)
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => onUpdateSpeechSettings({ engine: 'edge-tts' })}
                    className={`px-3 py-2 text-xs font-medium rounded-xl border text-left transition-all ${
                      speechSettings.engine === 'edge-tts'
                        ? 'border-amber-500 bg-amber-500/10 text-amber-900 dark:text-amber-200 ring-2 ring-amber-500/30 font-bold'
                        : 'border-stone-200 dark:border-neutral-700 hover:bg-stone-50 dark:hover:bg-neutral-800'
                    }`}
                  >
                    <div className="flex items-center gap-1.5 text-amber-600 dark:text-amber-400 font-semibold">
                      <span>✨ Edge TTS (Neural AI)</span>
                    </div>
                    <div className="text-[11px] opacity-70 mt-0.5">เสียงสมจริงระดับมนุษย์ รองรับ Premwadee</div>
                  </button>

                  <button
                    type="button"
                    onClick={() => onUpdateSpeechSettings({ engine: 'web-speech' })}
                    className={`px-3 py-2 text-xs font-medium rounded-xl border text-left transition-all ${
                      speechSettings.engine === 'web-speech'
                        ? 'border-amber-500 bg-amber-500/10 text-amber-900 dark:text-amber-200 ring-2 ring-amber-500/30 font-bold'
                        : 'border-stone-200 dark:border-neutral-700 hover:bg-stone-50 dark:hover:bg-neutral-800'
                    }`}
                  >
                    <div className="flex items-center gap-1.5 text-stone-700 dark:text-neutral-300 font-semibold">
                      <span>🌐 Web Speech API</span>
                    </div>
                    <div className="text-[11px] opacity-70 mt-0.5">เสียงในเบราว์เซอร์ / ออฟไลน์</div>
                  </button>
                </div>
              </div>

              {speechSettings.engine === 'edge-tts' ? (
                <div>
                  <label className="block text-xs font-semibold mb-1">
                    เลือกเสียง Microsoft Edge TTS
                  </label>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={() => onUpdateSpeechSettings({ edgeVoice: 'th-TH-PremwadeeNeural' })}
                      className={`p-3 rounded-xl border text-left transition-all flex items-start gap-2.5 ${
                        speechSettings.edgeVoice === 'th-TH-PremwadeeNeural' || !speechSettings.edgeVoice
                          ? 'border-amber-500 bg-amber-500/10 text-amber-900 dark:text-amber-200 ring-2 ring-amber-500/30'
                          : 'border-stone-200 dark:border-neutral-700 hover:bg-stone-50 dark:hover:bg-neutral-800'
                      }`}
                    >
                      <span className="text-xl">👩‍💼</span>
                      <div>
                        <div className="text-xs font-bold flex items-center gap-1.5">
                          <span>Premwadee (หญิง)</span>
                          <span className="text-[10px] px-1.5 py-0.2 bg-amber-500 text-white rounded-full font-medium">แนะนำ</span>
                        </div>
                        <p className="text-[11px] text-stone-500 dark:text-neutral-400 mt-0.5">
                          th-TH-PremwadeeNeural (เสียงหวาน อ่อนโยน เหมาะกับนิยาย)
                        </p>
                      </div>
                    </button>

                    <button
                      type="button"
                      onClick={() => onUpdateSpeechSettings({ edgeVoice: 'th-TH-NiwatNeural' })}
                      className={`p-3 rounded-xl border text-left transition-all flex items-start gap-2.5 ${
                        speechSettings.edgeVoice === 'th-TH-NiwatNeural'
                          ? 'border-amber-500 bg-amber-500/10 text-amber-900 dark:text-amber-200 ring-2 ring-amber-500/30'
                          : 'border-stone-200 dark:border-neutral-700 hover:bg-stone-50 dark:hover:bg-neutral-800'
                      }`}
                    >
                      <span className="text-xl">👨‍💼</span>
                      <div>
                        <div className="text-xs font-bold">
                          <span>Niwat (ชาย)</span>
                        </div>
                        <p className="text-[11px] text-stone-500 dark:text-neutral-400 mt-0.5">
                          th-TH-NiwatNeural (เสียงทุ้ม เข้มขรึม กังวาน)
                        </p>
                      </div>
                    </button>
                  </div>
                </div>
              ) : (
                <div>
                  <label className="block text-xs font-semibold mb-1">
                    เลือกเสียงผู้พากย์ในเบราว์เซอร์
                  </label>
                  <select
                    id="select-voice-engine"
                    value={speechSettings.voiceURI}
                    onChange={(e) => onUpdateSpeechSettings({ voiceURI: e.target.value })}
                    className="w-full px-3 py-2 text-sm rounded-xl bg-stone-100 dark:bg-neutral-800 border border-stone-200 dark:border-neutral-700 focus:ring-2 focus:ring-amber-500 outline-none"
                  >
                    <optgroup label="เสียงภาษาไทย (แนะนำ)">
                      {thaiVoices.length > 0 ? (
                        thaiVoices.map((v) => (
                          <option key={v.voiceURI} value={v.voiceURI}>
                            🇹🇭 {v.name} ({v.lang})
                          </option>
                        ))
                      ) : (
                        <option value="">เสียงภาษาไทยอัตโนมัติ (Default Thai Voice)</option>
                      )}
                    </optgroup>

                    {otherVoices.length > 0 && (
                      <optgroup label="เสียงภาษาอื่นๆ">
                        {otherVoices.slice(0, 15).map((v) => (
                          <option key={v.voiceURI} value={v.voiceURI}>
                            {v.name} ({v.lang})
                          </option>
                        ))}
                      </optgroup>
                    )}
                  </select>
                </div>
              )}
            </div>

            {/* Speed Rate Slider & Chips */}
            <div>
              <div className="flex justify-between items-center text-xs font-semibold mb-1">
                <span>ความเร็วในการอ่าน (Speed)</span>
                <span className="text-amber-600 dark:text-amber-400 font-mono font-bold">
                  {speechSettings.rate}x
                </span>
              </div>
              <input
                id="slider-voice-rate"
                type="range"
                min="0.5"
                max="2.0"
                step="0.05"
                value={speechSettings.rate}
                onChange={(e) => onUpdateSpeechSettings({ rate: parseFloat(e.target.value) })}
                className="w-full accent-amber-500 cursor-pointer"
              />
              <div className="flex gap-1.5 mt-2">
                {[0.75, 1.0, 1.25, 1.5, 1.75, 2.0].map((rateVal) => (
                  <button
                    key={rateVal}
                    type="button"
                    onClick={() => onUpdateSpeechSettings({ rate: rateVal })}
                    className={`flex-1 py-1 text-xs rounded-lg border transition-all ${
                      speechSettings.rate === rateVal
                        ? 'bg-amber-500 text-white border-amber-500 font-bold'
                        : 'bg-stone-50 dark:bg-neutral-800 border-stone-200 dark:border-neutral-700 hover:bg-stone-100'
                    }`}
                  >
                    {rateVal}x
                  </button>
                ))}
              </div>
            </div>

            {/* Pitch Slider */}
            <div>
              <div className="flex justify-between items-center text-xs font-semibold mb-1">
                <span>ระดับโทนเสียง (Pitch ทุ้ม-แหลม)</span>
                <span className="opacity-70 font-mono font-bold">
                  {speechSettings.pitch.toFixed(1)}
                </span>
              </div>
              <input
                id="slider-voice-pitch"
                type="range"
                min="0.6"
                max="1.4"
                step="0.1"
                value={speechSettings.pitch}
                onChange={(e) => onUpdateSpeechSettings({ pitch: parseFloat(e.target.value) })}
                className="w-full accent-amber-500 cursor-pointer"
              />
              <div className="flex justify-between text-[11px] opacity-60">
                <span>เสียงทุ้มลึก</span>
                <span>มาตรฐาน (1.0)</span>
                <span>เสียงใสแหลม</span>
              </div>
            </div>
          </section>

          <hr className="border-stone-200 dark:border-neutral-800" />

          {/* SECTION 2: READING THEME & APPEARANCE */}
          <section className="space-y-4">
            <h3 className="text-sm font-bold flex items-center gap-2 text-amber-600 dark:text-amber-400">
              <Palette className="w-4 h-4" />
              <span>โทนสีและธีมหน้าจอ (Reading Themes)</span>
            </h3>

            {/* Theme cards */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
              {themeOptions.map((opt) => (
                <button
                  key={opt.id}
                  type="button"
                  id={`btn-theme-${opt.id}`}
                  onClick={() => onUpdateReadingSettings({ theme: opt.id })}
                  className={`p-3 rounded-xl border-2 flex flex-col items-center gap-1.5 transition-all text-xs font-medium relative ${opt.bg} ${opt.border} ${opt.text} ${
                    readingSettings.theme === opt.id 
                      ? 'ring-2 ring-amber-500 scale-[1.02] shadow-sm' 
                      : 'opacity-80 hover:opacity-100'
                  }`}
                >
                  {readingSettings.theme === opt.id && (
                    <div className="absolute top-1.5 right-1.5 w-4 h-4 rounded-full bg-amber-500 text-white flex items-center justify-center">
                      <Check className="w-2.5 h-2.5 stroke-[3]" />
                    </div>
                  )}
                  <span className="font-semibold">{opt.name}</span>
                  <span className="text-[10px] opacity-70">ตัวอย่างข้อความ</span>
                </button>
              ))}
            </div>
          </section>

          <hr className="border-stone-200 dark:border-neutral-800" />

          {/* SECTION 3: TYPOGRAPHY & SIZING */}
          <section className="space-y-4">
            <h3 className="text-sm font-bold flex items-center gap-2 text-amber-600 dark:text-amber-400">
              <Type className="w-4 h-4" />
              <span>ฟอนต์และขนาดตัวหนังสือ (Typography)</span>
            </h3>

            {/* Font Family selector */}
            <div className="space-y-1.5">
              {fontOptions.map((f) => (
                <button
                  key={f.id}
                  type="button"
                  id={`btn-font-${f.id}`}
                  onClick={() => onUpdateReadingSettings({ fontFamily: f.id })}
                  className={`w-full p-2.5 rounded-xl border text-left text-xs transition-all flex items-center justify-between ${
                    readingSettings.fontFamily === f.id
                      ? 'bg-amber-500/10 border-amber-500 text-amber-700 dark:text-amber-300 font-semibold'
                      : 'bg-stone-50 dark:bg-neutral-800 border-stone-200 dark:border-neutral-700 hover:bg-stone-100'
                  }`}
                >
                  <span className={f.fontClass}>{f.name}</span>
                  {readingSettings.fontFamily === f.id && (
                    <Check className="w-4 h-4 text-amber-500" />
                  )}
                </button>
              ))}
            </div>

            {/* Font Size Adjuster */}
            <div>
              <div className="flex justify-between items-center text-xs font-semibold mb-1">
                <span>ขนาดตัวอักษร</span>
                <span className="font-mono text-amber-600 dark:text-amber-400 font-bold">
                  {readingSettings.fontSize}px
                </span>
              </div>
              <div className="flex items-center gap-3">
                <button
                  type="button"
                  onClick={() => onUpdateReadingSettings({ 
                    fontSize: Math.max(14, readingSettings.fontSize - 1) 
                  })}
                  className="px-3 py-1 text-xs font-bold rounded-lg border border-stone-300 dark:border-neutral-700 hover:bg-stone-100 dark:hover:bg-neutral-800"
                >
                  A-
                </button>
                <input
                  id="slider-font-size"
                  type="range"
                  min="14"
                  max="28"
                  step="1"
                  value={readingSettings.fontSize}
                  onChange={(e) => onUpdateReadingSettings({ fontSize: parseInt(e.target.value) })}
                  className="flex-1 accent-amber-500 cursor-pointer"
                />
                <button
                  type="button"
                  onClick={() => onUpdateReadingSettings({ 
                    fontSize: Math.min(28, readingSettings.fontSize + 1) 
                  })}
                  className="px-3 py-1 text-xs font-bold rounded-lg border border-stone-300 dark:border-neutral-700 hover:bg-stone-100 dark:hover:bg-neutral-800"
                >
                  A+
                </button>
              </div>
            </div>

            {/* Line Height Adjuster */}
            <div>
              <div className="flex justify-between items-center text-xs font-semibold mb-1">
                <span>ระยะห่างบรรทัด (Line Height)</span>
                <span className="opacity-70 font-mono">
                  {readingSettings.lineHeight}
                </span>
              </div>
              <div className="grid grid-cols-3 gap-2">
                {[
                  { label: 'กระชับ', val: 1.6 },
                  { label: 'พอดี (สบายตา)', val: 1.85 },
                  { label: 'โปร่งสบาย', val: 2.2 },
                ].map((lh) => (
                  <button
                    key={lh.val}
                    type="button"
                    onClick={() => onUpdateReadingSettings({ lineHeight: lh.val })}
                    className={`py-1.5 text-xs rounded-lg border transition-all ${
                      readingSettings.lineHeight === lh.val
                        ? 'bg-amber-500 text-white border-amber-500 font-semibold'
                        : 'bg-stone-50 dark:bg-neutral-800 border-stone-200 dark:border-neutral-700 hover:bg-stone-100'
                    }`}
                  >
                    {lh.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Toggles: Auto scroll & auto chapter */}
            <div className="space-y-2 pt-2">
              <label className="flex items-center justify-between p-3 rounded-xl bg-stone-50 dark:bg-neutral-800 border border-stone-200 dark:border-neutral-750 cursor-pointer">
                <div>
                  <span className="text-xs font-semibold block">เลื่อนหน้าจอตามอัตโนมัติ (Auto-scroll)</span>
                  <span className="text-[11px] opacity-60 block">เลื่อนหน้าเว็บตามประโยคที่กำลังอ่านออกเสียง</span>
                </div>
                <input
                  id="checkbox-autoscroll"
                  type="checkbox"
                  checked={readingSettings.autoScroll}
                  onChange={(e) => onUpdateReadingSettings({ autoScroll: e.target.checked })}
                  className="w-4 h-4 accent-amber-500 rounded-sm"
                />
              </label>

              <label className="flex items-center justify-between p-3 rounded-xl bg-stone-50 dark:bg-neutral-800 border border-stone-200 dark:border-neutral-750 cursor-pointer">
                <div>
                  <span className="text-xs font-semibold block">เล่นบทถัดไปอัตโนมัติ (Continuous Play)</span>
                  <span className="text-[11px] opacity-60 block">เมื่ออ่านจบตอน จะเปิดตอนถัดไปให้อัตโนมัติ</span>
                </div>
                <input
                  id="checkbox-auto-next-chapter"
                  type="checkbox"
                  checked={readingSettings.autoNextChapter}
                  onChange={(e) => onUpdateReadingSettings({ autoNextChapter: e.target.checked })}
                  className="w-4 h-4 accent-amber-500 rounded-sm"
                />
              </label>
            </div>
          </section>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-stone-200 dark:border-neutral-800 flex justify-end">
          <button
            id="btn-done-settings"
            onClick={onClose}
            className="px-6 py-2 text-sm font-semibold rounded-xl bg-amber-500 hover:bg-amber-600 text-white shadow-sm"
          >
            เสร็จสิ้น
          </button>
        </div>
      </div>
    </div>
  );
};
