import React from 'react';
import { 
  Play, 
  Pause, 
  SkipBack, 
  SkipForward, 
  RotateCcw, 
  Volume2, 
  VolumeX, 
  Gauge, 
  Sliders,
  ChevronUp,
  Timer
} from 'lucide-react';
import { SpeechSettings, TextSegment, ReadingSettings } from '../types';

interface AudioPlayerBarProps {
  isPlaying: boolean;
  isPaused: boolean;
  currentIndex: number;
  totalSegments: number;
  currentSegment: TextSegment | null;
  speechSettings: SpeechSettings;
  readingSettings: ReadingSettings;
  sleepTimerRemaining: number | null;
  onPlay: () => void;
  onPause: () => void;
  onPrevSegment: () => void;
  onNextSegment: () => void;
  onRestartChapter: () => void;
  onChangeRate: (rate: number) => void;
  onOpenSettings: () => void;
  onOpenSleepTimer: () => void;
  onToggleAutoScroll: () => void;
}

export const AudioPlayerBar: React.FC<AudioPlayerBarProps> = ({
  isPlaying,
  isPaused,
  currentIndex,
  totalSegments,
  currentSegment,
  speechSettings,
  readingSettings,
  sleepTimerRemaining,
  onPlay,
  onPause,
  onPrevSegment,
  onNextSegment,
  onRestartChapter,
  onChangeRate,
  onOpenSettings,
  onOpenSleepTimer,
  onToggleAutoScroll,
}) => {
  const isDark = readingSettings.theme === 'night' || readingSettings.theme === 'oled';

  // Format timer
  const formatTimer = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  const progressPercent = totalSegments > 0 
    ? Math.min(100, Math.round(((currentIndex + 1) / totalSegments) * 100))
    : 0;

  // Speeds
  const availableRates = [0.75, 1.0, 1.25, 1.5, 2.0];

  const cycleRate = () => {
    const idx = availableRates.indexOf(speechSettings.rate);
    const nextRate = idx === -1 || idx === availableRates.length - 1 
      ? availableRates[0] 
      : availableRates[idx + 1];
    onChangeRate(nextRate);
  };

  return (
    <div 
      id="floating-audio-player-bar"
      className={`fixed bottom-0 left-0 right-0 z-50 border-t transition-all duration-200 shadow-2xl backdrop-blur-lg ${
        readingSettings.theme === 'oled'
          ? 'bg-black/95 border-neutral-900 text-neutral-100'
          : readingSettings.theme === 'night'
          ? 'bg-neutral-900/95 border-neutral-800 text-neutral-200'
          : readingSettings.theme === 'sepia'
          ? 'bg-[#f4ecd8]/95 border-[#e2d5bd] text-[#4a3b32]'
          : 'bg-white/95 border-stone-200 text-stone-900'
      }`}
    >
      {/* Top Progress Bar */}
      <div 
        className="w-full h-1.5 bg-black/5 dark:bg-white/10 relative cursor-pointer group"
        title={`ความคืบหน้า: ${progressPercent}%`}
      >
        <div 
          className="h-full bg-amber-500 transition-all duration-300 relative"
          style={{ width: `${progressPercent}%` }}
        >
          <div className="absolute right-0 top-1/2 -translate-y-1/2 w-3 h-3 rounded-full bg-amber-600 shadow-sm opacity-0 group-hover:opacity-100 transition-opacity" />
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 py-2.5 sm:py-3">
        {/* Active sentence preview line */}
        <div className="flex items-center justify-between text-xs mb-2 opacity-85">
          <div className="flex items-center gap-2 truncate pr-2">
            <Volume2 className={`w-3.5 h-3.5 shrink-0 ${isPlaying ? 'text-amber-500 animate-bounce' : 'opacity-40'}`} />
            <span className="truncate italic">
              {currentSegment ? currentSegment.text : 'กดเล่นเพื่อเริ่มอ่านนิยายเสียง...'}
            </span>
          </div>
          <div className="shrink-0 flex items-center gap-2 text-[11px] font-mono opacity-80">
            <span className="hidden sm:inline-flex items-center gap-1 px-1.5 py-0.5 rounded bg-amber-500/15 text-amber-700 dark:text-amber-300 font-sans text-[10px] font-bold">
              {speechSettings.engine === 'edge-tts' 
                ? (speechSettings.edgeVoice === 'th-TH-NiwatNeural' ? '✨ Edge: Niwat (ชาย)' : '✨ Edge: Premwadee (หญิง)')
                : '🌐 Web Speech'}
            </span>
            <span>{currentIndex + 1}/{Math.max(1, totalSegments)} ประโยค</span>
            <span>({progressPercent}%)</span>
          </div>
        </div>

        {/* Main Controls Grid */}
        <div className="flex items-center justify-between gap-2 sm:gap-4">
          {/* Left Controls: Speed Pill & Restart */}
          <div className="flex items-center gap-1.5 sm:gap-2">
            <button
              id="btn-cycle-speed"
              onClick={cycleRate}
              className={`flex items-center gap-1 px-2.5 py-1.5 rounded-lg border text-xs font-semibold transition-all active:scale-95 ${
                readingSettings.theme === 'sepia'
                  ? 'bg-[#efe5ce] border-[#d8c7a8] hover:bg-[#e6d9bc] text-amber-950'
                  : isDark
                  ? 'bg-neutral-800 border-neutral-700 hover:bg-neutral-700 text-neutral-200'
                  : 'bg-stone-100 border-stone-200 hover:bg-stone-200/70 text-stone-800'
              }`}
              title="เปลี่ยนความเร็วในการอ่านเสียง"
            >
              <Gauge className="w-3.5 h-3.5 text-amber-500" />
              <span>{speechSettings.rate}x</span>
            </button>

            <button
              id="btn-restart-chapter"
              onClick={onRestartChapter}
              className="p-1.5 rounded-lg opacity-70 hover:opacity-100 hover:bg-current/10 transition-colors"
              title="เริ่มอ่านใหม่ตั้งแต่ต้นบท"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
          </div>

          {/* Center Playback Controls */}
          <div className="flex items-center gap-2 sm:gap-3">
            {/* Previous Sentence */}
            <button
              id="btn-prev-sentence"
              onClick={onPrevSegment}
              disabled={currentIndex <= 0}
              className="p-2 rounded-full hover:bg-current/10 active:scale-90 disabled:opacity-30 disabled:cursor-not-allowed transition-all"
              title="ประโยคก่อนหน้า"
            >
              <SkipBack className="w-5 h-5 fill-current/20" />
            </button>

            {/* Play / Pause Primary Button */}
            <button
              id="btn-play-pause-toggle"
              onClick={isPlaying ? onPause : onPlay}
              className="w-12 h-12 sm:w-14 sm:h-14 rounded-full bg-amber-500 hover:bg-amber-600 text-white flex items-center justify-center shadow-lg shadow-amber-500/30 active:scale-95 transition-all"
              title={isPlaying ? "หยุดอ่านชั่วคราว" : "เล่นเสียงอ่าน"}
            >
              {isPlaying ? (
                <Pause className="w-6 h-6 fill-white" />
              ) : (
                <Play className="w-6 h-6 fill-white ml-0.5" />
              )}
            </button>

            {/* Next Sentence */}
            <button
              id="btn-next-sentence"
              onClick={onNextSegment}
              disabled={currentIndex >= totalSegments - 1}
              className="p-2 rounded-full hover:bg-current/10 active:scale-90 disabled:opacity-30 disabled:cursor-not-allowed transition-all"
              title="ประโยคถัดไป"
            >
              <SkipForward className="w-5 h-5 fill-current/20" />
            </button>
          </div>

          {/* Right Controls: Auto-scroll & Settings */}
          <div className="flex items-center gap-1.5 sm:gap-2">
            {/* Auto-scroll indicator & toggle */}
            <button
              id="btn-toggle-autoscroll"
              onClick={onToggleAutoScroll}
              className={`hidden sm:flex items-center gap-1 px-2.5 py-1.5 rounded-lg border text-xs font-medium transition-all ${
                readingSettings.autoScroll
                  ? 'bg-amber-500/15 border-amber-500/30 text-amber-700 dark:text-amber-300'
                  : 'opacity-50 border-transparent hover:bg-current/5'
              }`}
              title="เลื่อนหน้าจอตามตัวอักษรที่กำลังอ่านโดยอัตโนมัติ"
            >
              <span>เลื่อนตาม</span>
            </button>

            {/* Sleep timer status pill if active */}
            {sleepTimerRemaining !== null && (
              <button
                id="btn-mini-sleep-timer"
                onClick={onOpenSleepTimer}
                className="flex items-center gap-1 px-2 py-1 rounded-lg bg-indigo-500/20 text-indigo-700 dark:text-indigo-300 border border-indigo-500/30 text-xs font-mono"
                title="คลิกเพื่อปรับเวลาปิด"
              >
                <Timer className="w-3 h-3 animate-spin" />
                <span>{formatTimer(sleepTimerRemaining)}</span>
              </button>
            )}

            {/* Open Settings Modal */}
            <button
              id="btn-open-settings-bottom"
              onClick={onOpenSettings}
              className="p-2 rounded-lg hover:bg-current/10 transition-colors"
              title="ตั้งค่าเสียงและผู้อ่าน"
            >
              <Sliders className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
