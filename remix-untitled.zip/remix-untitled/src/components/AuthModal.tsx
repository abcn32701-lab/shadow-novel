import React, { useState } from 'react';
import { 
  X, 
  Mail, 
  Lock, 
  User, 
  ShieldCheck, 
  Headphones, 
  LogIn, 
  UserPlus, 
  CheckCircle2, 
  AlertCircle,
  Sparkles,
  ArrowRight
} from 'lucide-react';
import { UserProfile, UserRole } from '../types';
import { loginAccount, registerAccount } from '../utils/authService';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (user: UserProfile) => void;
  initialMode?: 'login' | 'register';
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
  initialMode = 'login'
}) => {
  const [tab, setTab] = useState<'login' | 'register'>(initialMode);

  // Form Fields
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [selectedRole, setSelectedRole] = useState<UserRole>('listener');

  // Status
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  if (!isOpen) return null;

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);
    setIsLoading(true);

    setTimeout(() => {
      const res = loginAccount(email, password);
      setIsLoading(false);

      if (!res.success || !res.user) {
        setErrorMessage(res.error || 'เข้าสู่ระบบไม่สำเร็จ');
      } else {
        setSuccessMessage(`ยินดีต้อนรับคุณ ${res.user.name} เข้าสู่ระบบสำเร็จ!`);
        setTimeout(() => {
          onSuccess(res.user!);
          onClose();
        }, 600);
      }
    }, 200);
  };

  const handleRegisterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    if (password !== confirmPassword) {
      setErrorMessage('รหัสผ่านและยืนยันรหัสผ่านไม่ตรงกัน');
      return;
    }

    setIsLoading(true);

    setTimeout(() => {
      const res = registerAccount(name, email, password, selectedRole);
      setIsLoading(false);

      if (!res.success || !res.user) {
        setErrorMessage(res.error || 'สมัครสมาชิกไม่สำเร็จ');
      } else {
        setSuccessMessage(`สมัครสมาชิกสำเร็จ! ยินดีต้อนรับคุณ ${res.user.name}`);
        setTimeout(() => {
          onSuccess(res.user!);
          onClose();
        }, 700);
      }
    }, 250);
  };

  const handleQuickDemoLogin = (role: 'listener' | 'admin') => {
    setErrorMessage(null);
    if (role === 'listener') {
      setEmail('listener@shadow.novel');
      setPassword('123456');
      const res = loginAccount('listener@shadow.novel', '123456');
      if (res.success && res.user) {
        setSuccessMessage('เข้าสู่ระบบในฐานะคนฟังทดสอบสำเร็จ');
        setTimeout(() => {
          onSuccess(res.user!);
          onClose();
        }, 500);
      }
    } else {
      setEmail('admin@shadow.novel');
      setPassword('admin123');
      const res = loginAccount('admin@shadow.novel', 'admin123');
      if (res.success && res.user) {
        setSuccessMessage('เข้าสู่ระบบในฐานะแอดมินสำเร็จ');
        setTimeout(() => {
          onSuccess(res.user!);
          onClose();
        }, 500);
      }
    }
  };

  return (
    <div
      id="auth-modal-overlay"
      className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-3.5 sm:p-5 animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div
        className="w-full max-w-md rounded-3xl border border-stone-200 dark:border-neutral-800 bg-white dark:bg-neutral-900 text-stone-900 dark:text-neutral-100 shadow-2xl overflow-hidden flex flex-col transition-all"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header with Title and Close Button */}
        <div className="p-4 sm:p-5 border-b border-stone-200 dark:border-neutral-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-amber-500 to-amber-600 text-white flex items-center justify-center shadow-xs">
              <User className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-extrabold text-base sm:text-lg leading-tight">
                {tab === 'login' ? 'เข้าสู่ระบบ Shadow Novel' : 'สมัครสมาชิกใหม่'}
              </h3>
              <p className="text-xs text-stone-500 dark:text-neutral-400">
                {tab === 'login' ? 'กรอกอีเมลและรหัสผ่านเพื่อเข้าใช้งาน' : 'สร้างบัญชีเพื่อบันทึกนิยายโปรดและประวัติการฟัง'}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-stone-100 dark:hover:bg-neutral-800 text-stone-500 hover:text-stone-800 dark:hover:text-neutral-200 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Switcher: Login vs Register */}
        <div className="grid grid-cols-2 p-1.5 m-3.5 sm:m-4 rounded-2xl bg-stone-100 dark:bg-neutral-800 text-xs font-bold">
          <button
            type="button"
            onClick={() => {
              setTab('login');
              setErrorMessage(null);
            }}
            className={`py-2 rounded-xl flex items-center justify-center gap-1.5 transition-all ${
              tab === 'login'
                ? 'bg-white dark:bg-neutral-900 text-amber-600 dark:text-amber-400 shadow-xs'
                : 'text-stone-600 dark:text-neutral-400 hover:text-stone-900 dark:hover:text-neutral-200'
            }`}
          >
            <LogIn className="w-3.5 h-3.5" />
            <span>เข้าสู่ระบบ (Login)</span>
          </button>

          <button
            type="button"
            onClick={() => {
              setTab('register');
              setErrorMessage(null);
            }}
            className={`py-2 rounded-xl flex items-center justify-center gap-1.5 transition-all ${
              tab === 'register'
                ? 'bg-white dark:bg-neutral-900 text-amber-600 dark:text-amber-400 shadow-xs'
                : 'text-stone-600 dark:text-neutral-400 hover:text-stone-900 dark:hover:text-neutral-200'
            }`}
          >
            <UserPlus className="w-3.5 h-3.5" />
            <span>สมัครสมาชิก (Sign Up)</span>
          </button>
        </div>

        {/* Alerts */}
        {errorMessage && (
          <div className="mx-4 mb-2 p-3 rounded-xl bg-red-500/10 border border-red-500/30 text-red-600 dark:text-red-400 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{errorMessage}</span>
          </div>
        )}

        {successMessage && (
          <div className="mx-4 mb-2 p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-600 dark:text-emerald-400 text-xs flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 shrink-0" />
            <span>{successMessage}</span>
          </div>
        )}

        {/* Modal Body: Forms */}
        <div className="px-4 pb-4 sm:px-6 sm:pb-6 overflow-y-auto max-h-[65vh]">
          {tab === 'login' ? (
            /* =========================================================================
               LOGIN FORM
               ========================================================================= */
            <form onSubmit={handleLoginSubmit} className="space-y-3.5">
              {/* Email */}
              <div>
                <label className="block text-xs font-bold text-stone-700 dark:text-neutral-300 mb-1">
                  อีเมลของคุณ (Email)
                </label>
                <div className="relative">
                  <Mail className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-stone-400" />
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="เช่น yourname@gmail.com"
                    className="w-full pl-10 pr-3.5 py-2.5 rounded-xl border border-stone-300 dark:border-neutral-700 bg-stone-50 dark:bg-neutral-800 text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-amber-500"
                  />
                </div>
              </div>

              {/* Password */}
              <div>
                <label className="block text-xs font-bold text-stone-700 dark:text-neutral-300 mb-1">
                  รหัสผ่าน (Password)
                </label>
                <div className="relative">
                  <Lock className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-stone-400" />
                  <input
                    type="password"
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="กรอกรหัสผ่านของคุณ"
                    className="w-full pl-10 pr-3.5 py-2.5 rounded-xl border border-stone-300 dark:border-neutral-700 bg-stone-50 dark:bg-neutral-800 text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-amber-500"
                  />
                </div>
              </div>

              {/* Submit Button */}
              <button
                type="submit"
                disabled={isLoading}
                className="w-full py-2.5 px-4 rounded-xl bg-amber-500 hover:bg-amber-600 disabled:opacity-50 text-white font-extrabold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-md active:scale-98 transition-all"
              >
                <LogIn className="w-4 h-4" />
                <span>{isLoading ? 'กำลังเข้าสู่ระบบ...' : 'เข้าสู่ระบบ'}</span>
              </button>

              {/* Quick Demo Login Shortcut */}
              <div className="pt-3 border-t border-stone-200 dark:border-neutral-800 space-y-2">
                <span className="text-[11px] font-bold text-stone-500 dark:text-neutral-400 block text-center">
                  หรือคลิกเข้าสู่ระบบด่วนเพื่อทดสอบระบบได้ทันที:
                </span>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => handleQuickDemoLogin('listener')}
                    className="p-2 rounded-xl border border-indigo-500/30 bg-indigo-500/10 hover:bg-indigo-500/20 text-indigo-700 dark:text-indigo-300 font-bold text-xs flex items-center justify-center gap-1.5 transition-colors"
                  >
                    <Headphones className="w-3.5 h-3.5" />
                    <span>เข้าแบบคนฟัง</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleQuickDemoLogin('admin')}
                    className="p-2 rounded-xl border border-amber-500/30 bg-amber-500/10 hover:bg-amber-500/20 text-amber-700 dark:text-amber-300 font-bold text-xs flex items-center justify-center gap-1.5 transition-colors"
                  >
                    <ShieldCheck className="w-3.5 h-3.5" />
                    <span>เข้าแบบแอดมิน</span>
                  </button>
                </div>
              </div>
            </form>
          ) : (
            /* =========================================================================
               REGISTER FORM
               ========================================================================= */
            <form onSubmit={handleRegisterSubmit} className="space-y-3.5">
              {/* Name */}
              <div>
                <label className="block text-xs font-bold text-stone-700 dark:text-neutral-300 mb-1">
                  ชื่อของคุณ หรือนามปากกา (Display Name)
                </label>
                <div className="relative">
                  <User className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-stone-400" />
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="เช่น คุณสมชาย, นักอ่านเงา"
                    className="w-full pl-10 pr-3.5 py-2.5 rounded-xl border border-stone-300 dark:border-neutral-700 bg-stone-50 dark:bg-neutral-800 text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-amber-500"
                  />
                </div>
              </div>

              {/* Email */}
              <div>
                <label className="block text-xs font-bold text-stone-700 dark:text-neutral-300 mb-1">
                  อีเมล (Email)
                </label>
                <div className="relative">
                  <Mail className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-stone-400" />
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="เช่น user@example.com"
                    className="w-full pl-10 pr-3.5 py-2.5 rounded-xl border border-stone-300 dark:border-neutral-700 bg-stone-50 dark:bg-neutral-800 text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-amber-500"
                  />
                </div>
              </div>

              {/* Password */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-stone-700 dark:text-neutral-300 mb-1">
                    รหัสผ่าน (Password)
                  </label>
                  <div className="relative">
                    <Lock className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-stone-400" />
                    <input
                      type="password"
                      required
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="ขั้นต่ำ 4 ตัวอักษร"
                      className="w-full pl-10 pr-3.5 py-2.5 rounded-xl border border-stone-300 dark:border-neutral-700 bg-stone-50 dark:bg-neutral-800 text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-amber-500"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-stone-700 dark:text-neutral-300 mb-1">
                    ยืนยันรหัสผ่าน
                  </label>
                  <div className="relative">
                    <Lock className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-stone-400" />
                    <input
                      type="password"
                      required
                      value={confirmPassword}
                      onChange={(e) => setConfirmPassword(e.target.value)}
                      placeholder="พิมพ์ซ้ำอีกครั้ง"
                      className="w-full pl-10 pr-3.5 py-2.5 rounded-xl border border-stone-300 dark:border-neutral-700 bg-stone-50 dark:bg-neutral-800 text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-amber-500"
                    />
                  </div>
                </div>
              </div>

              {/* Account Role Choice */}
              <div>
                <label className="block text-xs font-bold text-stone-700 dark:text-neutral-300 mb-1.5">
                  เลือกประเภทบัญชีของคุณ:
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setSelectedRole('listener')}
                    className={`p-2.5 rounded-xl border text-left transition-all ${
                      selectedRole === 'listener'
                        ? 'border-indigo-500 bg-indigo-500/15 text-indigo-900 dark:text-indigo-200 ring-2 ring-indigo-500/50'
                        : 'border-stone-200 dark:border-neutral-700 hover:bg-stone-50 dark:hover:bg-neutral-800 text-stone-600 dark:text-neutral-400'
                    }`}
                  >
                    <div className="flex items-center gap-1.5 font-bold text-xs mb-0.5">
                      <Headphones className="w-3.5 h-3.5 text-indigo-500" />
                      <span>คนฟัง / คนดู</span>
                    </div>
                    <p className="text-[10px] opacity-75">หน้าเว็บสะอาดตา บันทึกรายการโปรด</p>
                  </button>

                  <button
                    type="button"
                    onClick={() => setSelectedRole('admin')}
                    className={`p-2.5 rounded-xl border text-left transition-all ${
                      selectedRole === 'admin'
                        ? 'border-amber-500 bg-amber-500/15 text-amber-900 dark:text-amber-200 ring-2 ring-amber-500/50'
                        : 'border-stone-200 dark:border-neutral-700 hover:bg-stone-50 dark:hover:bg-neutral-800 text-stone-600 dark:text-neutral-400'
                    }`}
                  >
                    <div className="flex items-center gap-1.5 font-bold text-xs mb-0.5">
                      <ShieldCheck className="w-3.5 h-3.5 text-amber-500" />
                      <span>แอดมิน (Admin)</span>
                    </div>
                    <p className="text-[10px] opacity-75">สร้าง/แก้ไข/อัปโหลดรูปนิยาย</p>
                  </button>
                </div>
              </div>

              {/* Submit Button */}
              <button
                type="submit"
                disabled={isLoading}
                className="w-full py-2.5 px-4 rounded-xl bg-amber-500 hover:bg-amber-600 disabled:opacity-50 text-white font-extrabold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-md active:scale-98 transition-all"
              >
                <UserPlus className="w-4 h-4" />
                <span>{isLoading ? 'กำลังสร้างบัญชี...' : 'สมัครสมาชิกฟรี'}</span>
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
