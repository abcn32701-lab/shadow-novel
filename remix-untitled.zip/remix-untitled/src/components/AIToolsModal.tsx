import React, { useState } from 'react';
import { 
  X, 
  Sparkles, 
  BookOpen, 
  FileText, 
  Send, 
  Plus, 
  Copy, 
  Check, 
  Loader2,
  Users,
  Mic
} from 'lucide-react';
import { Chapter, Novel } from '../types';

interface AIToolsModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentNovel: Novel;
  currentChapter: Chapter;
  onAppendContent: (textToAppend: string) => void;
}

export const AIToolsModal: React.FC<AIToolsModalProps> = ({
  isOpen,
  onClose,
  currentNovel,
  currentChapter,
  onAppendContent,
}) => {
  const [activeTab, setActiveTab] = useState<'summarize' | 'continue' | 'characters'>('summarize');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  // Results
  const [summaryResult, setSummaryResult] = useState<string>('');
  const [continueResult, setContinueResult] = useState<string>('');
  const [characterResult, setCharacterResult] = useState<string>('');

  // Continuation prompt instruction
  const [continueInstruction, setContinueInstruction] = useState<string>('');

  if (!isOpen) return null;

  // Summarize
  const handleSummarize = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch('/api/ai/summarize', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: currentChapter.title,
          text: currentChapter.content,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'การสรุปเนื้อหาล้มเหลว');
      setSummaryResult(data.summary);
    } catch (err: any) {
      setError(err.message || 'เกิดข้อผิดพลาดในการเชื่อมต่อ AI');
    } finally {
      setLoading(false);
    }
  };

  // Continue story
  const handleContinue = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch('/api/ai/continue', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: currentNovel.title,
          contextText: currentChapter.content,
          instruction: continueInstruction,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'การสร้างเนื้อเรื่องต่อล้มเหลว');
      setContinueResult(data.continuation);
    } catch (err: any) {
      setError(err.message || 'เกิดข้อผิดพลาดในการเชื่อมต่อ AI');
    } finally {
      setLoading(false);
    }
  };

  // Analyze characters
  const handleAnalyzeCharacters = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch('/api/ai/analyze-characters', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: currentChapter.title,
          text: currentChapter.content,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'การวิเคราะห์ตัวละครล้มเหลว');
      setCharacterResult(data.analysis);
    } catch (err: any) {
      setError(err.message || 'เกิดข้อผิดพลาดในการเชื่อมต่อ AI');
    } finally {
      setLoading(false);
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div 
      id="modal-ai-tools-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fade-in"
    >
      <div 
        id="modal-ai-tools-panel"
        className="bg-white dark:bg-neutral-900 text-stone-900 dark:text-neutral-100 w-full max-w-2xl max-h-[85vh] rounded-2xl shadow-2xl border border-stone-200 dark:border-neutral-800 flex flex-col overflow-hidden"
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-stone-200 dark:border-neutral-800">
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-purple-500" />
            <h2 className="text-base font-bold">ผู้ช่วยวิเคราะห์และต่อเติมนิยาย (Gemini AI)</h2>
          </div>
          <button
            id="btn-close-ai-modal"
            onClick={onClose}
            className="p-1.5 rounded-lg hover:bg-stone-100 dark:hover:bg-neutral-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab switcher */}
        <div className="flex border-b border-stone-200 dark:border-neutral-800 text-xs font-semibold px-4">
          <button
            onClick={() => setActiveTab('summarize')}
            className={`py-3 px-3 border-b-2 flex items-center gap-1.5 transition-all ${
              activeTab === 'summarize'
                ? 'border-purple-500 text-purple-600 dark:text-purple-400'
                : 'border-transparent opacity-60 hover:opacity-100'
            }`}
          >
            <FileText className="w-4 h-4" />
            <span>สรุปเนื้อหาบทนี้</span>
          </button>
          <button
            onClick={() => setActiveTab('continue')}
            className={`py-3 px-3 border-b-2 flex items-center gap-1.5 transition-all ${
              activeTab === 'continue'
                ? 'border-purple-500 text-purple-600 dark:text-purple-400'
                : 'border-transparent opacity-60 hover:opacity-100'
            }`}
          >
            <Sparkles className="w-4 h-4" />
            <span>แต่งเนื้อเรื่องตอนต่อไป</span>
          </button>
          <button
            onClick={() => setActiveTab('characters')}
            className={`py-3 px-3 border-b-2 flex items-center gap-1.5 transition-all ${
              activeTab === 'characters'
                ? 'border-purple-500 text-purple-600 dark:text-purple-400'
                : 'border-transparent opacity-60 hover:opacity-100'
            }`}
          >
            <Users className="w-4 h-4" />
            <span>วิเคราะห์ตัวละครและเสียงพากย์</span>
          </button>
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-4 custom-scrollbar">
          {error && (
            <div className="p-3 rounded-xl bg-red-500/10 border border-red-500/30 text-red-600 dark:text-red-400 text-xs">
              {error}
            </div>
          )}

          {/* TAB 1: SUMMARIZE */}
          {activeTab === 'summarize' && (
            <div className="space-y-4">
              <div className="p-3 rounded-xl bg-purple-500/5 border border-purple-500/20 text-xs">
                <span className="font-semibold block mb-1">นิยายเรื่อง: {currentNovel.title}</span>
                <span className="opacity-70">กำลังวิเคราะห์: {currentChapter.title}</span>
              </div>

              {!summaryResult && !loading && (
                <div className="text-center py-6">
                  <p className="text-xs opacity-70 mb-4">
                    กดปุ่มเพื่อใช้ AI วิเคราะห์และสรุปประเด็นสำคัญของบทนี้ใน 3-5 บรรทัด
                  </p>
                  <button
                    id="btn-run-summarize"
                    onClick={handleSummarize}
                    className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-700 text-white text-xs font-semibold shadow-md active:scale-95 transition-all"
                  >
                    <Sparkles className="w-4 h-4" />
                    <span>เริ่มสรุปเนื้อหา</span>
                  </button>
                </div>
              )}

              {loading && (
                <div className="text-center py-10">
                  <Loader2 className="w-7 h-7 animate-spin mx-auto text-purple-600 mb-2" />
                  <p className="text-xs opacity-70">Gemini กำลังอ่านและสรุปเนื้อหาบทนี้...</p>
                </div>
              )}

              {summaryResult && (
                <div className="space-y-3">
                  <div className="p-4 rounded-xl bg-stone-50 dark:bg-neutral-800 border border-stone-200 dark:border-neutral-700 text-sm leading-relaxed whitespace-pre-line font-sarabun">
                    {summaryResult}
                  </div>
                  <div className="flex justify-between items-center text-xs">
                    <button
                      onClick={handleSummarize}
                      className="text-purple-600 dark:text-purple-400 hover:underline"
                    >
                      🔄 สรุปใหม่อีกครั้ง
                    </button>
                    <button
                      onClick={() => copyToClipboard(summaryResult)}
                      className="flex items-center gap-1 px-3 py-1.5 rounded-lg border border-stone-200 dark:border-neutral-700 hover:bg-stone-100"
                    >
                      {copied ? <Check className="w-3.5 h-3.5 text-green-500" /> : <Copy className="w-3.5 h-3.5" />}
                      <span>{copied ? 'คัดลอกแล้ว' : 'คัดลอกสรุป'}</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* TAB 2: CONTINUE STORY */}
          {activeTab === 'continue' && (
            <div className="space-y-4">
              <div>
                <label className="block text-xs font-semibold mb-1">
                  คำสั่งพิเศษสำหรับฉากต่อไป (ไม่บังคับ)
                </label>
                <input
                  type="text"
                  value={continueInstruction}
                  onChange={(e) => setContinueInstruction(e.target.value)}
                  placeholder="เช่น ให้มีตัวละครลึกลับโผล่มาช่วย, ฉากเผชิญหน้าดุเดือด, อารมณ์หวานซึ้ง..."
                  className="w-full px-3 py-2 text-xs rounded-xl bg-stone-100 dark:bg-neutral-800 border border-stone-200 dark:border-neutral-700 focus:ring-2 focus:ring-purple-500 outline-none"
                />
              </div>

              <div className="flex justify-center">
                <button
                  id="btn-run-continue"
                  onClick={handleContinue}
                  disabled={loading}
                  className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-700 text-white text-xs font-semibold shadow-md active:scale-95 disabled:opacity-50 transition-all"
                >
                  {loading ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      <span>กำลังเรียบเรียงฉากต่อไป...</span>
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-4 h-4" />
                      <span>แต่งเนื้อเรื่องฉากถัดไป</span>
                    </>
                  )}
                </button>
              </div>

              {continueResult && (
                <div className="space-y-3 pt-2">
                  <div className="p-4 rounded-xl bg-stone-50 dark:bg-neutral-800 border border-stone-200 dark:border-neutral-700 text-sm leading-relaxed whitespace-pre-line font-sarabun">
                    {continueResult}
                  </div>
                  <div className="flex items-center justify-between gap-2">
                    <button
                      onClick={() => {
                        onAppendContent('\n\n' + continueResult);
                        onClose();
                      }}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-medium shadow-xs"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>เพิ่มต่อท้ายบทนี้ทันที</span>
                    </button>

                    <button
                      onClick={() => copyToClipboard(continueResult)}
                      className="flex items-center gap-1 px-3 py-1.5 rounded-lg border border-stone-200 dark:border-neutral-700 hover:bg-stone-100 text-xs"
                    >
                      {copied ? <Check className="w-3.5 h-3.5 text-green-500" /> : <Copy className="w-3.5 h-3.5" />}
                      <span>{copied ? 'คัดลอกแล้ว' : 'คัดลอกเนื้อหา'}</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* TAB 3: CHARACTERS & VOICE ACTING */}
          {activeTab === 'characters' && (
            <div className="space-y-4">
              {!characterResult && !loading && (
                <div className="text-center py-6">
                  <p className="text-xs opacity-70 mb-4">
                    วิเคราะห์บทบาทตัวละครในบทนี้ พร้อมคำแนะนำการใช้น้ำเสียง (Voice Acting) สำหรับนิยายเสียง
                  </p>
                  <button
                    id="btn-run-characters"
                    onClick={handleAnalyzeCharacters}
                    className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-700 text-white text-xs font-semibold shadow-md active:scale-95 transition-all"
                  >
                    <Mic className="w-4 h-4" />
                    <span>วิเคราะห์ตัวละครและเสียงพากย์</span>
                  </button>
                </div>
              )}

              {loading && (
                <div className="text-center py-10">
                  <Loader2 className="w-7 h-7 animate-spin mx-auto text-purple-600 mb-2" />
                  <p className="text-xs opacity-70">กำลังวิเคราะห์ตัวละครและโทนเสียง...</p>
                </div>
              )}

              {characterResult && (
                <div className="space-y-3">
                  <div className="p-4 rounded-xl bg-stone-50 dark:bg-neutral-800 border border-stone-200 dark:border-neutral-700 text-sm leading-relaxed whitespace-pre-line font-sarabun">
                    {characterResult}
                  </div>
                  <div className="flex justify-end">
                    <button
                      onClick={() => copyToClipboard(characterResult)}
                      className="flex items-center gap-1 px-3 py-1.5 rounded-lg border border-stone-200 dark:border-neutral-700 hover:bg-stone-100 text-xs"
                    >
                      {copied ? <Check className="w-3.5 h-3.5 text-green-500" /> : <Copy className="w-3.5 h-3.5" />}
                      <span>{copied ? 'คัดลอกแล้ว' : 'คัดลอกคำแนะนำ'}</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-stone-200 dark:border-neutral-800 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs rounded-xl border border-stone-200 dark:border-neutral-700 hover:bg-stone-100 dark:hover:bg-neutral-800"
          >
            ปิด
          </button>
        </div>
      </div>
    </div>
  );
};
