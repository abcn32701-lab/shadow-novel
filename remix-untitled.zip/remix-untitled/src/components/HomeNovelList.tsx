import React, { useState, useRef, useMemo } from 'react';
import { 
  BookOpen, 
  Plus, 
  Play, 
  Pause, 
  Layers, 
  Search, 
  Camera, 
  Trash2, 
  Edit3, 
  Volume2, 
  Bookmark, 
  Upload, 
  BookMarked, 
  ShieldCheck, 
  Headphones, 
  Check, 
  Sparkles, 
  Flame, 
  Clock, 
  Grid, 
  List as ListIcon, 
  ChevronRight, 
  X, 
  Eye, 
  SlidersHorizontal, 
  Compass,
  Heart,
  Globe,
  Share2
} from 'lucide-react';
import { Novel, Chapter, ReadingSettings, UserRole, UserProfile } from '../types';
import { compressCoverImage } from '../utils/imageHelper';

interface HomeNovelListProps {
  novels: Novel[];
  activeNovelId: string;
  activeChapterId: string;
  readingSettings: ReadingSettings;
  isPlaying: boolean;
  userRole: UserRole;
  onToggleUserRole: () => void;
  onSelectNovelAndChapter: (novelId: string, chapterId: string, autoPlay?: boolean) => void;
  onOpenCreateNovelModal: () => void;
  onOpenAddChapterModal: (novelId: string) => void;
  onUpdateNovelCover: (novelId: string, coverImage: string | undefined) => void;
  onEditNovelTitle: (novelId: string, newTitle: string) => void;
  onDeleteNovel: (novelId: string) => void;
  currentUser?: UserProfile | null;
  onOpenAuthModal?: () => void;
  onOpenShareModal?: () => void;
  onToggleFavorite?: (novelId: string) => void;
}

type SortOption = 'latest' | 'chapters' | 'title';

export const HomeNovelList: React.FC<HomeNovelListProps> = ({
  novels,
  activeNovelId,
  activeChapterId,
  readingSettings,
  isPlaying,
  userRole,
  onToggleUserRole,
  onSelectNovelAndChapter,
  onOpenCreateNovelModal,
  onOpenAddChapterModal,
  onUpdateNovelCover,
  onEditNovelTitle,
  onDeleteNovel,
  currentUser,
  onOpenAuthModal,
  onOpenShareModal,
  onToggleFavorite,
}) => {
  // Search and filter state
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('ทั้งหมด');
  const [sortBy, setSortBy] = useState<SortOption>('chapters');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');

  // Modal for Viewer: Full Novel Synopsis & Chapter Catalog
  const [inspectingNovel, setInspectingNovel] = useState<Novel | null>(null);
  const [inspectingChapterSearch, setInspectingChapterSearch] = useState('');

  // Admin edit state
  const [editingNovelId, setEditingNovelId] = useState<string | null>(null);
  const [editTitleText, setEditTitleText] = useState('');
  const [uploadingNovelId, setUploadingNovelId] = useState<string | null>(null);

  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const activeUploadNovelIdRef = useRef<string | null>(null);

  const isDark = readingSettings.theme === 'night' || readingSettings.theme === 'oled';
  const isSepia = readingSettings.theme === 'sepia';

  // Extract all categories
  const categories = useMemo(() => {
    const set = new Set<string>();
    set.add('ทั้งหมด');
    novels.forEach(n => {
      if (n.category) set.add(n.category);
    });
    return Array.from(set);
  }, [novels]);

  // Featured novel (e.g. active or first with most chapters)
  const featuredNovel = useMemo(() => {
    if (!novels.length) return null;
    const sorted = [...novels].sort((a, b) => b.chapters.length - a.chapters.length);
    return sorted[0];
  }, [novels]);

  // Currently reading novel and chapter
  const currentReadingNovel = novels.find(n => n.id === activeNovelId);
  const currentReadingChapter = currentReadingNovel?.chapters.find(c => c.id === activeChapterId);

  // Filtered and sorted novels
  const filteredNovels = useMemo(() => {
    let list = novels.filter((n) => {
      const matchSearch = 
        n.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        n.author.toLowerCase().includes(searchQuery.toLowerCase()) ||
        n.category.toLowerCase().includes(searchQuery.toLowerCase());
      
      const matchCategory = selectedCategory === 'ทั้งหมด' || n.category === selectedCategory;
      return matchSearch && matchCategory;
    });

    if (sortBy === 'chapters') {
      list.sort((a, b) => b.chapters.length - a.chapters.length);
    } else if (sortBy === 'latest') {
      list.sort((a, b) => (b.updatedAt || 0) - (a.updatedAt || 0));
    } else if (sortBy === 'title') {
      list.sort((a, b) => a.title.localeCompare(b.title, 'th'));
    }

    return list;
  }, [novels, searchQuery, selectedCategory, sortBy]);

  // Total chapters count
  const totalChaptersCount = novels.reduce((acc, n) => acc + n.chapters.length, 0);

  const triggerUploadCover = (novelId: string) => {
    activeUploadNovelIdRef.current = novelId;
    fileInputRef.current?.click();
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    const targetNovelId = activeUploadNovelIdRef.current;
    if (!file || !targetNovelId) return;

    try {
      setUploadingNovelId(targetNovelId);
      const dataUrl = await compressCoverImage(file, 600, 0.84);
      onUpdateNovelCover(targetNovelId, dataUrl);
    } catch (err: any) {
      alert(err?.message || 'ไม่สามารถโหลดรูปภาพได้');
    } finally {
      setUploadingNovelId(null);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  const handleStartEditTitle = (novel: Novel) => {
    if (userRole !== 'admin') return;
    setEditingNovelId(novel.id);
    setEditTitleText(novel.title);
  };

  const handleSaveTitle = (novelId: string) => {
    if (editTitleText.trim()) {
      onEditNovelTitle(novelId, editTitleText.trim());
    }
    setEditingNovelId(null);
  };

  return (
    <main
      id="home-novel-list-view"
      className="min-h-screen px-3 sm:px-6 md:px-8 pt-4 sm:pt-6 pb-28 sm:pb-36 transition-colors duration-200"
    >
      {/* Hidden file input for uploading novel covers (Admin only) */}
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        onChange={handleFileChange}
        className="hidden"
      />

      <div className="max-w-6xl mx-auto space-y-6">
        {/* =========================================================================
            ROLE BANNER & SWITCHER BAR
            ========================================================================= */}
        <section
          id="role-switch-banner"
          className={`p-3.5 sm:p-4 rounded-2xl border transition-all flex flex-col sm:flex-row items-center justify-between gap-3 shadow-xs ${
            userRole === 'admin'
              ? 'bg-amber-500/10 border-amber-500/30 text-amber-950 dark:text-amber-100'
              : 'bg-indigo-500/10 border-indigo-500/25 text-indigo-950 dark:text-indigo-100'
          }`}
        >
          <div className="flex items-center gap-3 text-center sm:text-left">
            <div className={`p-2.5 rounded-xl shadow-xs shrink-0 ${
              userRole === 'admin' 
                ? 'bg-amber-500 text-white' 
                : 'bg-indigo-600 text-white'
            }`}>
              {userRole === 'admin' ? <ShieldCheck className="w-5 h-5" /> : <Headphones className="w-5 h-5" />}
            </div>
            <div>
              <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2">
                <span className="text-sm sm:text-base font-extrabold tracking-tight">
                  {userRole === 'admin' 
                    ? '👑 โหมดแอดมิน (Admin Control Panel)' 
                    : '🎧 เว็บพอร์ทัลนิยายและนิยายเสียง (Shadow Novel Portal)'}
                </span>
                <span className="text-[11px] font-bold px-2 py-0.5 rounded-full bg-black/10 dark:bg-white/10">
                  {userRole === 'admin' ? 'สำหรับผู้จัดการเว็บ' : 'สำหรับคนดู / คนฟังทั่วไป'}
                </span>
              </div>
              <p className="text-xs opacity-75 mt-0.5">
                {userRole === 'admin'
                  ? 'คุณมีสิทธิ์เต็ม: สร้างนิยายใหม่, อัปโหลดรูปปก, เพิ่มบท, แก้ไขชื่อ และลบเนื้อหา'
                  : 'หน้าเว็บสะอาดตา 100% สำหรับผู้ฟัง: ไม่มีปุ่มลบหรือกรอบอัปโหลดรูป ให้เลือกฟังหรืออ่านได้ทันที'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            {/* Share Listener Link Button */}
            <button
              id="btn-banner-share-link"
              onClick={onOpenShareModal}
              className="px-3 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs sm:text-sm flex items-center gap-1.5 shadow-2xs active:scale-95 transition-all"
              title="ดูและคัดลอกลิงก์หน้าเว็บคนดูเต็มจอ หรือเปิดแท็บใหม่"
            >
              <Globe className="w-4 h-4" />
              <span className="hidden xs:inline">ลิงก์เว็บคนดู</span>
            </button>

            {userRole === 'admin' && (
              <button
                id="btn-banner-create-novel"
                onClick={onOpenCreateNovelModal}
                className="px-3.5 py-2 rounded-xl bg-amber-500 hover:bg-amber-600 text-white font-bold text-xs sm:text-sm flex items-center gap-1.5 shadow-xs active:scale-95 transition-all"
              >
                <Plus className="w-4 h-4" />
                <span>+ สร้างเรื่องใหม่</span>
              </button>
            )}

            <button
              id="btn-banner-toggle-role"
              onClick={onToggleUserRole}
              className={`px-3.5 py-2 rounded-xl text-xs sm:text-sm font-bold border transition-all flex items-center gap-1.5 shadow-2xs ${
                userRole === 'admin'
                  ? 'bg-indigo-600 hover:bg-indigo-700 text-white border-transparent'
                  : 'bg-amber-500 hover:bg-amber-600 text-white border-transparent'
              }`}
              title="คลิกเพื่อสลับมุมมองระหว่างแอดมิน และคนดู"
            >
              {userRole === 'admin' ? (
                <>
                  <Eye className="w-4 h-4" />
                  <span>ดูหน้าเว็บแบบคนฟัง</span>
                </>
              ) : (
                <>
                  <ShieldCheck className="w-4 h-4" />
                  <span>สลับเข้าโหมดแอดมิน</span>
                </>
              )}
            </button>
          </div>
        </section>

        {/* =========================================================================
            FOR VIEWER: CONTINUE LISTENING WIDGET (IF CURRENT NOVEL EXISTS)
            ========================================================================= */}
        {currentReadingNovel && (
          <section
            id="continue-listening-card"
            className={`p-3.5 sm:p-4 rounded-2xl border transition-all flex flex-col sm:flex-row items-center justify-between gap-3 shadow-xs ${
              isDark 
                ? 'bg-neutral-900 border-neutral-800' 
                : isSepia 
                ? 'bg-[#f4ecd8] border-[#dfcfb0]' 
                : 'bg-gradient-to-r from-amber-50 to-orange-50 border-amber-200/80'
            }`}
          >
            <div className="flex items-center gap-3 min-w-0 w-full sm:w-auto">
              {/* Cover thumb */}
              <div className="w-12 h-16 rounded-lg overflow-hidden shrink-0 border border-stone-300 dark:border-neutral-700 bg-stone-200 dark:bg-neutral-800 shadow-2xs">
                {currentReadingNovel.coverImage ? (
                  <img src={currentReadingNovel.coverImage} alt={currentReadingNovel.title} className="w-full h-full object-cover" />
                ) : (
                  <div className="w-full h-full flex items-center justify-center bg-amber-500/20 text-amber-700 dark:text-amber-300">
                    <BookOpen className="w-5 h-5" />
                  </div>
                )}
              </div>

              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2">
                  <span className="text-[10px] sm:text-xs font-bold px-2 py-0.5 rounded-md bg-amber-500 text-white flex items-center gap-1">
                    <Volume2 className="w-3 h-3 animate-pulse" />
                    <span>ฟังล่าสุดค้างไว้</span>
                  </span>
                  <span className="text-xs opacity-60 truncate">
                    {currentReadingNovel.author}
                  </span>
                </div>
                <h4 className="font-bold text-sm sm:text-base truncate mt-0.5">
                  {currentReadingNovel.title}
                </h4>
                <p className="text-xs opacity-75 truncate">
                  ตอนปัจจุบัน: <span className="font-semibold">{currentReadingChapter?.title || 'บทที่ 1'}</span>
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2 shrink-0 w-full sm:w-auto justify-end">
              <button
                onClick={() => onSelectNovelAndChapter(currentReadingNovel.id, activeChapterId, true)}
                className="flex-1 sm:flex-initial px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-600 text-white font-bold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-xs active:scale-95 transition-all"
              >
                {isPlaying ? <Volume2 className="w-4 h-4 animate-bounce" /> : <Play className="w-4 h-4 fill-current" />}
                <span>{isPlaying ? 'กำลังเล่นเสียง' : 'ฟังต่อจากที่ค้างไว้'}</span>
              </button>

              <button
                onClick={() => onSelectNovelAndChapter(currentReadingNovel.id, activeChapterId, false)}
                className="px-3 py-2 rounded-xl border border-current/20 hover:bg-black/5 dark:hover:bg-white/5 font-semibold text-xs transition-colors"
                title="เปิดหน้าอ่านนิยาย"
              >
                <BookOpen className="w-4 h-4" />
              </button>
            </div>
          </section>
        )}

        {/* =========================================================================
            FEATURED HERO SHOWCASE (RECOMMENDED NOVEL FOR LISTENERS)
            ========================================================================= */}
        {featuredNovel && userRole === 'listener' && !searchQuery && selectedCategory === 'ทั้งหมด' && (
          <section
            id="featured-hero-novel"
            className={`p-4 sm:p-6 rounded-3xl border relative overflow-hidden transition-all shadow-md ${
              isDark
                ? 'bg-gradient-to-br from-neutral-900 via-neutral-900 to-neutral-950 border-neutral-800'
                : isSepia
                ? 'bg-gradient-to-br from-[#f6efe1] to-[#ede2cd] border-[#d8c7a6] text-[#3d2e24]'
                : 'bg-gradient-to-br from-amber-500/10 via-amber-100/40 to-stone-50 border-amber-200/90 text-stone-900'
            }`}
          >
            <div className="flex flex-col md:flex-row items-center md:items-start gap-5 sm:gap-7">
              {/* Cover with 3D-effect shadow */}
              <div 
                onClick={() => setInspectingNovel(featuredNovel)}
                className="relative group cursor-pointer shrink-0"
              >
                <div className="w-36 h-52 sm:w-44 sm:h-64 rounded-2xl overflow-hidden border border-amber-500/30 shadow-xl group-hover:scale-105 transition-transform duration-300 bg-stone-200 dark:bg-neutral-800">
                  {featuredNovel.coverImage ? (
                    <img src={featuredNovel.coverImage} alt={featuredNovel.title} className="w-full h-full object-cover" />
                  ) : (
                    <div className="w-full h-full flex flex-col items-center justify-center p-4 text-center bg-gradient-to-b from-amber-500 to-amber-600 text-white">
                      <BookOpen className="w-10 h-10 mb-2" />
                      <span className="font-extrabold text-sm line-clamp-3">{featuredNovel.title}</span>
                    </div>
                  )}
                </div>
                <div className="absolute top-2 left-2 px-2.5 py-1 rounded-full bg-amber-500 text-white text-[10px] font-extrabold shadow-md flex items-center gap-1">
                  <Flame className="w-3 h-3 fill-current" />
                  <span>เรื่องเด่นประจำสัปดาห์</span>
                </div>
              </div>

              {/* Info & Action Buttons */}
              <div className="flex-1 text-center md:text-left">
                <div className="flex flex-wrap items-center justify-center md:justify-start gap-2 mb-2">
                  <span className="text-xs font-bold px-2.5 py-0.5 rounded-full bg-amber-500/20 text-amber-700 dark:text-amber-300">
                    {featuredNovel.category || 'นิยายแปล'}
                  </span>
                  <span className="text-xs font-semibold opacity-70">
                    ผู้แต่ง: {featuredNovel.author}
                  </span>
                  <span className="opacity-40">•</span>
                  <span className="text-xs font-bold text-amber-600 dark:text-amber-400">
                    {featuredNovel.chapters.length} ตอนจบ/กำลังอัปเดต
                  </span>
                </div>

                <h2 
                  onClick={() => setInspectingNovel(featuredNovel)}
                  className="text-xl sm:text-2xl md:text-3xl font-black tracking-tight cursor-pointer hover:text-amber-600 dark:hover:text-amber-400 transition-colors mb-2.5"
                >
                  {featuredNovel.title}
                </h2>

                <p className="text-xs sm:text-sm opacity-80 line-clamp-3 leading-relaxed mb-5 max-w-2xl">
                  {featuredNovel.description || 'นิยายเสียงคุณภาพสูง พร้อมระบบอ่านออกเสียงธรรมชาติและเสียงบรรยากาศคลอเบาๆ เพื่ออรรถรสในการรับฟัง'}
                </p>

                <div className="flex flex-wrap items-center justify-center md:justify-start gap-2.5">
                  <button
                    onClick={() => onSelectNovelAndChapter(featuredNovel.id, featuredNovel.chapters[0]?.id || '', true)}
                    className="px-5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-white font-extrabold text-xs sm:text-sm flex items-center gap-2 shadow-md active:scale-95 transition-all"
                  >
                    <Play className="w-4 h-4 fill-current" />
                    <span>เริ่มฟังเสียงบรรยายบทที่ 1</span>
                  </button>

                  <button
                    onClick={() => onSelectNovelAndChapter(featuredNovel.id, featuredNovel.chapters[0]?.id || '', false)}
                    className="px-4 py-2.5 rounded-xl border border-amber-500/50 hover:bg-amber-500/10 text-amber-700 dark:text-amber-300 font-bold text-xs sm:text-sm flex items-center gap-1.5 transition-colors"
                  >
                    <BookOpen className="w-4 h-4" />
                    <span>อ่านเนื้อหา</span>
                  </button>

                  <button
                    onClick={() => setInspectingNovel(featuredNovel)}
                    className="px-4 py-2.5 rounded-xl border border-current/15 hover:bg-black/5 dark:hover:bg-white/5 font-semibold text-xs sm:text-sm flex items-center gap-1.5 transition-colors"
                  >
                    <Layers className="w-4 h-4" />
                    <span>ดูสารบัญทุกตอน ({featuredNovel.chapters.length})</span>
                  </button>
                </div>
              </div>
            </div>
          </section>
        )}

        {/* =========================================================================
            SEARCH, CATEGORY FILTER & VIEW CONTROLS
            ========================================================================= */}
        <section
          id="category-and-filter-bar"
          className={`p-4 rounded-2xl border transition-all space-y-3.5 shadow-xs ${
            isDark
              ? 'bg-neutral-900 border-neutral-800'
              : isSepia
              ? 'bg-[#f4ecd8] border-[#dfcfb0]'
              : 'bg-white border-stone-200'
          }`}
        >
          {/* Top Line: Search Input & Controls */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
            {/* Search Input */}
            <div className="relative flex-1">
              <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 opacity-45" />
              <input
                type="text"
                placeholder="ค้นหาชื่อนิยาย, ผู้แต่ง, หมวดหมู่ หรือคำสำคัญ..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-10 py-2.5 text-xs sm:text-sm rounded-xl border border-current/15 bg-black/5 dark:bg-white/5 outline-none focus:ring-2 focus:ring-amber-500 transition-all placeholder:opacity-50"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-xs opacity-50 hover:opacity-100 p-1"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>

            {/* Sort Dropdown & View Mode Switcher */}
            <div className="flex items-center gap-2 justify-between sm:justify-end shrink-0">
              <div className="flex items-center gap-1.5 text-xs">
                <SlidersHorizontal className="w-3.5 h-3.5 opacity-60" />
                <select
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value as SortOption)}
                  className="px-2.5 py-2 rounded-xl border border-current/15 bg-transparent font-semibold text-xs outline-none cursor-pointer"
                >
                  <option value="chapters" className="bg-stone-100 dark:bg-neutral-900 text-stone-900 dark:text-neutral-100">เรียงตาม: ตอนเยอะสุด</option>
                  <option value="latest" className="bg-stone-100 dark:bg-neutral-900 text-stone-900 dark:text-neutral-100">เรียงตาม: อัปเดตล่าสุด</option>
                  <option value="title" className="bg-stone-100 dark:bg-neutral-900 text-stone-900 dark:text-neutral-100">เรียงตาม: ชื่อเรื่อง ก-ฮ</option>
                </select>
              </div>

              {/* View Mode Toggle: Grid vs List */}
              <div className="flex items-center border border-current/15 rounded-xl p-0.5 bg-black/5 dark:bg-white/5">
                <button
                  onClick={() => setViewMode('grid')}
                  className={`p-1.5 rounded-lg transition-all ${
                    viewMode === 'grid' 
                      ? 'bg-amber-500 text-white shadow-xs' 
                      : 'opacity-60 hover:opacity-100'
                  }`}
                  title="มุมมองแบบแกลเลอรีการ์ด (Grid)"
                >
                  <Grid className="w-4 h-4" />
                </button>
                <button
                  onClick={() => setViewMode('list')}
                  className={`p-1.5 rounded-lg transition-all ${
                    viewMode === 'list' 
                      ? 'bg-amber-500 text-white shadow-xs' 
                      : 'opacity-60 hover:opacity-100'
                  }`}
                  title="มุมมองแบบรายการยาว (List)"
                >
                  <ListIcon className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>

          {/* Category Filter Pills */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 custom-scrollbar">
            <span className="text-xs font-bold opacity-60 shrink-0 mr-1">หมวดหมู่:</span>
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-3 py-1 rounded-xl text-xs font-bold shrink-0 transition-all ${
                  selectedCategory === cat
                    ? 'bg-amber-500 text-white shadow-2xs'
                    : 'bg-black/5 dark:bg-white/5 border border-current/10 opacity-75 hover:opacity-100 hover:border-amber-500/40'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </section>

        {/* =========================================================================
            NOVEL DISPLAY SECTION (GRID OR LIST)
            ========================================================================= */}
        <section id="novels-catalog-container" aria-label="คลังนิยายทั้งหมด">
          {filteredNovels.length === 0 ? (
            <div
              className={`p-10 rounded-2xl border text-center ${
                isDark
                  ? 'bg-neutral-900/60 border-neutral-800'
                  : 'bg-white border-stone-200'
              }`}
            >
              <BookOpen className="w-12 h-12 mx-auto text-amber-500/50 mb-3" />
              <h3 className="font-bold text-base mb-1">
                {searchQuery ? 'ไม่พบนิยายตามเงื่อนไขที่ค้นหา' : 'ยังไม่มีนิยายในคลัง'}
              </h3>
              <p className="text-xs opacity-65 mb-4">
                {searchQuery
                  ? 'ลองล้างการค้นหา หรือเลือกหมวดหมู่ "ทั้งหมด"'
                  : userRole === 'admin'
                  ? 'กดปุ่มด้านล่างเพื่อสร้างนิยายเรื่องแรกของคุณ'
                  : 'กรุณารอแอดมินอัปเดตนิยายเรื่องใหม่'}
              </p>
              {searchQuery && (
                <button
                  onClick={() => {
                    setSearchQuery('');
                    setSelectedCategory('ทั้งหมด');
                  }}
                  className="px-4 py-2 rounded-xl bg-amber-500 text-white font-semibold text-xs"
                >
                  ล้างตัวกรองทั้งหมด
                </button>
              )}
            </div>
          ) : viewMode === 'grid' ? (
            /* =================================================================
               GRID VIEW: Beautiful Book Covers (Ideal for Listeners / Viewers)
               ================================================================= */
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3.5 sm:gap-5">
              {filteredNovels.map((novel, index) => {
                const isCurrent = novel.id === activeNovelId;

                return (
                  <article
                    key={novel.id}
                    id={`grid-novel-card-${novel.id}`}
                    className={`rounded-2xl border transition-all overflow-hidden flex flex-col group ${
                      isDark
                        ? 'bg-neutral-900 border-neutral-800 hover:border-neutral-700'
                        : isSepia
                        ? 'bg-[#f8f2e4] border-[#e4d6be] hover:border-amber-700/40 text-[#3d2e24]'
                        : 'bg-white border-stone-200 hover:border-amber-300 shadow-xs hover:shadow-md'
                    } ${isCurrent ? 'ring-2 ring-amber-500/80' : ''}`}
                  >
                    {/* Cover Aspect Container */}
                    <div 
                      onClick={() => {
                        if (userRole === 'admin') {
                          triggerUploadCover(novel.id);
                        } else {
                          setInspectingNovel(novel);
                        }
                      }}
                      className="relative aspect-[3/4] overflow-hidden bg-stone-200 dark:bg-neutral-800 cursor-pointer"
                      title={userRole === 'admin' ? 'คลิกเพื่อเปลี่ยนรูปหน้าปก' : `คลิกเพื่อดูสารบัญและเรื่องย่อ: ${novel.title}`}
                    >
                      {novel.coverImage ? (
                        <img
                          src={novel.coverImage}
                          alt={novel.title}
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                        />
                      ) : (
                        <div className="w-full h-full flex flex-col items-center justify-center p-3 text-center bg-gradient-to-br from-amber-500/20 to-stone-500/20">
                          <BookOpen className="w-8 h-8 opacity-40 mb-1.5 text-amber-500" />
                          <span className="text-xs font-bold line-clamp-2 px-1">
                            {novel.title}
                          </span>
                        </div>
                      )}

                      {/* Chapter count badge top right */}
                      <span className="absolute top-2 right-2 text-[10px] sm:text-xs font-extrabold px-2 py-0.5 rounded-full bg-amber-500 text-white shadow-md">
                        {novel.chapters.length} บท
                      </span>

                      {/* Currently reading indicator */}
                      {isCurrent && (
                        <span className="absolute top-2 left-2 text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-600 text-white shadow-md flex items-center gap-1">
                          <Bookmark className="w-2.5 h-2.5" />
                          <span>กำลังอ่าน</span>
                        </span>
                      )}

                      {/* Admin hover overlay to change cover */}
                      {userRole === 'admin' && (
                        <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center text-white p-2 text-center">
                          <Camera className="w-6 h-6 mb-1" />
                          <span className="text-xs font-bold">เปลี่ยนรูปปก</span>
                        </div>
                      )}

                      {/* Favorite button on bottom-right of cover */}
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          if (currentUser) {
                            onToggleFavorite?.(novel.id);
                          } else {
                            onOpenAuthModal?.();
                          }
                        }}
                        className={`absolute bottom-2 right-2 p-1.5 rounded-full backdrop-blur-md transition-all shadow-md z-10 ${
                          (currentUser?.favorites || []).includes(novel.id)
                            ? 'bg-rose-500 text-white ring-2 ring-white/50'
                            : 'bg-black/40 hover:bg-black/70 text-white/90 hover:text-white'
                        }`}
                        title={(currentUser?.favorites || []).includes(novel.id) ? 'นำออกจากรายการโปรด' : 'กดหัวใจเพื่อบันทึกรายการโปรด'}
                      >
                        <Heart className={`w-3.5 h-3.5 ${(currentUser?.favorites || []).includes(novel.id) ? 'fill-current text-white' : ''}`} />
                      </button>
                    </div>

                    {/* Content Details */}
                    <div className="p-3 sm:p-4 flex-1 flex flex-col justify-between">
                      <div>
                        <div className="flex items-center justify-between gap-1 mb-1">
                          <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-amber-500/15 text-amber-700 dark:text-amber-300 truncate max-w-[110px]">
                            {novel.category || 'นิยาย'}
                          </span>
                          <span className="text-[10px] opacity-60 truncate">
                            {novel.author}
                          </span>
                        </div>

                        <h3
                          onClick={() => {
                            if (userRole === 'admin') {
                              handleStartEditTitle(novel);
                            } else {
                              setInspectingNovel(novel);
                            }
                          }}
                          className="font-bold text-sm sm:text-base leading-snug line-clamp-2 cursor-pointer hover:text-amber-600 dark:hover:text-amber-400 transition-colors mb-1.5"
                          title={novel.title}
                        >
                          {novel.title}
                        </h3>

                        <p className="text-[11px] sm:text-xs opacity-75 line-clamp-2 leading-relaxed mb-3">
                          {novel.description || 'เรื่องย่อนิยาย'}
                        </p>
                      </div>

                      {/* Bottom Action Buttons */}
                      <div className="pt-2 border-t border-current/10 space-y-1.5">
                        <div className="grid grid-cols-2 gap-1.5">
                          <button
                            onClick={() => onSelectNovelAndChapter(novel.id, novel.chapters[0]?.id || '', true)}
                            className="py-1.5 px-2 rounded-xl bg-amber-500 hover:bg-amber-600 text-white font-bold text-xs flex items-center justify-center gap-1 shadow-2xs active:scale-95 transition-all"
                            title="ฟังเสียงบรรยายทันที"
                          >
                            <Play className="w-3 h-3 fill-current" />
                            <span>ฟังเสียง</span>
                          </button>

                          <button
                            onClick={() => setInspectingNovel(novel)}
                            className="py-1.5 px-2 rounded-xl border border-current/20 hover:bg-black/5 dark:hover:bg-white/5 font-semibold text-xs flex items-center justify-center gap-1 transition-colors"
                            title="ดูรายชื่อตอนทั้งหมด"
                          >
                            <Layers className="w-3 h-3" />
                            <span>สารบัญ</span>
                          </button>
                        </div>

                        {/* Admin-only controls */}
                        {userRole === 'admin' && (
                          <div className="flex items-center justify-between pt-1 text-xs opacity-70">
                            <button
                              onClick={() => onOpenAddChapterModal(novel.id)}
                              className="text-amber-600 dark:text-amber-400 font-bold hover:underline"
                            >
                              + เพิ่มบท
                            </button>
                            {novels.length > 1 && (
                              <button
                                onClick={() => {
                                  if (confirm(`คุณต้องการลบ "${novel.title}" หรือไม่?`)) {
                                    onDeleteNovel(novel.id);
                                  }
                                }}
                                className="text-red-500 hover:underline"
                              >
                                ลบ
                              </button>
                            )}
                          </div>
                        )}
                      </div>
                    </div>
                  </article>
                );
              })}
            </div>
          ) : (
            /* =================================================================
               LIST VIEW: Detailed vertical list (Top to bottom)
               ================================================================= */
            <div className="space-y-4">
              {filteredNovels.map((novel, index) => {
                const isCurrentlyReadingThis = novel.id === activeNovelId;
                const chapterCount = novel.chapters.length;

                return (
                  <article
                    key={novel.id}
                    id={`list-novel-card-${novel.id}`}
                    className={`rounded-2xl border transition-all overflow-hidden p-4 sm:p-5 ${
                      isDark
                        ? 'bg-neutral-900 border-neutral-800 hover:border-neutral-700'
                        : isSepia
                        ? 'bg-[#f8f2e4] border-[#e4d6be] text-[#3d2e24]'
                        : 'bg-white border-stone-200 shadow-xs hover:shadow-md'
                    } ${isCurrentlyReadingThis ? 'ring-2 ring-amber-500/80' : ''}`}
                  >
                    <div className="flex flex-col sm:flex-row gap-4 items-start">
                      {/* Cover */}
                      <div 
                        onClick={() => {
                          if (userRole === 'admin') triggerUploadCover(novel.id);
                          else setInspectingNovel(novel);
                        }}
                        className="w-28 h-40 sm:w-32 sm:h-46 rounded-xl overflow-hidden shrink-0 border border-stone-300 dark:border-neutral-700 bg-stone-100 dark:bg-neutral-800 shadow-md cursor-pointer relative group mx-auto sm:mx-0"
                      >
                        {novel.coverImage ? (
                          <img src={novel.coverImage} alt={novel.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform" />
                        ) : (
                          <div className="w-full h-full flex flex-col items-center justify-center p-3 text-center bg-amber-500/10">
                            <BookOpen className="w-8 h-8 text-amber-500 opacity-50 mb-1" />
                            <span className="text-xs font-bold line-clamp-3">{novel.title}</span>
                          </div>
                        )}

                        {userRole === 'admin' && (
                          <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center text-white text-xs font-bold">
                            <Camera className="w-5 h-5 mb-1" />
                            <span>เปลี่ยนรูปปก</span>
                          </div>
                        )}
                      </div>

                      {/* Content */}
                      <div className="flex-1 min-w-0 w-full">
                        <div className="flex items-center justify-between gap-2 mb-1.5">
                          <div className="flex items-center gap-2">
                            <span className="text-xs font-bold px-2 py-0.5 rounded-md bg-black/5 dark:bg-white/10 opacity-70">
                              #{index + 1}
                            </span>
                            <span className="text-xs font-semibold px-2.5 py-0.5 rounded-full bg-amber-500/15 text-amber-700 dark:text-amber-300">
                              {novel.category}
                            </span>
                          </div>
                          <span className="text-xs sm:text-sm font-extrabold px-3 py-1 rounded-full bg-amber-500 text-white shadow-2xs flex items-center gap-1.5">
                            <Layers className="w-3.5 h-3.5" />
                            <span>{chapterCount} ตอน</span>
                          </span>
                        </div>

                        <h3 
                          onClick={() => setInspectingNovel(novel)}
                          className="text-lg sm:text-xl font-bold cursor-pointer hover:text-amber-600 dark:hover:text-amber-400 transition-colors mb-1"
                        >
                          {novel.title}
                        </h3>

                        <p className="text-xs opacity-70 mb-2">ผู้แต่ง: <span className="font-semibold">{novel.author}</span></p>

                        <p className="text-xs sm:text-sm opacity-80 leading-relaxed line-clamp-2 mb-3">
                          {novel.description || 'ไม่มีคำอธิบาย'}
                        </p>

                        {/* Chapter shortcuts */}
                        <div className="flex flex-wrap gap-1.5 mb-3.5 pt-2 border-t border-current/10">
                          {novel.chapters.slice(0, 5).map((chap) => (
                            <button
                              key={chap.id}
                              onClick={() => onSelectNovelAndChapter(novel.id, chap.id)}
                              className="text-xs px-2.5 py-1 rounded-xl border border-current/15 hover:bg-amber-500/10 hover:border-amber-500 text-xs truncate max-w-[140px]"
                            >
                              #{chap.number} {chap.title}
                            </button>
                          ))}
                          {novel.chapters.length > 5 && (
                            <button
                              onClick={() => setInspectingNovel(novel)}
                              className="text-xs px-2.5 py-1 rounded-xl border border-dashed border-amber-500/40 text-amber-600 dark:text-amber-400 font-bold"
                            >
                              + ดูอีก {novel.chapters.length - 5} ตอน
                            </button>
                          )}
                        </div>

                        {/* Actions */}
                        <div className="flex flex-wrap items-center gap-2">
                          <button
                            onClick={() => onSelectNovelAndChapter(novel.id, novel.chapters[0]?.id || '', true)}
                            className="px-3.5 py-2 rounded-xl bg-amber-500 hover:bg-amber-600 text-white font-bold text-xs sm:text-sm flex items-center gap-1.5 shadow-xs"
                          >
                            <Play className="w-3.5 h-3.5 fill-current" />
                            <span>ฟังเสียงบรรยาย</span>
                          </button>

                          <button
                            onClick={() => onSelectNovelAndChapter(novel.id, novel.chapters[0]?.id || '', false)}
                            className="px-3.5 py-2 rounded-xl border border-amber-500/50 hover:bg-amber-500/10 text-amber-700 dark:text-amber-300 font-bold text-xs sm:text-sm flex items-center gap-1.5"
                          >
                            <BookOpen className="w-3.5 h-3.5" />
                            <span>อ่านเนื้อหา</span>
                          </button>

                          <button
                            onClick={() => setInspectingNovel(novel)}
                            className="px-3 py-2 rounded-xl border border-current/15 hover:bg-black/5 dark:hover:bg-white/5 font-semibold text-xs flex items-center gap-1.5"
                          >
                            <Layers className="w-3.5 h-3.5" />
                            <span>สารบัญเต็ม</span>
                          </button>

                          {/* Favorite button in list view */}
                          <button
                            onClick={() => {
                              if (currentUser) {
                                onToggleFavorite?.(novel.id);
                              } else {
                                onOpenAuthModal?.();
                              }
                            }}
                            className={`p-2 rounded-xl border transition-all ${
                              (currentUser?.favorites || []).includes(novel.id)
                                ? 'bg-rose-500 text-white border-rose-600 shadow-2xs'
                                : 'border-current/15 hover:bg-black/5 dark:hover:bg-white/5 opacity-70 hover:opacity-100'
                            }`}
                            title={(currentUser?.favorites || []).includes(novel.id) ? 'นำออกจากรายการโปรด' : 'บันทึกเป็นรายการโปรด'}
                          >
                            <Heart className={`w-4 h-4 ${(currentUser?.favorites || []).includes(novel.id) ? 'fill-current' : ''}`} />
                          </button>
                        </div>
                      </div>
                    </div>
                  </article>
                );
              })}
            </div>
          )}
        </section>
      </div>

      {/* =========================================================================
          VIEWER MODAL: FULL NOVEL SYNOPSIS & COMPLETE CHAPTER CATALOG
          ========================================================================= */}
      {inspectingNovel && (
        <div
          id="viewer-novel-inspect-modal"
          className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-3 sm:p-5 animate-in fade-in duration-200"
          onClick={() => setInspectingNovel(null)}
        >
          <div
            className={`w-full max-w-2xl max-h-[90vh] rounded-3xl border shadow-2xl flex flex-col overflow-hidden transition-all ${
              isDark
                ? 'bg-neutral-900 border-neutral-800 text-neutral-100'
                : isSepia
                ? 'bg-[#f7f1e3] border-[#decbb0] text-[#3d2e24]'
                : 'bg-white border-stone-200 text-stone-900'
            }`}
            onClick={(e) => e.stopPropagation()}
          >
            {/* Modal Header */}
            <div className="p-4 sm:p-5 border-b border-current/10 flex items-center justify-between shrink-0">
              <div className="flex items-center gap-2">
                <BookOpen className="w-5 h-5 text-amber-500" />
                <span className="font-extrabold text-sm sm:text-base">
                  ข้อมูลนิยาย & สารบัญบททั้งหมด
                </span>
              </div>
              <button
                onClick={() => setInspectingNovel(null)}
                className="p-1.5 rounded-full hover:bg-black/10 dark:hover:bg-white/10 opacity-70 hover:opacity-100 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Body: Scrollable */}
            <div className="p-4 sm:p-6 overflow-y-auto custom-scrollbar space-y-5 flex-1">
              {/* Top Novel Summary */}
              <div className="flex flex-col sm:flex-row gap-4 sm:gap-5 items-start">
                <div className="w-32 h-44 sm:w-36 sm:h-50 rounded-2xl overflow-hidden shrink-0 border border-stone-300 dark:border-neutral-700 shadow-md bg-stone-200 dark:bg-neutral-800 mx-auto sm:mx-0">
                  {inspectingNovel.coverImage ? (
                    <img src={inspectingNovel.coverImage} alt={inspectingNovel.title} className="w-full h-full object-cover" />
                  ) : (
                    <div className="w-full h-full flex flex-col items-center justify-center p-3 text-center bg-amber-500/20 text-amber-700 dark:text-amber-300">
                      <BookOpen className="w-8 h-8 mb-1" />
                      <span className="text-xs font-bold">{inspectingNovel.title}</span>
                    </div>
                  )}
                </div>

                <div className="flex-1 text-center sm:text-left">
                  <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2 mb-1.5">
                    <span className="text-xs font-bold px-2.5 py-0.5 rounded-full bg-amber-500/20 text-amber-700 dark:text-amber-300">
                      {inspectingNovel.category}
                    </span>
                    <span className="text-xs font-semibold opacity-75">
                      ผู้แต่ง: {inspectingNovel.author}
                    </span>
                  </div>

                  <h3 className="text-xl sm:text-2xl font-black mb-2">
                    {inspectingNovel.title}
                  </h3>

                  <p className="text-xs sm:text-sm opacity-80 leading-relaxed max-h-28 overflow-y-auto custom-scrollbar pr-1 mb-4">
                    {inspectingNovel.description || 'ไม่มีคำอธิบายเรื่องย่อ'}
                  </p>

                  <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2">
                    <button
                      onClick={() => {
                        onSelectNovelAndChapter(inspectingNovel.id, inspectingNovel.chapters[0]?.id || '', true);
                        setInspectingNovel(null);
                      }}
                      className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-600 text-white font-bold text-xs sm:text-sm flex items-center gap-1.5 shadow-xs"
                    >
                      <Play className="w-3.5 h-3.5 fill-current" />
                      <span>เริ่มฟังตั้งแต่บทแรก</span>
                    </button>

                    <button
                      onClick={() => {
                        const lastChapter = inspectingNovel.chapters[inspectingNovel.chapters.length - 1];
                        onSelectNovelAndChapter(inspectingNovel.id, lastChapter?.id || '', true);
                        setInspectingNovel(null);
                      }}
                      className="px-3.5 py-2 rounded-xl border border-amber-500/50 hover:bg-amber-500/10 text-amber-700 dark:text-amber-300 font-semibold text-xs sm:text-sm"
                    >
                      <span>ฟังตอนล่าสุด (#{inspectingNovel.chapters.length})</span>
                    </button>

                    <button
                      onClick={() => {
                        if (currentUser) {
                          onToggleFavorite?.(inspectingNovel.id);
                        } else {
                          onOpenAuthModal?.();
                        }
                      }}
                      className={`px-3.5 py-2 rounded-xl border flex items-center gap-1.5 text-xs sm:text-sm font-bold transition-all ${
                        (currentUser?.favorites || []).includes(inspectingNovel.id)
                          ? 'bg-rose-500 text-white border-rose-600'
                          : 'border-current/15 hover:bg-black/5 dark:hover:bg-white/5 opacity-80 hover:opacity-100'
                      }`}
                    >
                      <Heart className={`w-3.5 h-3.5 ${(currentUser?.favorites || []).includes(inspectingNovel.id) ? 'fill-current' : ''}`} />
                      <span>{(currentUser?.favorites || []).includes(inspectingNovel.id) ? 'บันทึกแล้ว' : 'บันทึกโปรด'}</span>
                    </button>
                  </div>
                </div>
              </div>

              {/* Chapter Catalog List */}
              <div className="pt-4 border-t border-current/10 space-y-3">
                <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-2">
                  <span className="font-extrabold text-sm flex items-center gap-1.5">
                    <Layers className="w-4 h-4 text-amber-500" />
                    <span>รายชื่อตอนทั้งหมด ({inspectingNovel.chapters.length} ตอน):</span>
                  </span>

                  {/* Chapter Search Filter */}
                  <div className="relative">
                    <Search className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 opacity-40" />
                    <input
                      type="text"
                      placeholder="ค้นหาชื่อหรือเลขตอน..."
                      value={inspectingChapterSearch}
                      onChange={(e) => setInspectingChapterSearch(e.target.value)}
                      className="pl-8 pr-3 py-1.5 text-xs rounded-xl border border-current/15 bg-black/5 dark:bg-white/5 outline-none focus:ring-1 focus:ring-amber-500"
                    />
                  </div>
                </div>

                {/* Chapter List Box */}
                <div className="max-h-64 overflow-y-auto custom-scrollbar space-y-1.5 pr-1 border border-current/10 rounded-2xl p-2 bg-black/5 dark:bg-white/5">
                  {inspectingNovel.chapters
                    .filter(c => 
                      c.title.toLowerCase().includes(inspectingChapterSearch.toLowerCase()) || 
                      String(c.number).includes(inspectingChapterSearch)
                    )
                    .map((chap) => {
                      const isCurrentActive = inspectingNovel.id === activeNovelId && chap.id === activeChapterId;

                      return (
                        <div
                          key={chap.id}
                          className={`p-2.5 rounded-xl border transition-all flex items-center justify-between gap-2 ${
                            isCurrentActive
                              ? 'bg-amber-500/20 border-amber-500/60 font-bold'
                              : 'border-current/10 hover:bg-black/5 dark:hover:bg-white/5'
                          }`}
                        >
                          <div className="flex items-center gap-2.5 min-w-0">
                            <span className="text-xs font-mono opacity-60 w-7 shrink-0 text-right">
                              #{chap.number}
                            </span>
                            <span className="text-xs sm:text-sm truncate">
                              {chap.title}
                            </span>
                          </div>

                          <div className="flex items-center gap-1.5 shrink-0">
                            <button
                              onClick={() => {
                                onSelectNovelAndChapter(inspectingNovel.id, chap.id, true);
                                setInspectingNovel(null);
                              }}
                              className="px-2.5 py-1 rounded-lg bg-amber-500 hover:bg-amber-600 text-white font-bold text-xs flex items-center gap-1"
                              title="ฟังตอนนี้ทันที"
                            >
                              <Play className="w-3 h-3 fill-current" />
                              <span>ฟัง</span>
                            </button>

                            <button
                              onClick={() => {
                                onSelectNovelAndChapter(inspectingNovel.id, chap.id, false);
                                setInspectingNovel(null);
                              }}
                              className="px-2.5 py-1 rounded-lg border border-current/20 text-xs hover:bg-black/10 dark:hover:bg-white/10"
                              title="อ่านเนื้อหาตอนนี้"
                            >
                              อ่าน
                            </button>
                          </div>
                        </div>
                      );
                    })}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </main>
  );
};
