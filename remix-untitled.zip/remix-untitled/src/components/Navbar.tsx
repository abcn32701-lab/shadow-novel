import React, { useState } from 'react';
import { 
  BookOpen, 
  Sparkles, 
  Moon, 
  Sun, 
  CloudRain, 
  Timer, 
  Sliders, 
  Layers,
  Plus,
  ArrowLeft,
  BookMarked,
  Menu,
  X,
  ShieldCheck,
  Headphones,
  Compass,
  Share2,
  User,
  LogIn,
  Globe
} from 'lucide-react';
import { Novel, Chapter, ReadingSettings, AmbientSoundType, UserRole, UserProfile } from '../types';

interface NavbarProps {
  currentView: 'home' | 'reader';
  onSwitchView: (view: 'home' | 'reader') => void;
  userRole: UserRole;
  onToggleUserRole: () => void;
  totalNovelsCount: number;
  currentNovel: Novel;
  currentChapter: Chapter;
  readingSettings: ReadingSettings;
  ambientSound: AmbientSoundType;
  sleepTimerRemaining: number | null;
  isChapterSidebarOpen: boolean;
  onToggleChapterSidebar: () => void;
  onOpenAddChapter: () => void;
  onOpenCreateNovel: () => void;
  onOpenLibrary: () => void;
  onOpenSettings: () => void;
  onOpenAI: () => void;
  onOpenSleepTimer: () => void;
  onCycleAmbient: () => void;
  onToggleTheme: () => void;
  currentUser: UserProfile | null;
  onOpenAuthModal: () => void;
  onOpenProfileModal: () => void;
  onOpenShareModal: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentView,
  onSwitchView,
  userRole,
  onToggleUserRole,
  totalNovelsCount,
  currentNovel,
  currentChapter,
  readingSettings,
  ambientSound,
  sleepTimerRemaining,
  isChapterSidebarOpen,
  onToggleChapterSidebar,
  onOpenAddChapter,
  onOpenCreateNovel,
  onOpenLibrary,
  onOpenSettings,
  onOpenAI,
  onOpenSleepTimer,
  onCycleAmbient,
  onToggleTheme,
  currentUser,
  onOpenAuthModal,
  onOpenProfileModal,
  onOpenShareModal,
}) => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const isDark = readingSettings.theme === 'night' || readingSettings.theme === 'oled';

  // Format timer
  const formatTimer = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  const getAmbientLabel = (type: AmbientSoundType) => {
    switch (type) {
      case 'rain': return 'เสียงฝน';
      case 'campfire': return 'กองไฟ';
      case 'cafe': return 'คาเฟ่';
      case 'waves': return 'คลื่นทะเล';
      default: return 'บรรยากาศ';
    }
  };

  const hasActiveBackgroundEffects = ambientSound !== 'off' || sleepTimerRemaining !== null;

  return (
    <header 
      id="novel-reader-navbar"
      className={`sticky top-0 z-40 border-b px-2.5 sm:px-4 py-2 sm:py-2.5 transition-colors duration-200 backdrop-blur-md ${
        readingSettings.theme === 'oled' 
          ? 'bg-black/90 border-neutral-900 text-neutral-100' 
          : readingSettings.theme === 'night'
          ? 'bg-neutral-900/90 border-neutral-800 text-neutral-200'
          : readingSettings.theme === 'sepia'
          ? 'bg-[#f4ecd8]/95 border-[#e2d5bd] text-[#4a3b32]'
          : 'bg-amber-50/95 border-amber-200/60 text-stone-800 shadow-xs'
      }`}
    >
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-1.5 sm:gap-3">
        {/* Left: Brand Identity & Navigation */}
        <div className="flex items-center gap-2 min-w-0">
          {/* Logo / Brand Name Button (Shadow Novel - นิยายเงา) */}
          <button
            id="btn-navbar-logo-home"
            onClick={() => onSwitchView('home')}
            className="flex items-center gap-2 group text-left px-1.5 py-1 rounded-xl hover:bg-black/5 dark:hover:bg-white/5 transition-all shrink-0"
            title="ไปที่หน้าหลัก Shadow Novel (นิยายเงา)"
          >
            <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-amber-500 to-amber-600 text-white flex items-center justify-center shadow-xs shrink-0 group-hover:scale-105 transition-transform">
              <BookOpen className="w-4 h-4" />
            </div>
            <div className="leading-tight">
              <div className="flex items-center gap-1.5">
                <span className="text-sm sm:text-base font-extrabold tracking-tight">
                  Shadow Novel
                </span>
                <span className="hidden xs:inline-block text-[9px] font-bold px-1.5 py-0.2 rounded-full bg-amber-500/20 text-amber-700 dark:text-amber-300">
                  {totalNovelsCount}
                </span>
              </div>
              <div className="text-[10px] font-medium opacity-65 flex items-center gap-1">
                <span>นิยายเงา</span>
                <span className="opacity-40">•</span>
                <span>{userRole === 'admin' ? 'แอดมิน' : 'เว็บนิยายเสียง'}</span>
              </div>
            </div>
          </button>

          {/* Desktop Extra: Current Reading Novel Tag */}
          {currentView === 'reader' && (
            <div className="hidden lg:flex items-center gap-2 pl-2 border-l border-current/15 text-xs opacity-80 min-w-0">
              <button
                onClick={onToggleChapterSidebar}
                className={`flex items-center gap-1 px-2 py-1 rounded-lg border transition-all text-xs ${
                  isChapterSidebarOpen
                    ? 'bg-amber-500/20 border-amber-500/40 text-amber-700 dark:text-amber-300 font-bold'
                    : 'border-current/15 hover:bg-black/5 dark:hover:bg-white/5'
                }`}
                title="เปิด/ปิด แถบตอนนิยาย"
              >
                <Layers className="w-3.5 h-3.5 text-amber-500" />
                <span>แถบตอน ({currentNovel.chapters.length})</span>
              </button>
              <div className="truncate max-w-[220px]">
                <span className="font-bold">{currentNovel.title}</span>
                <span className="opacity-50 mx-1">/</span>
                <span className="opacity-80">{currentChapter.title}</span>
              </div>
            </div>
          )}
        </div>

        {/* Right Section for MOBILE (< sm): STRICTLY COMPACT & NEVER OVERLAPPING */}
        <div className="flex sm:hidden items-center gap-1.5 shrink-0">
          {/* View Switcher Button on Mobile */}
          {currentView === 'reader' ? (
            <button
              id="btn-mobile-nav-home"
              onClick={() => onSwitchView('home')}
              className="flex items-center gap-1 text-[11px] px-2 py-1.5 rounded-lg bg-amber-500 text-white font-bold shadow-2xs active:scale-95 transition-all shrink-0"
              title="กลับไปที่หน้าหลักคลังนิยาย"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>หน้าหลัก</span>
            </button>
          ) : (
            <button
              id="btn-mobile-nav-reader"
              onClick={() => onSwitchView('reader')}
              className="flex items-center gap-1 text-[11px] px-2 py-1.5 rounded-lg border border-amber-500/50 bg-amber-500/10 text-amber-700 dark:text-amber-300 font-bold shadow-2xs active:scale-95 transition-all shrink-0"
              title="เปิดหน้าอ่านนิยายต่อ"
            >
              <BookMarked className="w-3.5 h-3.5 text-amber-500" />
              <span>อ่านต่อ</span>
            </button>
          )}

          {/* Quick Role Switcher Button on Mobile */}
          <button
            id="btn-mobile-toggle-role"
            onClick={onToggleUserRole}
            className={`flex items-center gap-1 text-[11px] px-2 py-1.5 rounded-lg border font-bold shrink-0 transition-all ${
              userRole === 'admin'
                ? 'bg-amber-500/20 border-amber-500/50 text-amber-700 dark:text-amber-300'
                : 'bg-indigo-500/15 border-indigo-500/40 text-indigo-700 dark:text-indigo-300'
            }`}
            title="กดเพื่อสลับโหมด แอดมิน / คนฟัง"
          >
            {userRole === 'admin' ? (
              <>
                <ShieldCheck className="w-3 h-3 text-amber-500" />
                <span>แอดมิน</span>
              </>
            ) : (
              <>
                <Headphones className="w-3 h-3 text-indigo-500" />
                <span>คนฟัง</span>
              </>
            )}
          </button>

          {/* Theme Toggle Button on Mobile */}
          <button
            id="btn-mobile-toggle-theme"
            onClick={onToggleTheme}
            className="p-1.5 rounded-lg border border-current/15 hover:bg-black/5 dark:hover:bg-white/5 opacity-80 shrink-0"
            title="สลับธีมถนอมสายตา / กลางคืน"
          >
            {isDark ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4" />}
          </button>

          {/* Mobile Menu Trigger */}
          <button
            id="btn-mobile-menu-trigger"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className={`relative p-1.5 rounded-lg border transition-colors shrink-0 ${
              isMobileMenuOpen 
                ? 'bg-amber-500 text-white border-amber-600' 
                : 'border-current/15 bg-black/5 dark:bg-white/5 opacity-85'
            }`}
            title="เปิดเมนูเครื่องมือเพิ่มเติม"
          >
            {isMobileMenuOpen ? <X className="w-4 h-4" /> : <Menu className="w-4 h-4" />}
            {hasActiveBackgroundEffects && !isMobileMenuOpen && (
              <span className="absolute -top-1 -right-1 w-2 h-2 rounded-full bg-amber-500 animate-ping" />
            )}
          </button>
        </div>

        {/* Right Section for TABLET & DESKTOP (>= sm): Spacious, complete toolbar */}
        <div className="hidden sm:flex items-center gap-1.5 md:gap-2 shrink-0">
          {/* View Switch Button */}
          {currentView === 'reader' ? (
            <button
              id="btn-navbar-back-home"
              onClick={() => onSwitchView('home')}
              className="flex items-center gap-1.5 text-xs px-2.5 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-white font-bold shadow-xs active:scale-95 transition-all"
              title="กลับไปที่หน้าหลักคลังนิยาย"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>หน้าหลัก</span>
            </button>
          ) : (
            <button
              id="btn-navbar-go-reader"
              onClick={() => onSwitchView('reader')}
              className="flex items-center gap-1.5 text-xs px-2.5 py-1.5 rounded-xl border border-current/20 hover:border-amber-500 hover:bg-amber-500/10 font-semibold transition-all"
              title="เปิดหน้าอ่านนิยายต่อ"
            >
              <BookMarked className="w-3.5 h-3.5 text-amber-500" />
              <span>อ่านต่อ</span>
              <span className="hidden md:inline text-[11px] opacity-70 truncate max-w-[120px]">
                ({currentNovel.title})
              </span>
            </button>
          )}

          {/* Role Toggle Switcher */}
          <button
            id="btn-navbar-toggle-role"
            onClick={onToggleUserRole}
            className={`flex items-center gap-1.5 text-xs px-2.5 py-1.5 rounded-xl border transition-all font-bold ${
              userRole === 'admin'
                ? 'bg-amber-500/15 border-amber-500/50 text-amber-800 dark:text-amber-200'
                : 'bg-indigo-500/15 border-indigo-500/50 text-indigo-800 dark:text-indigo-200'
            }`}
            title="คลิกเพื่อสลับระหว่างโหมดแอดมิน (สร้าง/แก้ไข) และโหมดคนฟัง (หน้าเว็บสำหรับผู้ชม)"
          >
            {userRole === 'admin' ? (
              <>
                <ShieldCheck className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400" />
                <span>แอดมิน</span>
              </>
            ) : (
              <>
                <Headphones className="w-3.5 h-3.5 text-indigo-600 dark:text-indigo-400" />
                <span>โหมดคนฟัง</span>
              </>
            )}
          </button>

          {/* Admin-only: Create Novel Button */}
          {userRole === 'admin' && (
            <button
              id="btn-navbar-create-novel"
              onClick={onOpenCreateNovel}
              className="flex items-center gap-1 px-2.5 py-1.5 text-xs font-semibold rounded-xl bg-amber-500 hover:bg-amber-600 text-white shadow-xs active:scale-95 transition-all"
              title="สร้างนิยายเรื่องใหม่"
            >
              <Plus className="w-3.5 h-3.5" />
              <span className="hidden md:inline">สร้างเรื่องใหม่</span>
            </button>
          )}

          {/* Ambient Sound Toggle */}
          <button
            id="btn-navbar-ambient"
            onClick={onCycleAmbient}
            className={`relative flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium rounded-xl border transition-colors ${
              ambientSound !== 'off'
                ? 'bg-amber-500/20 border-amber-500/40 text-amber-700 dark:text-amber-300 font-semibold'
                : 'border-current/15 hover:bg-black/5 dark:hover:bg-white/5 opacity-80 hover:opacity-100'
            }`}
            title="เสียงบรรยากาศคลอเบาๆ (ฝนตก, กองไฟ, คาเฟ่, คลื่นทะเล)"
          >
            <CloudRain className={`w-3.5 h-3.5 ${ambientSound !== 'off' ? 'text-amber-600 animate-pulse' : ''}`} />
            <span className="hidden lg:inline">{ambientSound !== 'off' ? getAmbientLabel(ambientSound) : 'บรรยากาศ'}</span>
            {ambientSound !== 'off' && (
              <span className="w-1.5 h-1.5 rounded-full bg-amber-500 animate-ping absolute -top-0.5 -right-0.5" />
            )}
          </button>

          {/* Sleep Timer */}
          <button
            id="btn-navbar-sleep-timer"
            onClick={onOpenSleepTimer}
            className={`flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium rounded-xl border transition-colors ${
              sleepTimerRemaining !== null
                ? 'bg-indigo-500/20 border-indigo-500/40 text-indigo-700 dark:text-indigo-300 font-semibold'
                : 'border-current/15 hover:bg-black/5 dark:hover:bg-white/5 opacity-80 hover:opacity-100'
            }`}
            title="ตั้งเวลาปิดเสียงอ่านอัตโนมัติ"
          >
            <Timer className={`w-3.5 h-3.5 ${sleepTimerRemaining !== null ? 'text-indigo-600 animate-spin' : ''}`} />
            <span className="tabular-nums">
              {sleepTimerRemaining !== null ? formatTimer(sleepTimerRemaining) : 'เวลา'}
            </span>
          </button>

          {/* AI Story Assistant */}
          <button
            id="btn-navbar-ai"
            onClick={onOpenAI}
            className="flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium rounded-xl border border-purple-500/30 bg-purple-500/10 text-purple-700 dark:text-purple-300 hover:bg-purple-500/20 transition-colors shadow-xs"
            title="ผู้ช่วยวิเคราะห์และต่อเติมนิยายด้วย AI"
          >
            <Sparkles className="w-3.5 h-3.5 text-purple-600 dark:text-purple-400" />
            <span className="hidden md:inline">AI</span>
          </button>

          {/* Quick Theme Toggle */}
          <button
            id="btn-navbar-toggle-theme"
            onClick={onToggleTheme}
            className="p-2 rounded-xl border border-current/15 hover:bg-black/5 dark:hover:bg-white/5 opacity-80 hover:opacity-100 transition-colors"
            title="สลับธีมถนอมสายตา / กลางคืน"
          >
            {isDark ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4" />}
          </button>

          {/* Share Listener Link Button */}
          <button
            id="btn-navbar-share-link"
            onClick={onOpenShareModal}
            className="flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-bold rounded-xl border border-indigo-500/30 bg-indigo-500/10 text-indigo-700 dark:text-indigo-300 hover:bg-indigo-500/20 transition-all shadow-xs"
            title="ดูและคัดลอกลิงก์หน้าเว็บคนดู หรือเปิดเต็มจอในแท็บใหม่"
          >
            <Globe className="w-3.5 h-3.5 text-indigo-600 dark:text-indigo-400" />
            <span className="hidden md:inline">ลิงก์คนดู</span>
          </button>

          {/* User Account / Login Button */}
          {currentUser ? (
            <button
              id="btn-navbar-user-profile"
              onClick={onOpenProfileModal}
              className="flex items-center gap-1.5 pl-1.5 pr-2.5 py-1 rounded-xl border border-stone-300 dark:border-neutral-700 hover:border-amber-500 hover:bg-black/5 dark:hover:bg-white/5 transition-all text-xs font-bold"
              title="ดูข้อมูลบัญชีผู้ใช้และรายการโปรด"
            >
              <div className={`w-6 h-6 rounded-lg bg-gradient-to-br ${currentUser.avatarColor || 'from-amber-500 to-amber-600'} text-white flex items-center justify-center text-[11px] font-black shadow-2xs shrink-0`}>
                {currentUser.name.slice(0, 1).toUpperCase()}
              </div>
              <span className="hidden md:inline truncate max-w-[100px]">{currentUser.name}</span>
            </button>
          ) : (
            <button
              id="btn-navbar-login"
              onClick={onOpenAuthModal}
              className="flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-bold rounded-xl border border-stone-300 dark:border-neutral-700 hover:border-amber-500 hover:bg-amber-500/10 text-stone-700 dark:text-neutral-200 transition-all shadow-2xs"
              title="เข้าสู่ระบบหรือสมัครสมาชิกด้วยอีเมลและรหัสผ่าน"
            >
              <LogIn className="w-3.5 h-3.5 text-amber-500" />
              <span>เข้าสู่ระบบ</span>
            </button>
          )}

          {/* Settings Button */}
          <button
            id="btn-navbar-settings"
            onClick={onOpenSettings}
            className="p-2 rounded-xl border border-current/15 hover:bg-black/5 dark:hover:bg-white/5 opacity-80 hover:opacity-100 transition-colors"
            title="ตั้งค่าเสียงและรูปแบบตัวอักษร"
          >
            <Sliders className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* MOBILE POPUP / SLIDE-DOWN DRAWER MENU */}
      {isMobileMenuOpen && (
        <div 
          id="mobile-navbar-dropdown"
          className="sm:hidden mt-2 pt-3 pb-2 border-t border-current/15 space-y-2.5 animate-in slide-in-from-top-2 duration-150"
        >
          {/* User Account / Login Banner in Mobile */}
          <div className="p-2.5 rounded-2xl bg-stone-100 dark:bg-neutral-800 border border-current/10 flex items-center justify-between gap-2">
            {currentUser ? (
              <div 
                className="flex items-center gap-2 min-w-0 cursor-pointer flex-1"
                onClick={() => {
                  setIsMobileMenuOpen(false);
                  onOpenProfileModal();
                }}
              >
                <div className={`w-8 h-8 rounded-xl bg-gradient-to-br ${currentUser.avatarColor || 'from-amber-500 to-amber-600'} text-white flex items-center justify-center text-sm font-black shrink-0`}>
                  {currentUser.name.slice(0, 1).toUpperCase()}
                </div>
                <div className="min-w-0">
                  <span className="font-bold text-xs block truncate">{currentUser.name}</span>
                  <span className="text-[10px] opacity-65 block truncate">{currentUser.email}</span>
                </div>
              </div>
            ) : (
              <div className="flex items-center gap-2 flex-1">
                <div className="w-8 h-8 rounded-xl bg-amber-500/20 text-amber-700 dark:text-amber-300 flex items-center justify-center shrink-0">
                  <User className="w-4 h-4" />
                </div>
                <div>
                  <span className="font-bold text-xs block">ยังไม่ได้เข้าสู่ระบบ</span>
                  <span className="text-[10px] opacity-65 block">สมัครเพื่อบันทึกนิยายโปรด</span>
                </div>
              </div>
            )}

            {currentUser ? (
              <button
                onClick={() => {
                  setIsMobileMenuOpen(false);
                  onOpenProfileModal();
                }}
                className="px-2.5 py-1.5 text-xs font-bold rounded-xl border border-current/20 hover:bg-black/5 shrink-0"
              >
                ดูโปรไฟล์
              </button>
            ) : (
              <button
                onClick={() => {
                  setIsMobileMenuOpen(false);
                  onOpenAuthModal();
                }}
                className="px-3 py-1.5 text-xs font-bold rounded-xl bg-amber-500 text-white shadow-xs shrink-0"
              >
                เข้าสู่ระบบ
              </button>
            )}
          </div>

          {/* Share Listener Link Card in Mobile */}
          <button
            onClick={() => {
              setIsMobileMenuOpen(false);
              onOpenShareModal();
            }}
            className="w-full p-2.5 rounded-2xl bg-indigo-500/10 border border-indigo-500/20 text-indigo-900 dark:text-indigo-200 flex items-center justify-between gap-2 text-xs font-bold"
          >
            <div className="flex items-center gap-2">
              <Globe className="w-4 h-4 text-indigo-500" />
              <span>คัดลอกลิงก์เว็บคนดู (Direct Link)</span>
            </div>
            <span className="text-[10px] bg-indigo-500 text-white px-2 py-0.5 rounded-lg">แชร์ลิงก์</span>
          </button>
          {/* Role explanation & switcher card */}
          <div className="p-2.5 rounded-xl bg-black/5 dark:bg-white/5 border border-current/10 flex items-center justify-between gap-2">
            <div>
              <div className="text-xs font-bold flex items-center gap-1">
                {userRole === 'admin' ? (
                  <>
                    <ShieldCheck className="w-3.5 h-3.5 text-amber-500" />
                    <span>คุณกำลังอยู่ในโหมดแอดมิน</span>
                  </>
                ) : (
                  <>
                    <Headphones className="w-3.5 h-3.5 text-indigo-500" />
                    <span>มุมมองผู้ฟัง (Shadow Novel)</span>
                  </>
                )}
              </div>
              <p className="text-[10px] opacity-60">
                {userRole === 'admin' 
                  ? 'สร้างนิยาย, เพิ่มตอน, แก้ไข และลบได้'
                  : 'โหมดสะอาดตาสำหรับคนดูและคนฟังทั่วไป'}
              </p>
            </div>
            <button
              onClick={() => {
                onToggleUserRole();
              }}
              className="px-2.5 py-1 text-xs font-bold rounded-lg bg-amber-500 text-white shrink-0 shadow-xs"
            >
              สลับเป็น {userRole === 'admin' ? 'โหมดคนฟัง' : 'โหมดแอดมิน'}
            </button>
          </div>

          {/* Quick action grid in mobile drawer */}
          <div className="grid grid-cols-2 gap-2">
            {/* Ambient Sound */}
            <button
              onClick={() => {
                onCycleAmbient();
              }}
              className={`p-2 rounded-xl border flex items-center gap-2 text-xs font-semibold text-left transition-colors ${
                ambientSound !== 'off'
                  ? 'bg-amber-500/20 border-amber-500/50 text-amber-700 dark:text-amber-300'
                  : 'border-current/15 hover:bg-black/5 dark:hover:bg-white/5'
              }`}
            >
              <CloudRain className="w-4 h-4 text-amber-500 shrink-0" />
              <div className="min-w-0">
                <span className="block truncate text-[11px]">เสียงบรรยากาศ</span>
                <span className="block text-[10px] opacity-60">{getAmbientLabel(ambientSound)}</span>
              </div>
            </button>

            {/* Sleep Timer */}
            <button
              onClick={() => {
                setIsMobileMenuOpen(false);
                onOpenSleepTimer();
              }}
              className={`p-2 rounded-xl border flex items-center gap-2 text-xs font-semibold text-left transition-colors ${
                sleepTimerRemaining !== null
                  ? 'bg-indigo-500/20 border-indigo-500/50 text-indigo-700 dark:text-indigo-300'
                  : 'border-current/15 hover:bg-black/5 dark:hover:bg-white/5'
              }`}
            >
              <Timer className="w-4 h-4 text-indigo-500 shrink-0" />
              <div className="min-w-0">
                <span className="block truncate text-[11px]">ตั้งเวลาปิดเสียง</span>
                <span className="block text-[10px] opacity-60">
                  {sleepTimerRemaining !== null ? formatTimer(sleepTimerRemaining) : 'ยังไม่ตั้ง'}
                </span>
              </div>
            </button>

            {/* AI Assistant */}
            <button
              onClick={() => {
                setIsMobileMenuOpen(false);
                onOpenAI();
              }}
              className="p-2 rounded-xl border border-purple-500/30 bg-purple-500/10 text-purple-700 dark:text-purple-300 flex items-center gap-2 text-xs font-semibold text-left"
            >
              <Sparkles className="w-4 h-4 text-purple-500 shrink-0" />
              <div className="min-w-0">
                <span className="block truncate text-[11px]">ผู้ช่วย AI</span>
                <span className="block text-[10px] opacity-60">วิเคราะห์/ต่อเรื่อง</span>
              </div>
            </button>

            {/* Reading & Voice Settings */}
            <button
              onClick={() => {
                setIsMobileMenuOpen(false);
                onOpenSettings();
              }}
              className="p-2 rounded-xl border border-current/15 hover:bg-black/5 dark:hover:bg-white/5 flex items-center gap-2 text-xs font-semibold text-left"
            >
              <Sliders className="w-4 h-4 text-amber-500 shrink-0" />
              <div className="min-w-0">
                <span className="block truncate text-[11px]">ตั้งค่าเสียง & ฟอนต์</span>
                <span className="block text-[10px] opacity-60">ความเร็ว, ขนาดตัวอักษร</span>
              </div>
            </button>
          </div>

          {/* If in Reader mode, button to toggle chapter list */}
          {currentView === 'reader' && (
            <button
              onClick={() => {
                setIsMobileMenuOpen(false);
                onToggleChapterSidebar();
              }}
              className="w-full py-2 px-3 rounded-xl border border-amber-500/40 bg-amber-500/10 text-amber-700 dark:text-amber-300 font-bold text-xs flex items-center justify-center gap-2"
            >
              <Layers className="w-3.5 h-3.5" />
              <span>เปิดแถบรายชื่อตอน ({currentNovel.chapters.length} ตอน)</span>
            </button>
          )}

          {/* If in Admin mode, button to create novel */}
          {userRole === 'admin' && (
            <button
              onClick={() => {
                setIsMobileMenuOpen(false);
                onOpenCreateNovel();
              }}
              className="w-full py-2 px-3 rounded-xl bg-amber-500 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-xs"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>+ สร้างนิยายเรื่องใหม่</span>
            </button>
          )}
        </div>
      )}
    </header>
  );
};
