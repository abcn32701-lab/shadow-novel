import React from 'react';
import { X, Timer, Moon, Check, BellOff } from 'lucide-react';

interface SleepTimerModalProps {
  isOpen: boolean;
  onClose: () => void;
  sleepTimerRemaining: number | null;
  onSetTimer: (minutes: number | null) => void;
}

export const SleepTimerModal: React.FC<SleepTimerModalProps> = ({
  isOpen,
  onClose,
  sleepTimerRemaining,
  onSetTimer,
}) => {
  if (!isOpen) return null;

  const presets = [
    { label: '5 นาที', minutes: 5, desc: 'งีบหลับสั้นๆ' },
    { label: '15 นาที', minutes: 15, desc: 'พักผ่อนคลาย' },
    { label: '30 นาที', minutes: 30, desc: 'ก่อนเข้านอน (ยอดนิยม)' },
    { label: '45 นาที', minutes: 45, desc: 'ฟังสบายๆ ยามค่ำคืน' },
    { label: '60 นาที', minutes: 60, desc: '1 ชั่วโมงเต็ม' },
  ];

  const formatTimer = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m} นาที ${s < 10 ? '0' : ''}${s} วินาที`;
  };

  return (
    <div 
      id="modal-sleep-timer-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fade-in"
    >
      <div 
        id="modal-sleep-timer-panel"
        className="bg-white dark:bg-neutral-900 text-stone-900 dark:text-neutral-100 w-full max-w-md rounded-2xl shadow-2xl border border-stone-200 dark:border-neutral-800 p-6 flex flex-col"
      >
        <div className="flex items-center justify-between pb-4 border-b border-stone-200 dark:border-neutral-800">
          <div className="flex items-center gap-2">
            <Timer className="w-5 h-5 text-indigo-500" />
            <h2 className="text-base font-bold">ตั้งเวลาปิดเสียงอ่านอัตโนมัติ</h2>
          </div>
          <button
            id="btn-close-sleep-timer"
            onClick={onClose}
            className="p-1.5 rounded-lg hover:bg-stone-100 dark:hover:bg-neutral-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Current status */}
        <div className="py-4 text-center">
          {sleepTimerRemaining !== null ? (
            <div className="p-4 rounded-xl bg-indigo-500/10 border border-indigo-500/30 text-indigo-700 dark:text-indigo-300">
              <span className="text-xs uppercase tracking-wider block opacity-70">กำลังนับถอยหลัง</span>
              <p className="text-2xl font-bold font-mono my-1">
                {formatTimer(sleepTimerRemaining)}
              </p>
              <p className="text-xs opacity-80">
                เมื่อหมดเวลา เสียงอ่านและเสียงบรรยากาศจะหยุดเล่นโดยอัตโนมัติ
              </p>
              <button
                id="btn-cancel-timer"
                onClick={() => {
                  onSetTimer(null);
                  onClose();
                }}
                className="mt-3 px-3 py-1.5 text-xs font-semibold rounded-lg bg-red-500/10 hover:bg-red-500/20 text-red-600 dark:text-red-400 border border-red-500/30 transition-colors"
              >
                ยกเลิกการตั้งเวลา
              </button>
            </div>
          ) : (
            <p className="text-xs opacity-60">
              เลือกเวลาที่คุณต้องการให้แอปหยุดอ่านนิยาย เพื่อให้คุณหลับได้อย่างสบายใจ
            </p>
          )}
        </div>

        {/* Preset choices */}
        <div className="space-y-2 mb-4">
          {presets.map((preset) => (
            <button
              key={preset.minutes}
              id={`btn-timer-${preset.minutes}`}
              onClick={() => {
                onSetTimer(preset.minutes);
                onClose();
              }}
              className="w-full p-3 rounded-xl border border-stone-200 dark:border-neutral-800 hover:border-indigo-400 dark:hover:border-indigo-500 hover:bg-indigo-50/50 dark:hover:bg-indigo-950/30 transition-all flex items-center justify-between text-left group"
            >
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-stone-100 dark:bg-neutral-800 flex items-center justify-center text-xs font-bold text-stone-700 dark:text-neutral-300 group-hover:bg-indigo-500 group-hover:text-white transition-colors">
                  {preset.minutes}m
                </div>
                <div>
                  <span className="text-sm font-semibold block">{preset.label}</span>
                  <span className="text-xs opacity-60 block">{preset.desc}</span>
                </div>
              </div>
              <Check className="w-4 h-4 opacity-0 group-hover:opacity-100 text-indigo-500 transition-opacity" />
            </button>
          ))}
        </div>

        <button
          onClick={onClose}
          className="w-full py-2.5 text-sm rounded-xl border border-stone-200 dark:border-neutral-700 hover:bg-stone-100 dark:hover:bg-neutral-800"
        >
          ปิดหน้าต่าง
        </button>
      </div>
    </div>
  );
};
