import { useState, useEffect, useRef, useCallback } from 'react';
import { SpeechSettings, TextSegment } from '../types';

interface UseSpeechPlayerProps {
  segments: TextSegment[];
  speechSettings: SpeechSettings;
  onChapterComplete?: () => void;
  autoScroll?: boolean;
}

export function useSpeechPlayer({
  segments,
  speechSettings,
  onChapterComplete,
}: UseSpeechPlayerProps) {
  const [isPlaying, setIsPlaying] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isLoadingAudio, setIsLoadingAudio] = useState(false);
  const [availableVoices, setAvailableVoices] = useState<SpeechSynthesisVoice[]>([]);
  const [sleepTimerRemaining, setSleepTimerRemaining] = useState<number | null>(null); // seconds
  const [sleepTimerTotal, setSleepTimerTotal] = useState<number | null>(null);

  // References to keep callbacks fresh
  const isPlayingRef = useRef(isPlaying);
  isPlayingRef.current = isPlaying;

  const isPausedRef = useRef(isPaused);
  isPausedRef.current = isPaused;

  const currentIndexRef = useRef(currentIndex);
  currentIndexRef.current = currentIndex;

  const segmentsRef = useRef(segments);
  segmentsRef.current = segments;

  const speechSettingsRef = useRef(speechSettings);
  speechSettingsRef.current = speechSettings;

  const onChapterCompleteRef = useRef(onChapterComplete);
  onChapterCompleteRef.current = onChapterComplete;

  const activeUtteranceRef = useRef<SpeechSynthesisUtterance | null>(null);
  const activeAudioRef = useRef<HTMLAudioElement | null>(null);
  const abortControllerRef = useRef<AbortController | null>(null);
  const sleepTimerIntervalRef = useRef<any>(null);

  // Pre-cached audio URLs for Edge TTS: Map<segmentIndex, objectUrl>
  const audioCacheRef = useRef<Map<number, string>>(new Map());

  // Load voices for Web Speech API fallback
  useEffect(() => {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) {
      return;
    }

    const updateVoices = () => {
      const voices = window.speechSynthesis.getVoices();
      if (voices.length > 0) {
        setAvailableVoices(voices);
      }
    };

    updateVoices();
    window.speechSynthesis.onvoiceschanged = updateVoices;

    return () => {
      if (window.speechSynthesis) {
        window.speechSynthesis.onvoiceschanged = null;
      }
    };
  }, []);

  // Stop any ongoing playback
  const stopAllAudio = useCallback(() => {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
    if (activeAudioRef.current) {
      activeAudioRef.current.pause();
      activeAudioRef.current.src = '';
      activeAudioRef.current = null;
    }
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
      abortControllerRef.current = null;
    }
    setIsLoadingAudio(false);
  }, []);

  // Prefetch audio for Edge TTS
  const prefetchEdgeAudio = useCallback(async (index: number) => {
    const segs = segmentsRef.current;
    if (!segs || index >= segs.length || audioCacheRef.current.has(index)) {
      return;
    }

    try {
      const seg = segs[index];
      const settings = speechSettingsRef.current;
      const res = await fetch('/api/tts/edge-tts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          text: seg.text,
          voice: settings.edgeVoice || 'th-TH-PremwadeeNeural',
          rate: settings.rate,
          pitch: settings.pitch,
        }),
      });
      if (res.ok) {
        const blob = await res.blob();
        const url = URL.createObjectURL(blob);
        audioCacheRef.current.set(index, url);
      }
    } catch (e) {
      // ignore prefetch errors
    }
  }, []);

  // Speak segment via Edge TTS
  const speakSegmentEdge = useCallback(async (index: number) => {
    const segs = segmentsRef.current;
    if (!segs || index >= segs.length) {
      setIsPlaying(false);
      setIsPaused(false);
      setIsLoadingAudio(false);
      onChapterCompleteRef.current?.();
      return;
    }

    stopAllAudio();
    setCurrentIndex(index);
    setIsPlaying(true);
    setIsPaused(false);

    try {
      let audioUrl = audioCacheRef.current.get(index);

      if (!audioUrl) {
        setIsLoadingAudio(true);
        const controller = new AbortController();
        abortControllerRef.current = controller;

        const settings = speechSettingsRef.current;
        const res = await fetch('/api/tts/edge-tts', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            text: segs[index].text,
            voice: settings.edgeVoice || 'th-TH-PremwadeeNeural',
            rate: settings.rate,
            pitch: settings.pitch,
          }),
          signal: controller.signal,
        });

        if (!res.ok) {
          throw new Error('Edge TTS response error');
        }

        const blob = await res.blob();
        audioUrl = URL.createObjectURL(blob);
        audioCacheRef.current.set(index, audioUrl);
      }

      setIsLoadingAudio(false);

      if (!isPlayingRef.current) return;

      const audio = new Audio(audioUrl);
      activeAudioRef.current = audio;

      audio.onended = () => {
        if (isPlayingRef.current && !isPausedRef.current) {
          const nextIdx = index + 1;
          if (nextIdx < segmentsRef.current.length) {
            speakSegmentEdge(nextIdx);
          } else {
            setIsPlaying(false);
            setIsPaused(false);
            onChapterCompleteRef.current?.();
          }
        }
      };

      audio.onerror = (e) => {
        console.warn('Edge audio error, falling back to Web Speech', e);
        speakSegmentWeb(index);
      };

      await audio.play();

      // Prefetch the next segment in parallel
      if (index + 1 < segs.length) {
        prefetchEdgeAudio(index + 1);
      }
    } catch (err: any) {
      if (err.name !== 'AbortError') {
        console.warn('Edge TTS failed, switching to browser voice', err);
        speakSegmentWeb(index);
      }
    }
  }, [prefetchEdgeAudio, stopAllAudio]);

  // Speak segment via browser Web Speech API
  const speakSegmentWeb = useCallback((index: number) => {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) {
      return;
    }

    const segs = segmentsRef.current;
    if (!segs || segs.length === 0 || index >= segs.length) {
      setIsPlaying(false);
      setIsPaused(false);
      setIsLoadingAudio(false);
      if (index >= segs.length && segs.length > 0) {
        onChapterCompleteRef.current?.();
      }
      return;
    }

    stopAllAudio();

    const targetSeg = segs[index];
    const utterance = new SpeechSynthesisUtterance(targetSeg.text);

    const settings = speechSettingsRef.current;
    utterance.rate = settings.rate;
    utterance.pitch = settings.pitch;
    utterance.volume = settings.volume;

    const voices = window.speechSynthesis.getVoices();
    let selectedVoice = voices.find(v => v.voiceURI === settings.voiceURI);

    if (!selectedVoice) {
      // Prioritize Premwadee if available in browser
      selectedVoice = voices.find(v => v.name.includes('Premwadee') || v.name.includes('เปรมวดี'));
      if (!selectedVoice) {
        selectedVoice = voices.find(v => v.lang.startsWith('th') || v.name.toLowerCase().includes('thai'));
      }
    }

    if (selectedVoice) {
      utterance.voice = selectedVoice;
      utterance.lang = selectedVoice.lang;
    } else {
      utterance.lang = 'th-TH';
    }

    utterance.onstart = () => {
      setCurrentIndex(index);
      setIsPlaying(true);
      setIsPaused(false);
      setIsLoadingAudio(false);
    };

    utterance.onend = () => {
      if (isPlayingRef.current && !isPausedRef.current) {
        const nextIdx = index + 1;
        if (nextIdx < segmentsRef.current.length) {
          speakSegmentWeb(nextIdx);
        } else {
          setIsPlaying(false);
          setIsPaused(false);
          onChapterCompleteRef.current?.();
        }
      }
    };

    utterance.onerror = (e) => {
      if (e.error !== 'canceled' && e.error !== 'interrupted') {
        console.warn('SpeechSynthesis error:', e.error);
      }
    };

    activeUtteranceRef.current = utterance;
    window.speechSynthesis.speak(utterance);
  }, [stopAllAudio]);

  // Master speak dispatcher
  const speakSegment = useCallback((index: number) => {
    if (speechSettingsRef.current.engine === 'edge-tts') {
      speakSegmentEdge(index);
    } else {
      speakSegmentWeb(index);
    }
  }, [speakSegmentEdge, speakSegmentWeb]);

  // Play / Resume
  const play = useCallback(() => {
    if (isPaused) {
      if (speechSettingsRef.current.engine === 'edge-tts' && activeAudioRef.current) {
        activeAudioRef.current.play();
        setIsPaused(false);
        setIsPlaying(true);
        return;
      } else if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
        window.speechSynthesis.resume();
        setIsPaused(false);
        setIsPlaying(true);
        return;
      }
    }

    setIsPlaying(true);
    setIsPaused(false);
    speakSegment(currentIndexRef.current);
  }, [isPaused, speakSegment]);

  // Pause
  const pause = useCallback(() => {
    if (speechSettingsRef.current.engine === 'edge-tts' && activeAudioRef.current) {
      activeAudioRef.current.pause();
    } else if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      window.speechSynthesis.pause();
    }
    setIsPaused(true);
    setIsPlaying(false);
  }, []);

  // Stop
  const stop = useCallback(() => {
    stopAllAudio();
    setIsPlaying(false);
    setIsPaused(false);
  }, [stopAllAudio]);

  // Jump to specific segment index
  const jumpToSegment = useCallback((index: number, autoStart = true) => {
    const safeIndex = Math.max(0, Math.min(segmentsRef.current.length - 1, index));
    setCurrentIndex(safeIndex);
    if (autoStart || isPlayingRef.current) {
      speakSegment(safeIndex);
    }
  }, [speakSegment]);

  // Next sentence
  const nextSegment = useCallback(() => {
    const nextIdx = currentIndexRef.current + 1;
    if (nextIdx < segmentsRef.current.length) {
      jumpToSegment(nextIdx, isPlayingRef.current);
    }
  }, [jumpToSegment]);

  // Previous sentence
  const prevSegment = useCallback(() => {
    const prevIdx = Math.max(0, currentIndexRef.current - 1);
    jumpToSegment(prevIdx, isPlayingRef.current);
  }, [jumpToSegment]);

  // Restart from beginning of chapter
  const restartChapter = useCallback(() => {
    jumpToSegment(0, isPlayingRef.current);
  }, [jumpToSegment]);

  // Clear cache on chapter/voice change
  useEffect(() => {
    audioCacheRef.current.forEach(url => URL.revokeObjectURL(url));
    audioCacheRef.current.clear();
  }, [speechSettings.edgeVoice, speechSettings.rate, speechSettings.pitch]);

  // Sleep timer logic
  const setSleepTimer = useCallback((minutes: number | null) => {
    if (sleepTimerIntervalRef.current) {
      clearInterval(sleepTimerIntervalRef.current);
      sleepTimerIntervalRef.current = null;
    }

    if (minutes === null || minutes <= 0) {
      setSleepTimerRemaining(null);
      setSleepTimerTotal(null);
      return;
    }

    const totalSecs = minutes * 60;
    setSleepTimerTotal(totalSecs);
    setSleepTimerRemaining(totalSecs);

    sleepTimerIntervalRef.current = setInterval(() => {
      setSleepTimerRemaining((prev) => {
        if (prev === null || prev <= 1) {
          clearInterval(sleepTimerIntervalRef.current);
          sleepTimerIntervalRef.current = null;
          stopAllAudio();
          setIsPlaying(false);
          setIsPaused(false);
          return null;
        }
        return prev - 1;
      });
    }, 1000);
  }, [stopAllAudio]);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      stopAllAudio();
      audioCacheRef.current.forEach(url => URL.revokeObjectURL(url));
      audioCacheRef.current.clear();
      if (sleepTimerIntervalRef.current) {
        clearInterval(sleepTimerIntervalRef.current);
      }
    };
  }, [stopAllAudio]);

  return {
    isPlaying,
    isPaused,
    isLoadingAudio,
    currentIndex,
    availableVoices,
    sleepTimerRemaining,
    sleepTimerTotal,
    play,
    pause,
    stop,
    jumpToSegment,
    nextSegment,
    prevSegment,
    restartChapter,
    setSleepTimer,
  };
}
