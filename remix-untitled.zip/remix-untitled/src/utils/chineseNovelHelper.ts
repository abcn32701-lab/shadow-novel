import { Chapter } from '../types';

/**
 * Cleans punctuation and typography artifacts commonly found in translated Chinese novels.
 */
export function cleanChineseNovelText(rawText: string): string {
  if (!rawText) return '';

  let text = rawText;

  // Replace Chinese brackets and quotes with natural Thai quotation marks
  text = text.replace(/[「『《〈【]/g, '"');
  text = text.replace(/[」』》〉】]/g, '"');

  // Replace Chinese ellipses and dashes with standard pauses
  text = text.replace(/[…]{2,}/g, '... ');
  text = text.replace(/[—]{2,}/g, ' - ');
  text = text.replace(/[\u3000]/g, ' '); // Chinese full-width space

  // Clean double quotes spacing
  text = text.replace(/""+/g, '"');

  // Ensure spacing after quotation marks for natural speech breathing
  text = text.replace(/\"([^\"]+)\"/g, ' "$1" ');

  return text.trim();
}

/**
 * Automatically detects and splits raw translated text into chapters based on
 * standard Thai / Chinese chapter headings like:
 * - ตอนที่ 1, ตอนที่ 2, ตอนที่ 10...
 * - บทที่ 1, บทที่ 2...
 * - 第1章, 第2章...
 * - Chapter 1, Chapter 2...
 */
export function splitNovelIntoChapters(rawText: string, novelId: string = 'novel'): Chapter[] {
  const cleaned = cleanChineseNovelText(rawText);
  if (!cleaned) return [];

  // Match lines that start with chapter keywords
  const lines = cleaned.split(/\n+/);
  const chapterRegex = /^(?:ตอนที่|บทที่|第\s*[0-9一二三四五六七八九十百千万]+\s*章|Chapter\s*[0-9]+)\s*[:：\s]/i;

  const chapters: { title: string; lines: string[] }[] = [];
  let currentChapterTitle = 'ตอนที่ 1: ปฐมบท';
  let currentLines: string[] = [];

  for (const line of lines) {
    const trimmed = line.trim();
    if (!trimmed) continue;

    if (chapterRegex.test(trimmed)) {
      // If we already have accumulated lines, push previous chapter
      if (currentLines.length > 0) {
        chapters.push({
          title: currentChapterTitle,
          lines: currentLines,
        });
        currentLines = [];
      }
      currentChapterTitle = trimmed;
    } else {
      currentLines.push(trimmed);
    }
  }

  // Push remaining chapter
  if (currentLines.length > 0) {
    chapters.push({
      title: currentChapterTitle,
      lines: currentLines,
    });
  }

  // If no chapter markers were found at all, check if text is long enough to break or keep single
  if (chapters.length === 0) {
    return [
      {
        id: `chap-${novelId}-1`,
        number: 1,
        title: 'ตอนที่ 1: จุดเริ่มต้น',
        content: cleaned,
      },
    ];
  }

  return chapters.map((ch, idx) => ({
    id: `chap-${novelId}-${idx + 1}`,
    number: idx + 1,
    title: ch.title,
    content: ch.lines.join('\n\n'),
  }));
}

/**
 * Common Chinese translated novel glossary & pronunciation helpers.
 */
export const CHINESE_NOVEL_GLOSSARY = [
  { term: 'ตันเถียน', reading: 'ตัน-เถียน', meaning: 'จุดศูนย์รวมพลังลมปราณใต้สะดือ' },
  { term: 'ลมปราณ', reading: 'ลม-ปราณ', meaning: 'พลังชี่หรือพลังชีวิตที่ไหลเวียนในเส้นชีพจร' },
  { term: 'ชั่วเค่อ', reading: 'ชั่ว-เค่อ', meaning: 'ระยะเวลาประมาณ 15 นาที' },
  { term: 'ยามจื่อ', reading: 'ยาม-จื่อ', meaning: 'ช่วงเวลา 23:00 - 01:00 น.' },
  { term: 'โอสถ', reading: 'โอ-สด', meaning: 'ยาเม็ดวิเศษหรือยาลูกกลอนเพิ่มพลัง' },
  { term: 'ทะลวงขั้น', reading: 'ทะ-ลวง-ขั้น', meaning: 'การก้าวข้ามระดับพลังยุทธ์สู่ขอบเขตใหม่' },
  { term: 'จอมยุทธ์', reading: 'จอม-ยุด', meaning: 'ผู้ฝึกตนหรือผู้มีวรยุทธ์ในยุทธภพ' },
  { term: 'ศิษย์พี่', reading: 'สิด-พี่', meaning: 'ผู้ร่วมสำนักที่มีลำดับอาวุโสสูงกว่า' },
  { term: 'หยกวิญญาณ', reading: 'หยก-วิน-ยาน', meaning: 'ศิลาหินล้ำค่าที่มีพลังงานบริสุทธิ์' },
  { term: 'แหวนมิติ', reading: 'แหวน-มิ-ติ', meaning: 'แหวนวิเศษสำหรับเก็บสิ่งของได้ไม่จำกัด' },
];
