import { TextSegment } from '../types';

/**
 * Splits text into paragraphs and manageable sentence segments for TTS and Karaoke highlight.
 */
export function parseTextToSegments(rawContent: string): {
  paragraphs: { paragraphIndex: number; segments: TextSegment[] }[];
  allSegments: TextSegment[];
} {
  if (!rawContent) {
    return { paragraphs: [], allSegments: [] };
  }

  // Split by double line breaks or single line breaks into paragraphs
  const rawParagraphs = rawContent.split(/\n+/).map(p => p.trim()).filter(Boolean);

  const paragraphs: { paragraphIndex: number; segments: TextSegment[] }[] = [];
  const allSegments: TextSegment[] = [];

  let globalIndex = 0;
  let charCounter = 0;

  rawParagraphs.forEach((paragraphText, pIndex) => {
    // Break paragraph by sentence terminators or natural pause boundaries:
    // Punctuation like ., !, ?, ", ” or double spaces, or natural phrase length (around 40-70 chars for Thai)
    const sentenceChunks = splitThaiSentences(paragraphText);
    const pSegments: TextSegment[] = [];

    sentenceChunks.forEach((chunk, sIndex) => {
      const trimmed = chunk.trim();
      if (!trimmed) return;

      const segment: TextSegment = {
        id: `seg-${pIndex}-${sIndex}-${globalIndex}`,
        paragraphIndex: pIndex,
        sentenceIndex: sIndex,
        text: trimmed,
        startIndex: charCounter,
        endIndex: charCounter + trimmed.length,
      };

      charCounter += trimmed.length + 1;
      globalIndex++;
      pSegments.push(segment);
      allSegments.push(segment);
    });

    if (pSegments.length > 0) {
      paragraphs.push({
        paragraphIndex: pIndex,
        segments: pSegments,
      });
    }
  });

  return { paragraphs, allSegments };
}

/**
 * Splits Thai prose into natural reading phrases while preserving dialogue and punctuation.
 */
function splitThaiSentences(paragraph: string): string[] {
  // Check if contains dialogue quotes
  const chunks: string[] = [];
  
  // Split on strong punctuation first if present (?!...)
  const regex = /([^.!?…]+[.!?…]+["”]?|\"[^\"]+\"|“[^”]+”|[^.!?…]+)/g;
  const rawMatches = paragraph.match(regex) || [paragraph];

  for (const raw of rawMatches) {
    const trimmed = raw.trim();
    if (!trimmed) continue;

    // If a chunk is still very long without punctuation (common in Thai text),
    // split on natural clause boundaries like spaces or words
    if (trimmed.length > 80 && trimmed.includes(' ')) {
      const subParts = trimmed.split(/\s{1,}/);
      let currentBuffer = '';

      for (const part of subParts) {
        if ((currentBuffer + ' ' + part).length > 60 && currentBuffer.length > 0) {
          chunks.push(currentBuffer.trim());
          currentBuffer = part;
        } else {
          currentBuffer = currentBuffer ? `${currentBuffer} ${part}` : part;
        }
      }
      if (currentBuffer.trim()) {
        chunks.push(currentBuffer.trim());
      }
    } else {
      chunks.push(trimmed);
    }
  }

  return chunks.length > 0 ? chunks : [paragraph];
}
