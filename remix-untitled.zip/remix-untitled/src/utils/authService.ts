import { UserProfile, StoredAccount, UserRole } from '../types';

const STORAGE_KEY_ACCOUNTS = 'shadow_novel_accounts_v1';
const STORAGE_KEY_CURRENT_USER = 'shadow_novel_current_user_v1';

// Seed default initial accounts for easy testing
const DEFAULT_ACCOUNTS: StoredAccount[] = [
  {
    id: 'account-admin-default',
    name: 'ผู้ดูแลระบบ (Admin)',
    email: 'admin@shadow.novel',
    passwordHash: 'admin123',
    role: 'admin',
    avatarColor: 'from-amber-500 to-amber-600',
    createdAt: Date.now() - 86400000 * 30,
    favorites: [],
    history: []
  },
  {
    id: 'account-listener-default',
    name: 'คุณนักฟังนิยาย',
    email: 'listener@shadow.novel',
    passwordHash: '123456',
    role: 'listener',
    avatarColor: 'from-indigo-500 to-purple-600',
    createdAt: Date.now() - 86400000 * 5,
    favorites: [],
    history: []
  }
];

export function getStoredAccounts(): StoredAccount[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY_ACCOUNTS);
    if (!raw) {
      localStorage.setItem(STORAGE_KEY_ACCOUNTS, JSON.stringify(DEFAULT_ACCOUNTS));
      return DEFAULT_ACCOUNTS;
    }
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : DEFAULT_ACCOUNTS;
  } catch (err) {
    console.error('Failed to read accounts from storage:', err);
    return DEFAULT_ACCOUNTS;
  }
}

export function saveStoredAccounts(accounts: StoredAccount[]): void {
  try {
    localStorage.setItem(STORAGE_KEY_ACCOUNTS, JSON.stringify(accounts));
  } catch (err) {
    console.error('Failed to save accounts to storage:', err);
  }
}

export function getCurrentUser(): UserProfile | null {
  try {
    const raw = localStorage.getItem(STORAGE_KEY_CURRENT_USER);
    if (!raw) return null;
    return JSON.parse(raw);
  } catch (err) {
    console.error('Failed to read current user:', err);
    return null;
  }
}

export function setCurrentUser(user: UserProfile | null): void {
  try {
    if (user) {
      localStorage.setItem(STORAGE_KEY_CURRENT_USER, JSON.stringify(user));
    } else {
      localStorage.removeItem(STORAGE_KEY_CURRENT_USER);
    }
  } catch (err) {
    console.error('Failed to update current user session:', err);
  }
}

const AVATAR_COLORS = [
  'from-amber-500 to-orange-600',
  'from-indigo-500 to-purple-600',
  'from-emerald-500 to-teal-600',
  'from-rose-500 to-pink-600',
  'from-sky-500 to-blue-600',
  'from-violet-500 to-fuchsia-600'
];

export function registerAccount(
  name: string,
  email: string,
  password: string,
  role: UserRole = 'listener'
): { success: boolean; error?: string; user?: UserProfile } {
  const cleanName = name.trim();
  const cleanEmail = email.trim().toLowerCase();
  const cleanPassword = password.trim();

  if (!cleanName) {
    return { success: false, error: 'กรุณากรอกชื่อของคุณ' };
  }
  if (!cleanEmail || !cleanEmail.includes('@') || !cleanEmail.includes('.')) {
    return { success: false, error: 'กรุณากรอกรูปแบบอีเมลให้ถูกต้อง (เช่น name@example.com)' };
  }
  if (cleanPassword.length < 4) {
    return { success: false, error: 'รหัสผ่านต้องมีความยาวอย่างน้อย 4 ตัวอักษร' };
  }

  const accounts = getStoredAccounts();
  const exists = accounts.find(a => a.email.toLowerCase() === cleanEmail);
  if (exists) {
    return { success: false, error: 'อีเมลนี้ถูกใช้งานแล้ว กรุณาใช้อีเมลอื่น หรือกดเข้าสู่ระบบ' };
  }

  const randomColor = AVATAR_COLORS[Math.floor(Math.random() * AVATAR_COLORS.length)];

  const newAccount: StoredAccount = {
    id: `user-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
    name: cleanName,
    email: cleanEmail,
    passwordHash: cleanPassword, // In-browser client storage
    role,
    avatarColor: randomColor,
    createdAt: Date.now(),
    favorites: [],
    history: []
  };

  accounts.push(newAccount);
  saveStoredAccounts(accounts);

  const { passwordHash, ...userProfile } = newAccount;
  setCurrentUser(userProfile);

  return { success: true, user: userProfile };
}

export function loginAccount(
  email: string,
  password: string
): { success: boolean; error?: string; user?: UserProfile } {
  const cleanEmail = email.trim().toLowerCase();
  const cleanPassword = password.trim();

  if (!cleanEmail) {
    return { success: false, error: 'กรุณากรอกอีเมล' };
  }
  if (!cleanPassword) {
    return { success: false, error: 'กรุณากรอกรหัสผ่าน' };
  }

  const accounts = getStoredAccounts();
  const account = accounts.find(a => a.email.toLowerCase() === cleanEmail);

  if (!account) {
    return { success: false, error: 'ไม่พบอีเมลนี้ในระบบ กรุณาตรวจสอบอีเมลหรือสมัครสมาชิกใหม่' };
  }

  if (account.passwordHash !== cleanPassword) {
    return { success: false, error: 'รหัสผ่านไม่ถูกต้อง กรุณาลองใหม่อีกครั้ง' };
  }

  const { passwordHash, ...userProfile } = account;
  setCurrentUser(userProfile);

  return { success: true, user: userProfile };
}

export function logoutAccount(): void {
  setCurrentUser(null);
}

export function toggleFavoriteNovel(userId: string, novelId: string): string[] {
  const accounts = getStoredAccounts();
  const index = accounts.findIndex(a => a.id === userId);
  if (index === -1) return [];

  const currentFavorites = accounts[index].favorites || [];
  const exists = currentFavorites.includes(novelId);
  const updatedFavorites = exists
    ? currentFavorites.filter(id => id !== novelId)
    : [...currentFavorites, novelId];

  accounts[index].favorites = updatedFavorites;
  saveStoredAccounts(accounts);

  const currentUser = getCurrentUser();
  if (currentUser && currentUser.id === userId) {
    currentUser.favorites = updatedFavorites;
    setCurrentUser(currentUser);
  }

  return updatedFavorites;
}
