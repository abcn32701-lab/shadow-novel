export interface Chapter {
  id: string;
  number: number;
  title: string;
  content: string;
}

export interface Novel {
  id: string;
  title: string;
  author: string;
  category: string;
  coverColor: string;
  coverImage?: string; // Base64 data url or image URL uploaded by user
  description: string;
  chapters: Chapter[];
  isCustom?: boolean;
  createdAt: number;
  updatedAt: number;
}

export type ReaderTheme = 'sepia' | 'light' | 'night' | 'oled';
export type ReaderFont = 'sarabun' | 'prompt' | 'noto' | 'sans';
export type UserRole = 'admin' | 'listener';

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  avatarColor?: string;
  createdAt: number;
  favorites?: string[]; // array of novel IDs
  history?: Array<{
    novelId: string;
    chapterId: string;
    timestamp: number;
  }>;
}

export interface StoredAccount extends UserProfile {
  passwordHash: string;
}

export interface ReadingSettings {
  theme: ReaderTheme;
  fontFamily: ReaderFont;
  fontSize: number; // in px: 14 to 28
  lineHeight: number; // 1.6 to 2.4
  autoScroll: boolean;
  autoNextChapter: boolean;
}

export type TTSEngineType = 'edge-tts' | 'web-speech';

export interface SpeechSettings {
  engine: TTSEngineType;
  edgeVoice: string; // 'th-TH-PremwadeeNeural' | 'th-TH-NiwatNeural'
  voiceURI: string;
  rate: number; // 0.5 to 2.0
  pitch: number; // 0.6 to 1.5
  volume: number; // 0 to 1
  lang: string;
}

export type AmbientSoundType = 'off' | 'rain' | 'campfire' | 'cafe' | 'waves';

export interface TextSegment {
  id: string;
  paragraphIndex: number;
  sentenceIndex: number;
  text: string;
  startIndex: number;
  endIndex: number;
}
