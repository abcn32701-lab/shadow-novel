import express from "express";
import path from "path";
import { fileURLToPath } from "url";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import { MsEdgeTTS, OUTPUT_FORMAT } from "msedge-tts";
import dotenv from "dotenv";

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

let aiClient: GoogleGenAI | null = null;
function getAI(): GoogleGenAI | null {
  if (!aiClient && process.env.GEMINI_API_KEY) {
    aiClient = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
  }
  return aiClient;
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json({ limit: "5mb" }));

  // Health check
  app.get("/api/health", (_req, res) => {
    res.json({
      status: "ok",
      hasGeminiKey: !!process.env.GEMINI_API_KEY,
    });
  });

  // Edge TTS Voices
  app.get("/api/tts/edge-voices", (_req, res) => {
    res.json({
      voices: [
        {
          id: "th-TH-PremwadeeNeural",
          name: "Premwadee (เปรมวดี - เสียงผู้หญิง)",
          gender: "Female",
          lang: "th-TH",
          badge: "แนะนำสำหรับนิยาย",
        },
        {
          id: "th-TH-NiwatNeural",
          name: "Niwat (นิวัต - เสียงผู้ชาย)",
          gender: "Male",
          lang: "th-TH",
          badge: "เสียงทุ้มนุ่ม",
        },
      ],
    });
  });

  // Edge TTS Audio Stream endpoint
  app.post("/api/tts/edge-tts", async (req, res) => {
    try {
      const { text, voice = "th-TH-PremwadeeNeural", rate = 1.0, pitch = 1.0 } = req.body;
      if (!text || typeof text !== "string") {
        return res.status(400).json({ error: "Missing or invalid text" });
      }

      const tts = new MsEdgeTTS();
      await tts.setMetadata(voice, OUTPUT_FORMAT.AUDIO_24KHZ_48KBITRATE_MONO_MP3);

      let rateStr = "default";
      if (rate && rate !== 1.0) {
        const diff = Math.round((rate - 1.0) * 100);
        rateStr = diff >= 0 ? `+${diff}%` : `${diff}%`;
      }

      let pitchStr = "default";
      if (pitch && pitch !== 1.0) {
        const diff = Math.round((pitch - 1.0) * 100);
        pitchStr = diff >= 0 ? `+${diff}%` : `${diff}%`;
      }

      const { audioStream } = tts.toStream(text, {
        rate: rateStr,
        pitch: pitchStr,
      });

      res.setHeader("Content-Type", "audio/mpeg");
      audioStream.pipe(res);
    } catch (err: any) {
      console.error("Edge TTS error:", err);
      res.status(500).json({ error: err?.message || "Failed to generate Edge TTS speech" });
    }
  });

  // AI Summarize Chapter
  app.post("/api/ai/summarize", async (req, res) => {
    try {
      const { text, title } = req.body;
      if (!text) {
        return res.status(400).json({ error: "Missing novel text" });
      }

      const ai = getAI();
      if (!ai) {
        return res.status(503).json({
          error: "ยังไม่ได้ระบุ GEMINI_API_KEY ในระบบ",
        });
      }

      const prompt = `คุณคือนักวิเคราะห์วรรณกรรมและบรรณาธิการนิยายมืออาชีพ
กรุณาสรุปเนื้อหาสำคัญของนิยายบทนี้ "${title || 'บทนี้'}" ให้อ่านเข้าใจง่าย น่าติดตาม ในรูปแบบข้อความภาษาไทยความยาวประมาณ 3-5 บรรทัด หรือ 3 ประเด็นสำคัญ พร้อมบอกอารมณ์/โทนของเรื่อง (เช่น ตื่นเต้น, ซาบซึ้ง, ลึกลับ):

เนื้อหา:
${text.slice(0, 4000)}`;

      const response = await ai.models.generateContent({
        model: "gemini-3.8-flash",
        contents: prompt,
      });

      res.json({ summary: response.text });
    } catch (err: any) {
      console.error("AI Summarize error:", err);
      res.status(500).json({ error: err?.message || "เกิดข้อผิดพลาดในการประมวลผล AI" });
    }
  });

  // AI Continue Story (แต่งเรื่องต่อ)
  app.post("/api/ai/continue", async (req, res) => {
    try {
      const { contextText, title, instruction } = req.body;
      if (!contextText) {
        return res.status(400).json({ error: "Missing novel text context" });
      }

      const ai = getAI();
      if (!ai) {
        return res.status(503).json({
          error: "ยังไม่ได้ระบุ GEMINI_API_KEY ในระบบ",
        });
      }

      const prompt = `คุณคือนักเขียนนิยายมือฉมัง
จงเขียนเนื้อเรื่องฉากถัดไปของนิยายเรื่อง "${title || 'นิยาย'}" ต่อจากข้อความเดิมอย่างกลมกลืน ดึงดูดอารมณ์ และมีบทสนทนาที่น่าติดตาม 
${instruction ? `คำขอพิเศษของผู้แต่ง: ${instruction}` : ''}
ใช้สำนวนภาษาไทยสละสลวย เหมาะสำหรับใช้อ่านออกเสียงเป็นนิยายเสียง (audiobook) ความยาวประมาณ 2-3 ย่อหน้า:

บริบทเนื้อเรื่องเดิม:
${contextText.slice(-2500)}`;

      const response = await ai.models.generateContent({
        model: "gemini-3.8-flash",
        contents: prompt,
      });

      res.json({ continuation: response.text });
    } catch (err: any) {
      console.error("AI Continue error:", err);
      res.status(500).json({ error: err?.message || "เกิดข้อผิดพลาดในการสร้างเนื้อเรื่องต่อ" });
    }
  });

  // AI Character & Setting breakdown
  app.post("/api/ai/analyze-characters", async (req, res) => {
    try {
      const { text, title } = req.body;
      if (!text) {
        return res.status(400).json({ error: "Missing text" });
      }

      const ai = getAI();
      if (!ai) {
        return res.status(503).json({ error: "ยังไม่ได้ระบุ GEMINI_API_KEY" });
      }

      const prompt = `จากเนื้อหานิยายตอน "${title || ''}" ต่อไปนี้ กรุณาวิเคราะห์:
1. ตัวละครหลักที่ปรากฏในตอนนี้ (ชื่อ และบุคลิก/บทบาทสั้นๆ)
2. ฉากสถานที่และบรรยากาศ
3. คำแนะนำในการใช้น้ำเสียงสำหรับอ่านนิยายเสียงบทนี้ (เช่น โทนเสียง พากย์อย่างไรให้อิน)

เนื้อหานิยาย:
${text.slice(0, 3500)}`;

      const response = await ai.models.generateContent({
        model: "gemini-3.8-flash",
        contents: prompt,
      });

      res.json({ analysis: response.text });
    } catch (err: any) {
      console.error("AI Analyze error:", err);
      res.status(500).json({ error: err?.message || "เกิดข้อผิดพลาดในการวิเคราะห์ตัวละคร" });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (_req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
